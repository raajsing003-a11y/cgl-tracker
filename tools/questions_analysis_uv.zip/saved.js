(function () {

function mqFmt(e) {
  e = String(e || '').replace(/\r/g, '').trim();
  if (!e) return e;
  e = e.replace(/[ \t]*(मूल अवधारणा|बेसिक कॉन्सेप्ट|स्मार्ट ट्रिक|गलत विकल्प|सही उत्तर)/g, '\n\n$1');
  e = e.replace(/([।])[ \t]+(?=\S)/g, '$1\n');
  e = e.replace(/[ \t]+(?=(?:स्टेप|चरण|Step)\s*\d)/g, '\n');
  e = e.replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n');
  return e.trim();
}
function mqTex(s) {
  return String(s || '').replace(/\\\[([\s\S]+?)\\\]/g, function (m, a) { return '$$' + a + '$$'; }).replace(/\\\(([\s\S]+?)\\\)/g, function (m, a) { return '$' + a + '$'; });
}

  function math(el) {
    try { if (window.renderMathInElement) renderMathInElement(el, { delimiters: [{ left: '$$', right: '$$', display: true }, { left: '\\[', right: '\\]', display: true }, { left: '\\(', right: '\\)', display: false }, { left: '$', right: '$', display: false }], throwOnError: false, strict: false }); } catch (e) {}
  }
  var items = [], sel = {}, $ = function (i) { return document.getElementById(i); };
  function load(cb) { chrome.storage.local.get('mqSaved', function (o) { items = (o && o.mqSaved) || []; cb && cb(); }); }
  function persist(cb) { chrome.storage.local.set({ mqSaved: items }, function () { cb && cb(); }); }
  function host(u) { try { return new URL(u).hostname; } catch (e) { return ''; } }
  function mqNorm(s){ return String(s || '').toLowerCase().replace(/[^a-z0-9\u0900-\u097f]+/g, ' ').trim(); }
function mqSet(s){ var o = {}; mqNorm(s).split(' ').forEach(function(w){ if(w) o[w] = 1; }); return o; }
function mqJacArr(a, b){ var A = {}, B = {}, n = 0, u = 0, k; a.forEach(function(x){ A[x] = 1; }); b.forEach(function(x){ B[x] = 1; });
  for(k in A){ u++; if(B[k]) n++; } for(k in B){ if(!A[k]) u++; } return u ? n / u : 0; }
function mqSame(q, x){
  if(!q || !x) return false;
  var tq = mqNorm(q.t), tx = mqNorm(x.t); if(!tq || !tx) return false;
  var oq = (q.o || []).map(mqNorm).filter(Boolean), ox = (x.o || []).map(mqNorm).filter(Boolean), both = oq.length && ox.length;
  if(tq === tx) return both ? mqJacArr(oq, ox) >= 0.5 : true;
  var A = mqSet(q.t), B = mqSet(x.t), ka = Object.keys(A), kb = Object.keys(B), n = 0;
  if(Math.min(ka.length, kb.length) < 5) return false;
  ka.forEach(function(k){ if(B[k]) n++; });
  var ov = n / Math.min(ka.length, kb.length);
  if(ov < 0.9) return false;
  return both ? mqJacArr(oq, ox) >= 0.5 : ov >= 0.97;
}


  function shown() {
    var f = $('fs').value, fc = $('fc').value, st = $('ft').value, k = ($('sq').value || '').toLowerCase().trim();
    return items.filter(function (q) {
      if (f && q.s !== f) return false;
      if (fc && (q.c || 'Bina chapter') !== fc) return false;
      if (st === 'new' && q.synced) return false;
      if (st === 'done' && !(q.synced && !q.skipped)) return false;
      if (st === 'skip' && !q.skipped) return false;
      if (st === 'bad' && !(self.MQ && MQ.broken(q))) return false;
      if (k && (q.t + ' ' + (q.o || []).join(' ') + ' ' + (q.e || '')).toLowerCase().indexOf(k) < 0) return false;
      return true;
    });
  }
  function render() {
    var L = shown(), box = $('list'); box.textContent = '';
    fillCh();
    var grp = $('gr').checked, lastG = null, cntG = {};
    if (grp) {
      var so = { Math: 0, Reasoning: 1, English: 2, GK: 3 };
      L = L.map(function (q, i) { return [q, i]; }).sort(function (a, b) { var x = a[0], y = b[0], sx = so[x.s] == null ? 9 : so[x.s], sy = so[y.s] == null ? 9 : so[y.s]; if (sx !== sy) return sx - sy; var cx = x.c || '~', cy = y.c || '~'; if (cx !== cy) return cx < cy ? -1 : 1; return a[1] - b[1]; }).map(function (p) { return p[0]; });
      L.forEach(function (q) { var g = (q.s || '?') + ' › ' + (q.c || 'Bina chapter'); cntG[g] = (cntG[g] || 0) + 1; });
    }
    $('cnt').textContent = '(' + items.length + ')';
    if (!L.length) { var d = document.createElement('div'); d.className = 'empty'; d.textContent = 'Abhi koi saved question nahi. Gemini/Google me reply aate hi (---MOCKBANK--- block) yahan save ho jayega.'; box.appendChild(d); return; }
    L.forEach(function (q, n) {
      if (grp) { var g = (q.s || '?') + ' › ' + (q.c || 'Bina chapter'); if (g !== lastG) { lastG = g; var gh = document.createElement('div'); gh.className = 'gh'; gh.textContent = '📘 ' + g + '  (' + cntG[g] + ')'; box.appendChild(gh); } }
      var c = document.createElement('div'); c.className = 'card';
      var top = document.createElement('div'); top.className = 'top';
      var cb = document.createElement('input'); cb.type = 'checkbox'; cb.checked = !!sel[q.id]; cb.onchange = function () { sel[q.id] = cb.checked; };
      var sb = document.createElement('select'); ['Math', 'English', 'Reasoning', 'GK'].forEach(function (s) { var o = document.createElement('option'); o.textContent = s; if (q.s === s) o.selected = true; sb.appendChild(o); });
      sb.onchange = function () { q.s = sb.value; persist(); };
      var ab = document.createElement('select'); ['', 'A', 'B', 'C', 'D'].forEach(function (s) { var o = document.createElement('option'); o.value = s; o.textContent = s ? 'Ans ' + s : 'Ans ?'; if ((q.a || '') === s) o.selected = true; ab.appendChild(o); });
      ab.onchange = function () { q.a = ab.value; persist(render); };
      var sp = document.createElement('span'); sp.textContent = (n + 1) + ' · ' + (host(q.src) || '—') + (q.synced ? (q.skipped ? ' · ⏭ app me pehle se tha' : ' · ✅ app me gaya') : ' · ⏳ app ka wait') + (self.MQ && MQ.broken(q) ? ' · ⚠ math toota' : '');
      var ci = document.createElement('input'); ci.setAttribute('list', 'chl'); ci.value = q.c || ''; ci.placeholder = 'Chapter?'; ci.style.cssText = 'width:130px;padding:6px 8px;border-radius:8px;border:1px solid #3a3d44;background:#0f1013;color:#eee;font-size:12px'; ci.onchange = function () { q.c = ci.value.trim(); if (q.synced && !q.skipped) { q.force = true; q.synced = false; } persist(render); };
      top.appendChild(cb); top.appendChild(sb); top.appendChild(ci); top.appendChild(ab); top.appendChild(sp); var pb = document.createElement('button'); pb.className = 'b'; pb.textContent = q.synced && !q.skipped ? '✅' : (q.skipped ? '➕ phir bhi app me' : '➕ App me'); pb.disabled = !!(q.synced && !q.skipped); pb.title = 'Is question ko app ke Mock Question Add me bhejo (app admin ke saath khula ho)'; pb.onclick = function () { q.force = true; q.synced = false; q.skipped = false; persist(render); }; top.appendChild(pb); c.appendChild(top);
      if (q.img) { var im = document.createElement('img'); im.className = 'sh'; im.src = q.img; c.appendChild(im); }
      var t = document.createElement('div'); t.className = 'q'; t.textContent = q.t; c.appendChild(t);
      (q.o || []).forEach(function (o, i) { if (!o) return; var d = document.createElement('div'); d.className = 'o' + ('ABCD'[i] === q.a ? ' ok' : ''); d.textContent = 'ABCD'[i] + ') ' + o; c.appendChild(d); });
      if (q.e) { var e = document.createElement('div'); e.className = 'e'; e.textContent = mqFmt(q.e); c.appendChild(e); }
      box.appendChild(c); math(c);
    });
  }
  function fillCh() {
    var cur = $('fc').value, seen = {}, names = [], all = {};
    items.forEach(function (q) { var c = q.c || 'Bina chapter'; if (!seen[c]) { seen[c] = 1; names.push(c); } if (q.c) all[q.c] = 1; });
    names.sort();
    var h = '<option value="">Sab chapter</option>' + names.map(function (c) { return '<option>' + c.replace(/[&<>"]/g, '') + '</option>'; }).join('');
    if ($('fc')._h !== h) { $('fc').innerHTML = h; $('fc')._h = h; $('fc').value = cur; }
    var dl = Object.keys(all).sort().map(function (c) { return '<option value="' + c.replace(/[&<>"]/g, '') + '">'; }).join('');
    if ($('chl')._h !== dl) { $('chl').innerHTML = dl; $('chl')._h = dl; }
  }
  $('fc').onchange = render; $('gr').onchange = render;
  $('fs').onchange = render; $('ft').onchange = render; $('sq').oninput = render;
  $('sendSel').onclick = function () {
    var c = items.filter(function (q) { return sel[q.id]; });
    if (!c.length) { alert('Pehle questions chuno (ya ek ek ke saath ➕ dabao)'); return; }
    c.forEach(function (q) { q.force = true; q.synced = false; q.skipped = false; });
    persist(function () { render(); alert(c.length + ' question app ko bhejne ke liye taiyar. CGLY app (Admin) khula rakho — kuch second me aa jayenge.'); });
  };
  $('dd').onclick = function () {
    var keep = [], drop = 0;
    function score(q) { return (q.e ? q.e.length : 0) + (q.a ? 50 : 0) + (q.img ? 20 : 0) - (self.MQ && MQ.broken(q) ? 100000 : 0); }
    items.forEach(function (q) {
      var j = -1; for (var i = 0; i < keep.length; i++) { if (mqSame(q, keep[i])) { j = i; break; } }
      if (j < 0) { keep.push(q); return; }
      drop++; if (score(q) > score(keep[j])) keep[j] = q;
    });
    if (!drop) { alert('Koi repeat question nahi mila'); return; }
    if (!confirm(drop + ' repeat question hatao? (har question ka sabse detailed version bacha rahega)')) return;
    items = keep; sel = {}; persist(render);
  };
  $('fx').onclick = function () {
    var L = chosen(), nfix = 0, none = 0;
    L.forEach(function (q) {
      var nt = MQ.joinTiny(q.t), no = (q.o || []).map(function (o) { return MQ.joinTiny(o); }), ne = mqFmt(MQ.joinTiny(q.e));
      var ch = nt !== String(q.t || '').replace(/\r/g, '') || no.join('\u0001') !== (q.o || []).join('\u0001') || MQ.joinTiny(q.e) !== String(q.e || '').replace(/\r/g, '');
      if (!ch) { none++; return; }
      q.t = nt; q.o = no; q.e = ne; q.bad = 1; nfix++;      // asli LaTeX wapas nahi aa sakta => bad:1 (dobara banwane ke liye)
    });
    if (!nfix) { alert('Kisi question me bikhri hui 1-akshar wali lines nahi mili (' + L.length + ' check kiye)'); return; }
    persist(function () { render(); alert(nfix + ' question me lines jod di gayi.\n\n⚠ Inka asli LaTeX wapas nahi aa sakta (text sirf padhne layak hua). Sahi math ke liye: wahi question ka screenshot dobara Gemini/Google ko bhejo (naya prompt) — reply aate hi ye purana wala apne aap naye se badal jayega. Filter: "⚠ Math toota".'); });
  };
  $('dsy').onclick = function () {
    var n = items.filter(function (q) { return q.synced && !q.skipped; }).length;
    if (!n) { alert('Abhi koi "app me gaya" question nahi'); return; }
    if (!confirm(n + ' question jo app me ja chuke hain, yahan se hatao?')) return;
    items = items.filter(function (q) { return !(q.synced && !q.skipped); }); sel = {}; persist(render);
  };
  $('sel').onclick = function () { var L = shown(), all = L.every(function (q) { return sel[q.id]; }); L.forEach(function (q) { sel[q.id] = !all; }); render(); };
  $('del').onclick = function () {
    var ids = items.filter(function (q) { return sel[q.id]; }).map(function (q) { return q.id; });
    if (!ids.length) { alert('Pehle questions chuno'); return; }
    if (!confirm(ids.length + ' question hatao?')) return;
    items = items.filter(function (q) { return ids.indexOf(q.id) < 0; }); sel = {}; persist(render);
  };
  function chosen() { var c = items.filter(function (q) { return sel[q.id]; }); return c.length ? c : shown(); }
  $('exj').onclick = function () {
    var L = chosen(); if (!L.length) { alert('Kuch save nahi hai'); return; }
    var out = L.map(function (q) { return { id: q.id, s: q.s || 'Math', tp: q.c || 'Other', c: q.c || '', pend: 1, t: mqTex(q.t), img: q.img || '', o: (q.o || ['', '', '', '']).map(mqTex), a: q.a || '', e: mqTex(mqFmt(q.e)) }; });
    var a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([JSON.stringify(out)], { type: 'application/json' }));
    a.download = 'mock-questions-extension-' + new Date().toISOString().slice(0, 10) + '.json'; a.click();
  };
  $('pdf').onclick = function () {
    var L = chosen(); if (!L.length) { alert('Kuch save nahi hai'); return; }
    var P = $('print'); P.textContent = '';
    var oi = $('oi').checked, oa = $('oa').checked, oe = $('oe').checked;
    L.forEach(function (q, n) {
      var d = document.createElement('div'); d.className = 'pq';
      var h = document.createElement('div'); var b = document.createElement('b'); b.className = 'n'; b.textContent = 'Q' + (n + 1) + '. '; h.appendChild(b); h.appendChild(document.createTextNode((q.t || '') + (q.s ? '   [' + q.s + ']' : ''))); h.style.whiteSpace = 'pre-wrap'; d.appendChild(h);
      if (oi && q.img) { var im = document.createElement('img'); im.src = q.img; d.appendChild(im); }
      (q.o || []).forEach(function (o, i) { if (!o) return; var x = document.createElement('div'); x.className = 'po'; x.textContent = 'ABCD'[i] + ') ' + o; d.appendChild(x); });
      if (oa && q.a) { var a = document.createElement('div'); a.className = 'pa'; a.textContent = 'Answer: ' + q.a; d.appendChild(a); }
      if (oe && q.e) { var e = document.createElement('div'); e.className = 'pe'; e.textContent = mqFmt(q.e); d.appendChild(e); }
      P.appendChild(d);
    });
    math(P); setTimeout(function () { window.print(); }, 500);
  };
  chrome.storage.onChanged.addListener(function (ch, area) { if (area === 'local' && ch.mqSaved) { items = ch.mqSaved.newValue || []; render(); } });
  load(render);
})();
