// ===== Mock Helper: kisi bhi website par Gemini + Google button =====
// Tap = us page ka screenshot + question/options ka text + prompt -> Gemini / Google AI Mode ki ek hi window me (auto paste).
// ✂ = sirf question wala hissa chuno (area yaad bhi rakh sakte ho). Screenshot background.js se (captureVisibleTab).
(function () {
  if (window.__sdMockInit) return; window.__sdMockInit = 1;
  if (window.top !== window) return;                                   // sirf main page par
  var H = location.hostname || 'local';
  if (/^(gemini\.google\.com|www\.google\.[a-z.]+)$/.test(H)) return;  // Gemini / Google par khud button nahi

  var DEF_PROMPT = "मास्टर प्रॉम्प्ट: SSC यूनिवर्सल '4-प्रश्न सेट' (गणित, रीजनिंग और अंग्रेजी)\n\n1. मुख्य प्रश्न (Main Question):\n * प्रश्न का प्रारूप: छात्र द्वारा दिए गए पूरे प्रश्न को हमेशा द्विभाषी (Bilingual - अंग्रेजी और हिंदी दोनों) में लिखें। प्रश्न का कोई भी हिस्सा अधूरा न छोड़ें।\n * मूल अवधारणा (Basic Concept): प्रश्न की जड़ और पूरी थ्योरी को आसान हिंदी में समझाएं, ताकि बेसिक्स 100% क्लियर हो जाएं। (अंग्रेजी के प्रश्नों के लिए ग्रामर रूल या वोकैबुलरी का लॉजिक विस्तार से बताएं)।\n * स्मार्ट ट्रिक (Smart Trick): परीक्षा में 10-15 सेकंड में उत्तर निकालने का सबसे तेज़ तरीका बताएं (गणित/रीजनिंग के लिए शॉर्ट ट्रिक या सीधा सूत्र; अंग्रेजी के लिए ऑप्शन एलिमिनेशन या कीवर्ड एप्रोच)।\n\n2. समान पैटर्न अभ्यास (Same Pattern Practice - 1 प्रश्न):\n * मुख्य प्रश्न के बिल्कुल समान कॉन्सेप्ट और ट्रिक पर आधारित 1 नया प्रश्न बनाएं।\n * प्रश्न की भाषा: पूरा प्रश्न हमेशा द्विभाषी (अंग्रेजी + हिंदी) होना चाहिए।\n * विकल्प (Options): हमेशा पूरे विकल्प लिखें।\n   * नया नियम: यदि विकल्पों में केवल संख्याएँ (Numbers) हैं, तो उन्हें दो बार (जैसे 36373/36373) नहीं लिखना है, उन्हें केवल एक ही बार लिखें।\n   * यदि विकल्प पूरे वाक्य (Sentence) या वाक्यांश के रूप में हैं, तो उन्हें हिंदी और अंग्रेजी दोनों में दें।\n * समाधान (Solution): पूरा समाधान आसान हिंदी में लिखें। किसी भी कठिन शब्द के आगे ब्रैकेट में उसका अंग्रेजी अनुवाद जरूर लिखें (जैसे: समानांतर (Parallel))। समाधान में केवल शॉर्टकट ट्रिक का ही उपयोग करें।\n\n3. विविध/उन्नत पैटर्न अभ्यास (Diverse/Advanced Practice - 2 प्रश्न):\n * उसी टॉपिक को थोड़ा घुमाकर या उच्च स्तर (Tier-2 लेवल) पर पूछने वाले 2 अलग-अलग प्रश्न बनाएं।\n * प्रारूप: पूरा प्रश्न (द्विभाषी), पूरे विकल्प (संख्या केवल एक बार, वाक्य दोनों भाषाओं में), और समाधान (हिंदी में, कठिन शब्द ब्रैकेट में अंग्रेजी के साथ) का नियम बिल्कुल ऊपर दिए गए सेक्शन 2 जैसा ही रहेगा।\n\n4. शर्तें (Strict Constraints):\n * पूरी बातचीत और समाधान केवल और केवल शुद्ध देवनागरी हिंदी में होंगे।\n * कोई भी स्टेप, कैलकुलेशन या ग्रामर का लॉजिक हवा में नहीं किया जाएगा, हर एक चीज़ स्पष्ट और स्टेप-बाय-स्टेप होनी चाहिए।\n * हमेशा पूरा प्रश्न और पूरे विकल्प लिखें, कोई भी शॉर्टकट या अधूरा वाक्य न लिखें।\n * विकल्पों का नियम सख्ती से लागू करें: संख्या = केवल 1 बार लिखें, वाक्य = 2 भाषाएं (अंग्रेजी + हिंदी)।\n\nविकल्प:\n- हमेशा 4 विकल्प।\n- केवल संख्याएँ हों तो उन्हें सिर्फ 1 बार लिखें (जैसे 36373)। वाक्य हों तो English + हिंदी दोनों में।\n- गलत विकल्प (distractors) असली गलतियों से बनाएं: sign error, % बनाम भिन्न, यूनिट छूटना, आधा स्टेप।\n- सही उत्तर का अक्षर और मान दोनों लिखें।\n- सही विकल्प हर बार एक ही जगह (जैसे हमेशा B) न रखें।\n\nसमाधान:\n- आसान हिंदी में, कठिन शब्दों के English अनुवाद ब्रैकेट में।\n- शॉर्ट ट्रिक + स्टेप-बाय-स्टेप कैलकुलेशन।\n- गणित/रीजनिंग में सिर्फ सही उत्तर तक का हल दिखाएं, बाकी विकल्पों की व्याख्या न करें।\n\nहर नए प्रश्न के नीचे:\n🔍 ये प्रश्न किस कमजोरी को पकड़ता है? (एक लाइन)\n\n## 8. 📌 क्विक रिवीजन बॉक्स\nचारों प्रश्नों के बाद, कुल 3-4 लाइन में, ताकि छात्र सीधे शॉर्ट-नोट्स में लिख सके:\n\n📌 Quick Revision\n- Formula/Rule: ...\n- Golden Rule: ...\n- Keyword: ...\n- सबसे आम गलती: ...\n\n## 9. भाषा\n- पूरी व्याख्या शुद्ध देवनागरी हिंदी में।\n- प्रश्न द्विभाषी (English + हिंदी)।\n- तकनीकी शब्द (Ratio, Synonym आदि) हिंदी के साथ ब्रैकेट में English।\n- सभी चित्र/आरेख केवल text में।\n\n## 10. फॉर्मेटिंग (मोबाइल-फ्रेंडली)\n- टेबल बिल्कुल नहीं। छोटी लिस्ट और हेडिंग इस्तेमाल करें।\n- पूरा उत्तर मानक स्क्रीन चौड़ाई में फिट हो, हॉरिजॉन्टल स्क्रॉलिंग की जरूरत न पड़े।\n- लंबे समीकरण, कोड ब्लॉक और पैराग्राफ को छोटी पंक्तियों में तोड़ें।\n- हर नया स्टेप और लॉजिकल ब्रेक नई लाइन से शुरू करें।\n- कुछ भी स्क्रीन के किनारे से कटना नहीं चाहिए।\n\n## 11. अंतिम गुणवत्ता-जाँच (छापने से पहले, चुपचाप)\n- हर प्रश्न में 4 विकल्प हैं और सही उत्तर उनमें मौजूद है।\n- Q2-Q4 की सीढ़ी सही है और कोई प्रश्न Q1 की कॉपी नहीं है।\n- गणित/रीजनिंग में गलत विकल्पों की व्याख्या नहीं है।\n- कोई टेबल नहीं है और कोई लाइन कट नहीं रही।\n\n## 12. समापन\nउत्तर के अंत में एक लाइन:\n\"कॉन्सेप्ट न समझ आया हो तो बताइए, मैं और सरल उदाहरण से समझा दूँगा।\"";
  var DEF_CH = 'Math: Number System, HCF & LCM, Simplification & BODMAS, Square & Cube Root, Surds & Indices, Percentage, Ratio & Proportion, Partnership, Average, Ages, Mixture & Alligation, Profit & Loss, Discount, Simple Interest, Compound Interest, Time & Work, Pipes & Cisterns, Time, Speed & Distance, Trains, Boats & Streams, Algebra, Quadratic & Polynomials, Coordinate Geometry, Triangle (त्रिभुज), Circle (वृत्त), Quadrilateral & Polygon, Lines & Angles, Mensuration 2D, Mensuration 3D, Trigonometry, Heights & Distances, Permutation & Probability, Statistics, Data Interpretation, Inequalities & Sets, Other\nReasoning: Analogy, Classification (Odd One), Number Series, Alphabet Series, Coding-Decoding, Blood Relations, Direction & Distance, Ranking & Order, Syllogism, Venn Diagram, Mirror Image, Water Image, Paper Folding & Cutting, Embedded Figures, Counting Figures, Figure Series, Dice & Cube, Calendar, Clock, Seating Arrangement, Puzzle, Mathematical Operations, Missing Number, Statement & Conclusion, Inequality, Word Formation, Letter-Number Test, Other\nEnglish: Noun & Pronoun, Verb & Tenses, Subject-Verb Agreement, Articles, Adjective & Adverb, Prepositions, Conjunctions, Modals & Conditionals, Active/Passive, Direct/Indirect, Error Spotting, Fill in the Blanks, Sentence Improvement, Synonyms, Antonyms, Idioms & Phrases, One Word Substitution, Spelling, Homonyms & Homophones, Phrasal Verbs, Para Jumbles, Cloze Test, Reading Comprehension, Vocabulary, Other\nGK: Ancient History, Medieval History, Modern History, Indian Polity, Indian Geography, World Geography, Physical Geography, Economy, Physics, Chemistry, Biology, Environment & Ecology, Art & Culture, Static GK, Sports, Important Days & Books, Current Affairs, Computer, Science & Technology, Organisations & Reports, Other';
  var CFG = { auto: true, prompt: '', gp: '', op: '', chs: '', isz: 800, text: true, image: true, fixed: false, gurl: '', ourl: '', hidden: false, pos: null, area: null, min: true };
  var host = null, sh = null, bar = null, toastEl = null, busy = false;

  function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

  // ---------- settings (har site ki alag: hidden/pos/area/fixed; prompt + text/image sabke liye ek) ----------
  function load(cb) {
    try {
      chrome.storage.local.get(['mockGlobal', 'mockSites'], function (o) {
        var g = (o && o.mockGlobal) || {}, s = ((o && o.mockSites) || {})[H] || {};
        if (typeof g.prompt === 'string') CFG.prompt = (g.prompt.trim().indexOf('Tum ek expert SSC') === 0) ? '' : g.prompt;
        if (typeof g.auto === 'boolean') CFG.auto = g.auto; if (typeof g.chs === 'string') CFG.chs = g.chs; if (typeof g.gp === 'string') CFG.gp = g.gp; if (typeof g.op === 'string') CFG.op = g.op; if (typeof g.iz === 'number') CFG.isz = g.iz;
        if (typeof g.text === 'boolean') CFG.text = g.text;
        if (typeof g.image === 'boolean') CFG.image = g.image;
        if (typeof g.gurl === 'string') CFG.gurl = g.gurl; if (typeof g.ourl === 'string') CFG.ourl = g.ourl;
        ['fixed', 'min'].forEach(function (k) { if (typeof s[k] === 'boolean') CFG[k] = s[k]; });
        CFG.pos = g.pos || s.pos || null; CFG.area = s.area || null;
        cb();
      });
    } catch (e) { cb(); }
  }
  function saveG() { try { chrome.storage.local.set({ mockGlobal: { auto: CFG.auto, prompt: CFG.prompt, chs: CFG.chs, gp: CFG.gp, op: CFG.op, iz: CFG.isz, text: CFG.text, image: CFG.image, gurl: CFG.gurl, ourl: CFG.ourl, pos: CFG.pos } }); } catch (e) {} }
  function saveS() {
    try {
      chrome.storage.local.get('mockSites', function (o) {
        var a = (o && o.mockSites) || {};
        a[H] = { hidden: false, fixed: CFG.fixed, min: CFG.min, pos: CFG.pos, area: CFG.area };
        chrome.storage.local.set({ mockSites: a });
      });
    } catch (e) {}
  }

  // ---------- UI ----------
  var CSS =
    ':host{all:initial}*{box-sizing:border-box;font-family:system-ui,-apple-system,"Segoe UI",Roboto,"Noto Sans Devanagari",sans-serif}' +
    '#bar{position:fixed;right:8px;top:10%;display:flex;flex-direction:column;gap:6px;padding:7px;border-radius:16px;background:rgba(20,22,27,.92);box-shadow:0 4px 16px rgba(0,0,0,.45);user-select:none;-webkit-user-select:none;touch-action:none;z-index:1}' +
    '#bar.min{padding:0;background:none;box-shadow:none;gap:0}' +
    '#bar.min>*:not(#dot){display:none!important}' +
    '#dot{display:none;width:40px;height:40px;border-radius:50%;background:#6a4cff;color:#fff;font:700 19px/40px sans-serif;text-align:center;cursor:pointer;opacity:.55;box-shadow:0 2px 8px rgba(0,0,0,.4)}' +
    '#dot:hover{opacity:1}#bar.min #dot{display:block}' +
    '#grip{cursor:grab;color:#9aa0a6;text-align:center;font-size:13px;line-height:12px;letter-spacing:2px;padding:2px 0}' +
    'button{border:0;border-radius:13px;padding:14px 16px;font-size:16.5px;font-weight:800;color:#fff;cursor:pointer;white-space:nowrap}' +
    'button:active{transform:scale(.96)}button[disabled]{opacity:.5}' +
    '.g{background:#6a4cff}.o{background:#1a73e8}.d{background:#00897b}.s{background:#2e7d32;font-size:14px}.x{background:#444;font-size:15px;padding:11px 13px}' +
    '.row{display:flex;gap:6px}.row>button{flex:1}' +
    '#info{font-size:10.5px;color:#cfd3d8;text-align:center;max-width:120px;line-height:1.25}' +
    '#by{font-size:9.5px;font-weight:800;text-align:center;max-width:120px;line-height:1.2;background:linear-gradient(90deg,#ff6ec4,#ffb84d,#4de1ff);-webkit-background-clip:text;background-clip:text;color:transparent}' +
    '#toast{position:fixed;left:50%;bottom:78px;transform:translateX(-50%);background:#202124;color:#fff;padding:9px 14px;border-radius:12px;font-size:13.5px;max-width:88vw;text-align:center;display:none;z-index:5;box-shadow:0 3px 12px rgba(0,0,0,.5)}' +
    '#pan{position:fixed;right:8px;top:8px;max-height:calc(100vh - 16px);overflow-y:auto;width:min(340px,94vw);background:#1b1d22;color:#eee;border-radius:14px;padding:0 12px 12px;font-size:13px;display:none;z-index:6;box-shadow:0 6px 24px rgba(0,0,0,.6)}' +
    '#pan .ph{position:sticky;top:0;background:#1b1d22;padding:10px 0 8px;display:flex;gap:6px;align-items:center;z-index:1}#pan .ph h4{margin:0;flex:1}#pan .ph button{padding:9px 14px;font-size:14px}#pan textarea{width:100%;height:110px;background:#0f1013;color:#eee;border:1px solid #3a3d44;border-radius:8px;padding:7px;font-size:12px;resize:vertical}' +
    '#pan label{display:flex;gap:7px;align-items:center;margin:7px 0;cursor:pointer}#pan h4{margin:0 0 8px;font-size:14px}' +
    '#sel{position:fixed;inset:0;cursor:crosshair;background:rgba(0,0,0,.25);display:none;z-index:10;touch-action:none}' +
    '#rect{position:fixed;border:2px solid #7c4dff;background:rgba(124,77,255,.18);display:none;z-index:11;pointer-events:none}' +
    '#hint{position:fixed;top:10px;left:50%;transform:translateX(-50%);background:#202124;color:#fff;padding:7px 13px;border-radius:10px;font-size:13px;display:none;z-index:12;pointer-events:none}' +
    '#chips{position:fixed;display:none;gap:6px;z-index:12;padding:6px;border-radius:12px;background:rgba(20,22,27,.95);box-shadow:0 3px 12px rgba(0,0,0,.5)}';

  function build() {
    host = document.createElement('div'); host.id = 'sd-mock-host';
    host.style.cssText = 'all:initial;position:fixed;z-index:2147483647;left:0;top:0;width:0;height:0';
    sh = host.attachShadow({ mode: 'open' });
    sh.innerHTML = '<style>' + CSS + '</style>' +
      '<div id="bar"><div id="dot" title="Gemini / Google bar kholo">✨</div><div id="grip" title="Pakad ke hilao">⋮⋮⋮</div>' +
      '<button class="g" id="bg" title="Page screenshot + question text + prompt -> Gemini (Alt+G)">✨ Gemini</button>' +
      '<button class="o" id="bo" title="Page screenshot + question text + prompt -> Google AI Mode (Alt+S)">🔍 Google</button>' +
      '<button class="d" id="bd" title="Dark / Light, font size, font, text + background color (Dark Reader + A+ jaisa)">🎨 Look</button>' +
      '<div class="row"><button class="s" id="bs" title="Sirf question wala hissa chuno">✂ Area</button><button class="x" id="bv" title="Saved questions kholo">📂</button><button class="x" id="bc" title="Settings / prompt">⚙</button><button class="x" id="bm" title="Chhota karo">–</button></div>' +
      '<div id="info"></div><div id="by">Made by Yuvraj Sisodiya</div></div>' +
      '<div id="pan"></div><div id="toast"></div>' +
      '<div id="sel"></div><div id="rect"></div><div id="hint">Question wala hissa drag karke chuno (Esc = cancel)</div>' +
      '<div id="chips"><button class="g" data-c="g">✨ Gemini</button><button class="o" data-c="o">🔍 Google</button><button class="s" data-c="a">📐 Area yaad rakho</button><button class="x" data-c="x">✕</button></div>';
    bar = sh.getElementById('bar'); toastEl = sh.getElementById('toast');
    (document.documentElement || document.body).appendChild(host);
    wire(); place(); render();
  }
  function $(id) { return sh.getElementById(id); }
  function toast(m, ms) { toastEl.textContent = m; toastEl.style.display = 'block'; clearTimeout(toastEl._t); toastEl._t = setTimeout(function () { toastEl.style.display = 'none'; }, ms || 3200); }
  function render() {
    bar.classList.toggle('min', !!CFG.min); setTimeout(fit, 0);
    host.style.display = CFG.hidden ? 'none' : 'block';
    $('info').textContent = (CFG.fixed && CFG.area) ? '📐 Fixed area ON' : 'Poora screen';
  }
  function fit() { var r = bar.getBoundingClientRect(); if (r.bottom > innerHeight - 6) bar.style.top = Math.max(4, innerHeight - r.height - 6) + 'px'; if (r.top < 0) bar.style.top = '4px'; }
  function place() {
    if (CFG.pos) { var w = bar.offsetWidth || 60; bar.style.left = Math.max(-(w - 36), Math.min(innerWidth - 36, CFG.pos.x)) + 'px'; bar.style.top = Math.max(0, Math.min(innerHeight - 36, CFG.pos.y)) + 'px'; bar.style.right = 'auto'; }
  }

  // ---------- drag (grip / dot) ----------
  function dragify(handle) {
    handle.addEventListener('pointerdown', function (e) {
      if (e.button !== undefined && e.button !== 0) return;
      var r = bar.getBoundingClientRect(), dx = e.clientX - r.left, dy = e.clientY - r.top, moved = false, sx = e.clientX, sy = e.clientY;
      function mv(ev) {
        if (!moved && Math.abs(ev.clientX - sx) + Math.abs(ev.clientY - sy) > 6) { moved = true; try { handle.setPointerCapture(e.pointerId); } catch (x) {} }
        if (!moved) return;
        ev.preventDefault();
        var w = bar.offsetWidth || 60;
        bar.style.right = 'auto';
        bar.style.left = Math.max(-(w - 36), Math.min(innerWidth - 36, ev.clientX - dx)) + 'px';
        bar.style.top = Math.max(0, Math.min(innerHeight - 36, ev.clientY - dy)) + 'px';
      }
      function up() {
        handle.removeEventListener('pointermove', mv); handle.removeEventListener('pointerup', up); handle.removeEventListener('pointercancel', up);
        try { handle.releasePointerCapture(e.pointerId); } catch (x) {}
        if (moved) { var b = bar.getBoundingClientRect(); CFG.pos = { x: b.left, y: b.top }; saveG(); saveS(); bar._moved = true; setTimeout(function () { bar._moved = false; }, 80); }
      }
      handle.addEventListener('pointermove', mv); handle.addEventListener('pointerup', up); handle.addEventListener('pointercancel', up);
    });
    // drag ke baad galti se button click na ho
    handle.addEventListener('click', function (e) { if (bar._moved) { e.stopPropagation(); e.preventDefault(); } }, true);
  }

  // ---------- text nikalna (screen ya chuna hua area) ----------
  var SKIP = 'script,style,noscript,template,svg,canvas,select,option,.katex-mathml,mjx-assistive-mml,.MJX_Assistive_MathML,.sr-only,.visually-hidden';
  function collectText(doc, rect, ox, oy, out, depth) {
    var w = doc.createTreeWalker(doc.body || doc.documentElement, NodeFilter.SHOW_TEXT, null), n, lastBlk = null, buf = '';
    var rg = doc.createRange();
    function blockOf(el) {
      while (el && el.nodeType === 1) {
        var d = (doc.defaultView.getComputedStyle(el).display || '');
        if (d.indexOf('inline') !== 0 && d !== 'contents') return el;
        el = el.parentElement;
      }
      return null;
    }
    while ((n = w.nextNode())) {
      var t = n.nodeValue; if (!t || !t.trim()) continue;
      var p = n.parentElement; if (!p) continue;
      if (host && host.contains(p)) continue;
      try { if (p.closest(SKIP)) continue; } catch (e) {}
      rg.selectNodeContents(n);
      var rs = rg.getClientRects(), hit = false, i;
      for (i = 0; i < rs.length; i++) {
        var r = rs[i]; if (r.width < 1.5 || r.height < 1.5) continue;
        var cx = ox + r.left + r.width / 2, cy = oy + r.top + r.height / 2;
        if (cx >= rect.l && cx <= rect.r && cy >= rect.t && cy <= rect.b) { hit = true; break; }
      }
      if (!hit) continue;
      var cs = doc.defaultView.getComputedStyle(p);
      if (cs.visibility === 'hidden' || cs.display === 'none' || parseFloat(cs.opacity) === 0) continue;
      var blk = blockOf(p);
      var piece = t.replace(/\s+/g, ' ');
      if (buf && blk !== lastBlk) buf += '\n'; else if (buf && !/\s$/.test(buf) && !/^\s/.test(piece)) buf += '';
      buf += piece; lastBlk = blk;
    }
    out.push(buf);
    // same-origin iframe ke andar ka text bhi
    if (depth < 3) {
      var fr = doc.querySelectorAll('iframe,frame');
      for (var k = 0; k < fr.length; k++) {
        try {
          var d2 = fr[k].contentDocument; if (!d2 || !d2.body) continue;
          var b = fr[k].getBoundingClientRect();
          collectText(d2, rect, ox + b.left, oy + b.top, out, depth + 1);
        } catch (e) {}
      }
    }
  }
  function getText(rect) {
    var out = [];
    try { collectText(document, rect, 0, 0, out, 0); } catch (e) {}
    var s = out.join('\n').replace(/[ \t]+\n/g, '\n').replace(/\n[ \t]+/g, '\n').replace(/[ \t]{2,}/g, ' ').replace(/\n{3,}/g, '\n\n').trim();
    return s.length > 9000 ? s.slice(0, 9000) + '…' : s;
  }

  // ---------- screenshot ----------
  function capture() {
    return new Promise(function (res, rej) {
      try {
        chrome.runtime.sendMessage({ cmd: 'mockCapture' }, function (r) {
          var le = chrome.runtime.lastError;
          if (le || !r || !r.ok) return rej(new Error((r && r.err) || (le && le.message) || 'capture fail'));
          res(r.data);
        });
      } catch (e) { rej(e); }
    });
  }
  function loadImg(src) { return new Promise(function (res, rej) { var i = new Image(); i.onload = function () { res(i); }; i.onerror = rej; i.src = src; }); }
  async function shot(rect) {
    var full = await capture(), img = await loadImg(full);
    var sx = img.naturalWidth / innerWidth, sy = img.naturalHeight / innerHeight;
    var x = Math.round(rect.l * sx), y = Math.round(rect.t * sy), w = Math.round((rect.r - rect.l) * sx), h = Math.round((rect.b - rect.t) * sy);
    x = Math.max(0, x); y = Math.max(0, y); w = Math.max(10, Math.min(img.naturalWidth - x, w)); h = Math.max(10, Math.min(img.naturalHeight - y, h));
    var k = Math.min(1, (CFG.isz || 800) / Math.max(w, h));
    var cv = document.createElement('canvas'); cv.width = Math.round(w * k); cv.height = Math.round(h * k);
    var cx = cv.getContext('2d'); cx.fillStyle = '#fff'; cx.fillRect(0, 0, cv.width, cv.height); cx.drawImage(img, x, y, w, h, 0, 0, cv.width, cv.height);
    return cv.toDataURL('image/jpeg', (CFG.isz || 800) <= 800 ? 0.6 : 0.72);
  }

  // ---------- bhejna ----------
  function geo() {
    var sl = screen.availLeft || 0, st = screen.availTop || 0, sw = screen.availWidth || screen.width, sh2 = screen.availHeight || screen.height, w = Math.round(sw / 2);
    return { l: sl + w, t: st, w: w, h: sh2 };
  }
  function viewRect() { return { l: 0, t: 0, r: innerWidth, b: innerHeight }; }
  function areaRect() {
    var a = CFG.area; if (!(CFG.fixed && a)) return viewRect();
    return { l: a.x * innerWidth, t: a.y * innerHeight, r: (a.x + a.w) * innerWidth, b: (a.y + a.h) * innerHeight };
  }
  async function send(target, rect) {
    if (busy) return; busy = true;
    var isG = target === 'google', label = isG ? 'Google' : 'Gemini';
    try {
      rect = rect || areaRect();
      toast('📸 Screenshot ban raha hai…', 6000);
      var hadHost = host.style.display; host.style.display = 'none'; try { window.dispatchEvent(new Event('sd-pen-hide')); } catch (e) {}
      await Promise.race([new Promise(function (r) { requestAnimationFrame(function () { requestAnimationFrame(r); }); }), sleep(80)]);   // bar chhupne ka ek frame (pehle 120ms)
      var du = '', qt = '';
      try {
        if (CFG.text) qt = getText(rect);
        if (CFG.image) du = await shot(rect);
      } finally { host.style.display = hadHost; try { window.dispatchEvent(new Event('sd-pen-show')); } catch (e) {} }
      var prompt = ((isG ? CFG.op : CFG.gp) || CFG.prompt || '').trim() || DEF_PROMPT;
      if (prompt.indexOf('---MOCKBANK---') < 0) prompt += "\n\n=== MOCK BANK BLOCK (bahut zaroori: sabse END mein, bilkul isi format mein. POORA block ---MOCKBANK--- se ---END--- tak EK HI code block (``` ... ```) ke andar likho, taaki maths render hokar bikhre nahi; code block ke andar plain text, bold/table ke bina) ===\n---MOCKBANK---\nSUBJECT: Math ya English ya Reasoning ya GK (koi ek)\nCHAPTER: <is question ka SAHI chapter, neeche di list me se HUBAHU wahi naam; list me na ho to sabse paas ka chapter>\nQ: <poora question. SUBJECT Math/Reasoning/GK ho to Hindi + English dono; lekin SUBJECT English ho to question aur options SIRF English mein (Hindi bilkul nahi); maths LaTeX \\( ... \\) mein>\nA) <option>\nB) <option>\nC) <option>\nD) <option>\nANS: <A ya B ya C ya D>\nEXP: <POORA DETAILED solution, upar ke jawab jaisa. HAR section aur HAR step ALAG NAYI LINE par likho, ek lambi line mein mat jodo. Is order mein:\nमूल अवधारणा (Basic Concept): ...\nस्मार्ट ट्रिक (Smart Trick): ...\nस्टेप 1: ...\nस्टेप 2: ...\nअतः उत्तर: ...\nगलत विकल्प: ...\nSaari maths/formula LaTeX mein \\( ... \\) ke andar likho, jaise \\(x=\\sqrt{45\\times 20}=30\\), \\(\\frac{a}{b}\\) — sqrt(...) ya * jaisa plain text mat likho. Koi line 'Q:', 'ANS:', 'EXP:' ya 'SUBJECT:' se shuru na ho>\n(is block mein jawab ke SAARE questions likho: main question + same pattern wala practice question + diverse/advanced wale dono questions = kul 4 (ya jitne bhi bane). Har question ke liye alag-alag poora set: Q:, A) B) C) D), ANS:, EXP: — ek ke baad ek, bina kisi question ko chhode. Har question ka EXP poora detailed aur line-wise; har question 'Q:' se shuru ho aur ek question ke liye sirf ek hi 'Q:' block ho. SUBJECT sirf ek baar block ke shuru mein likho, lekin HAR question ke Q: se bilkul pehle uski apni 'CHAPTER:' line zaroor likho (practice questions ka chapter bhi wahi jo us question ka asli topic ho).\nChapter list (CHAPTER me inhi me se naam likho):\n" + (CFG.chs || DEF_CH).replace(/\n/g, '\\n') + "\n Practice questions ke options mein number ek hi baar, aur Math/Reasoning/GK mein question Hindi + English dono)\n---END---";
      var text = prompt + (qt ? '\n\n--- Question (text) ---\n' + qt : '');
      if (!du && !qt) { toast('⚠ Kuch bhejne ko nahi mila (settings me image/text ON rakho)'); return; }
      var msg = { cmd: isG ? 'sendG' : 'send', image: du, text: text.slice(0, 12000), url: isG ? (CFG.ourl || 'https://www.google.com/search?udm=50') : (CFG.gurl || 'https://gemini.google.com/app'), custom: !!(isG ? CFG.ourl : CFG.gurl), geo: geo() };
      var reply = await new Promise(function (res) {
        var done = false, tm = setTimeout(function () { if (!done) { done = true; res(null); } }, 6000);
        try { chrome.runtime.sendMessage(msg, function (r) { void chrome.runtime.lastError; if (!done) { done = true; clearTimeout(tm); res(r || null); } }); } catch (e) { clearTimeout(tm); res(null); }
      });
      if (reply === null) { fallbackCopy(du, text, label); return; }
      toast(reply.found ? ('📎 Screenshot + question + prompt ' + label + ' ko bhej diya') : (label + ' khul raha hai — wahan paste ho jayega'), 3800);
    } catch (e) {
      var em = (e && e.message) ? e.message : String(e);
      if (/context invalidated|receiving end|Extension context/i.test(em)) {
        // extension reload/update hua, ye purani script orphan hai — prompt copy + refresh ka clear msg
        try { if (typeof text !== 'undefined' && text) navigator.clipboard.writeText(text); } catch (x) {}
        toast('🔄 Extension update/reload hua — is page ko ek baar F5 se refresh karo (prompt copy ho gaya)', 7000);
      } else toast('⚠ ' + em, 5000);
    } finally { busy = false; }
  }
  function fallbackCopy(du, text, label) {
    try {
      navigator.clipboard.writeText(text).then(function () { toast('⚠ Extension ne jawab nahi diya — prompt copy ho gaya, ' + label + ' me Ctrl+V karo (extension reload karo)', 6000); }, function () { toast('⚠ Extension ne jawab nahi diya — extension reload karo', 6000); });
    } catch (e) { toast('⚠ Extension ne jawab nahi diya — extension reload karo', 6000); }
  }

  // ---------- area chunna ----------
  function selectArea(after) {
    var sel = $('sel'), rc = $('rect'), hint = $('hint'), chips = $('chips'), x0 = 0, y0 = 0, drag = false, cur = null;
    sel.style.display = 'block'; hint.style.display = 'block'; rc.style.display = 'none'; chips.style.display = 'none';
    function end() { sel.style.display = 'none'; rc.style.display = 'none'; hint.style.display = 'none'; chips.style.display = 'none'; sel.onpointerdown = sel.onpointermove = sel.onpointerup = null; document.removeEventListener('keydown', kd, true); chips.onclick = null; }
    function kd(e) { if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); end(); } }
    document.addEventListener('keydown', kd, true);
    function draw(x1, y1, x2, y2) {
      var l = Math.min(x1, x2), t = Math.min(y1, y2), w = Math.abs(x2 - x1), h = Math.abs(y2 - y1);
      rc.style.display = 'block'; rc.style.left = l + 'px'; rc.style.top = t + 'px'; rc.style.width = w + 'px'; rc.style.height = h + 'px';
      return { l: l, t: t, r: l + w, b: t + h };
    }
    sel.onpointerdown = function (e) { e.preventDefault(); drag = true; x0 = e.clientX; y0 = e.clientY; chips.style.display = 'none'; try { sel.setPointerCapture(e.pointerId); } catch (x) {} draw(x0, y0, x0, y0); };
    sel.onpointermove = function (e) { if (drag) cur = draw(x0, y0, e.clientX, e.clientY); };
    sel.onpointerup = function (e) {
      if (!drag) return; drag = false; cur = draw(x0, y0, e.clientX, e.clientY);
      if (cur.r - cur.l < 25 || cur.b - cur.t < 25) { rc.style.display = 'none'; toast('Area bahut chhota hai, dobara drag karo'); return; }
      hint.style.display = 'none'; chips.style.display = 'flex';
      var cw = 330, cl = Math.max(6, Math.min(innerWidth - cw - 6, cur.l)), ct = cur.b + 10; if (ct > innerHeight - 56) ct = Math.max(6, cur.t - 54);
      chips.style.left = cl + 'px'; chips.style.top = ct + 'px';
    };
    chips.onclick = function (e) {
      var b = e.target.closest('button'); if (!b || !cur) return; var c = b.getAttribute('data-c'), r = cur; end();
      if (c === 'x') return;
      if (c === 'a') { CFG.area = { x: r.l / innerWidth, y: r.t / innerHeight, w: (r.r - r.l) / innerWidth, h: (r.b - r.t) / innerHeight }; CFG.fixed = true; saveS(); render(); toast('📐 Area yaad ho gaya — ab har baar yahi hissa jayega (⚙ se band kar sakte ho)'); return; }
      send(c === 'g' ? 'gemini' : 'google', r);
    };
  }

  // ---------- settings panel ----------
  function openPanel() {
    var p = $('pan');
    if (p.style.display === 'block') { p.style.display = 'none'; return; }
    p.innerHTML = '<div class=ph><h4>⚙ Mock Helper <span style="font-size:10.5px;font-weight:700;color:#ffb84d">· Made by Yuvraj Sisodiya</span></h4><button class=s id=ps>Save</button><button class=x id=px>✕</button></div>' +
      '<label><input type="checkbox" id="pi"> Screenshot bhejo</label>' +
      '<label><input type="checkbox" id="pt"> Question + options ka text bhi bhejo</label>' +
      '<label><input type="checkbox" id="pa"> 🚀 Gemini me auto-send (Enter apne aap)</label>' +
      '<label><input type="checkbox" id="pf"> 📐 Fixed area (is site ke liye yaad rakha hua)</label>' +
      '<div style="margin:8px 0 4px;font-weight:700">Gemini URL (khali = default; apna Gem/chat link):</div><input id="pg" placeholder="https://gemini.google.com/gem/..." style="width:100%;padding:7px;border-radius:8px;border:1px solid #3a3d44;background:#0f1013;color:#eee;font-size:12px">' +
      '<div style="margin:8px 0 4px;font-weight:700">Google URL (khali = AI Mode):</div><input id="po" placeholder="https://www.google.com/search?udm=50" style="width:100%;padding:7px;border-radius:8px;border:1px solid #3a3d44;background:#0f1013;color:#eee;font-size:12px">' +
      '<div style="margin:8px 0 4px;font-weight:700">Image size (chhota = fast upload):</div><select id="pz" style="width:100%;padding:7px;border-radius:8px;border:1px solid #3a3d44;background:#0f1013;color:#eee;font-size:12px"><option value="640">🚀 Ultra fast (640px)</option><option value="800">⚡ Fast (800px)</option><option value="1100">Normal (1100px)</option><option value="1500">Clear (1500px)</option></select>' +
      '<div style="margin:8px 0 4px;font-weight:700">📚 Chapter list (app ke chapter naam; har subject ki alag line):</div><textarea id="pc" style="height:90px"></textarea><button class="x" id="pcr" style="margin-top:4px">Chapter list: default</button>' +
      '<div style="margin:8px 0 4px;font-weight:700">✨ Gemini ka prompt:</div><textarea id="pp"></textarea><button class="x" id="pr1" style="margin-top:4px">Gemini: default prompt</button>' +
      '<div style="margin:8px 0 4px;font-weight:700">🔍 Google ka prompt:</div><textarea id="pq"></textarea><button class="x" id="pr2" style="margin-top:4px">Google: default prompt</button>' +
      '<div class="row" style="margin-top:8px"><button class="x" id="ph">Is site par chhupao</button></div>' +
      '<div style="margin-top:8px;font-size:11.5px;color:#aab">Shortcut: Alt+G = Gemini, Alt+S = Google. Bar wapas lane ke liye: page par right-click → "Gemini/Google bar: is site par dikhao/chhupao".</div>';
    p.style.display = 'block';
    $('pa').checked = CFG.auto; $('pi').checked = CFG.image; $('pt').checked = CFG.text; $('pf').checked = !!(CFG.fixed && CFG.area); $('pp').value = CFG.gp || CFG.prompt || DEF_PROMPT; $('pq').value = CFG.op || CFG.prompt || DEF_PROMPT; $('pz').value = String(CFG.isz || 800); $('pc').value = CFG.chs || DEF_CH; $('pg').value = CFG.gurl; $('po').value = CFG.ourl;
    $('pf').onchange = function () { if ($('pf').checked && !CFG.area) { $('pf').checked = false; toast('Pehle ✂ Area se hissa chuno'); } };
    $('ps').onclick = function () {
      CFG.auto = $('pa').checked; CFG.image = $('pi').checked; CFG.text = $('pt').checked; CFG.fixed = $('pf').checked && !!CFG.area;
      var gv = $('pg').value.trim(), ov = $('po').value.trim();
      if (gv && !/^https:\/\/gemini\.google\.com\//.test(gv)) { toast('⚠ Gemini URL https://gemini.google.com/ se shuru hona chahiye'); return; }
      if (ov && !/^https:\/\/www\.google\.[a-z.]+\//.test(ov)) { toast('⚠ Google URL https://www.google.com/ se shuru hona chahiye'); return; }
      CFG.gurl = gv; CFG.ourl = ov;
      var v1 = $('pp').value.trim(), v2 = $('pq').value.trim(); CFG.gp = (v1 === DEF_PROMPT.trim()) ? '' : v1; CFG.op = (v2 === DEF_PROMPT.trim()) ? '' : v2; var cv = $('pc').value.trim(); CFG.chs = (cv === DEF_CH.trim()) ? '' : cv; CFG.prompt = ''; CFG.isz = parseInt($('pz').value, 10) || 800;
      saveG(); saveS(); render(); p.style.display = 'none'; toast('✅ Save ho gaya');
    };
    $('px').onclick = function () { p.style.display = 'none'; };
    $('pcr').onclick = function () { $('pc').value = DEF_CH; };
    $('pr1').onclick = function () { $('pp').value = DEF_PROMPT; };
    $('pr2').onclick = function () { $('pq').value = DEF_PROMPT; };
    $('ph').onclick = function () { CFG.hidden = true; saveS(); render(); p.style.display = 'none'; };
  }

  function wire() {
    dragify(bar);
    $('dot').addEventListener('click', function () { if (bar._moved) return; CFG.min = false; saveS(); render(); });
    $('bm').onclick = function () { CFG.min = true; $('pan').style.display = 'none'; saveS(); render(); };
    $('bg').onclick = function () { send('gemini'); };
    $('bo').onclick = function () { send('google'); };
    $('bd').onclick = function () { try { if (window.__ldk) window.__ldk.toggle(); else toast('⚠ Look script is page par load nahi hua — extension reload karke page refresh (F5) karo', 6000); } catch (e) { toast('⚠ Look error: ' + e.message, 6000); } };
    $('bs').onclick = function () { selectArea(); };
    $('bc').onclick = openPanel;
    $('bv').onclick = function () { try { chrome.runtime.sendMessage({ cmd: 'mqOpen' }); } catch (e) {} };
    function cnt() { try { chrome.storage.local.get('mqSaved', function (o) { void chrome.runtime.lastError; var L = (o && o.mqSaved) || [], n = L.filter(function (q) { return !q.synced; }).length; $('bv').textContent = '📂 ' + L.length + (n ? ' · ' + n + ' naye' : ''); }); } catch (e) {} }
    cnt(); try { chrome.storage.onChanged.addListener(function (ch, a) { if (a === 'local' && ch.mqSaved) cnt(); }); } catch (e) {}
    // page ke click/keys par asar na pade
    ['keydown', 'keyup', 'keypress'].forEach(function (t) { sh.addEventListener(t, function (e) { e.stopPropagation(); }); });
  }

  document.addEventListener('keydown', function (e) {
    if (!host || CFG.hidden || !e.altKey || e.ctrlKey || e.metaKey) return;
    var k = (e.key || '').toLowerCase();
    if (k === 'g') { e.preventDefault(); send('gemini'); }
    else if (k === 's') { e.preventDefault(); send('google'); }
  }, true);

  chrome.runtime.onMessage.addListener(function (m, s, reply) {
    if (m && m.cmd === 'mock-toggle') { if (host) { CFG.hidden = !CFG.hidden; if (!CFG.hidden) CFG.min = false; saveS(); render(); } reply({ ok: true, hidden: CFG.hidden }); }
  });

  // CGL app (jahan apne handles hain) par dobara button nahi
  function appCheck() { if (!host) return; host.style.display = CFG.hidden ? 'none' : 'block'; }

  window.addEventListener('resize', function () { if (bar) { place(); fit(); } });

  function start() {
    if (host) return;
    load(function () {
      if (!document.documentElement) return;
      build(); setInterval(function () { if (!document.hidden) appCheck(); }, 3000);
      // kuch sites DOM replace kar deti hain: host gayab ho to wapas lagao
      setInterval(function () { if (!document.hidden && host && !host.isConnected) (document.documentElement || document.body).appendChild(host); }, 3000);
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
})();
