(function () {
if (window.__sdGemInit) return; window.__sdGemInit = 1;
var busy = false;
function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
function norm(s) { return String(s || '').replace(/\s+/g, ' ').trim(); }
function curText(ed) { return ed ? (('value' in ed && ed.tagName !== 'DIV') ? ed.value : (ed.innerText || ed.textContent || '')) : ''; }
// Text daalo, phir check karo ki sach mein gaya; nahi gaya to doosre tareeke se dobara (3 koshish)
async function putText(getEd, text) {
  var probe = norm(text).slice(0, 40), tail = norm(text).slice(-25);
  for (var i = 0; i < 4; i++) {
    var ed = getEd(); if (!ed) { await sleep(500); continue; }
    var have = norm(curText(ed));
    if (have.indexOf(probe) >= 0 && have.indexOf(tail) >= 0) return true;      // pehle se hai
    ed.focus();
    var isInput = ed.tagName === 'TEXTAREA' || ed.tagName === 'INPUT';
    try {
      if (i === 0 && !isInput) {
        var dt0 = new DataTransfer(); dt0.setData('text/plain', text);
        ed.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt0, bubbles: true, cancelable: true }));
      } else if (i === 1) {
        if (isInput) {
          var proto = ed.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
          Object.getOwnPropertyDescriptor(proto, 'value').set.call(ed, text);
          ed.dispatchEvent(new Event('input', { bubbles: true }));
        } else {
          var sel = window.getSelection(), r = document.createRange(); r.selectNodeContents(ed); sel.removeAllRanges(); sel.addRange(r);
          document.execCommand('insertText', false, text);
        }
      } else if (i === 2) {
        var dt = new DataTransfer(); dt.setData('text/plain', text);
        ed.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true }));
      } else {
        if (isInput) { ed.value = text; } else { ed.textContent = text; }
        ed.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: text }));
      }
    } catch (x) {}
    for (var w = 0; w < 14; w++) {
      await sleep(40);
      have = norm(curText(getEd() || ed));
      if (have.indexOf(probe) >= 0 && have.indexOf(tail) >= 0) return true;
    }
  }
  return false;
}


function findEditor() {
  return document.querySelector('rich-textarea .ql-editor, div.ql-editor[contenteditable="true"], div[contenteditable="true"][role="textbox"], div[contenteditable="true"]');
}
function waitFor(fn, ms) {
  return new Promise(function (res) {
    var t0 = Date.now();
    (function tick() { var v = fn(); if (v) return res(v); if (Date.now() - t0 > ms) return res(null); setTimeout(tick, 40); })();
  });
}
// Image attach hua ya nahi: jaise hi koi naya image/preview dikhe turant aage (nahi dikha to max wait tak ruko — pehle jaisa safe)
function attachCount(ed) {
  var n = 0, root = ed;
  try { for (var k = 0; k < 9 && root.parentElement; k++) root = root.parentElement; n += root.querySelectorAll('img,canvas,[data-attachment],[aria-label*="mage" i],uploader-file-preview,file-preview,[data-test-id*="preview"],button[aria-label*="emove" i]').length; } catch (e) {}
  try { n += document.querySelectorAll('img[src^="blob:"],img[src^="data:"]').length; } catch (e) {}
  return n;
}
async function waitAttach(ed, base, maxMs) {
  var t0 = Date.now(); await sleep(60);
  while (Date.now() - t0 < maxMs) {
    if (attachCount(ed) > base) { await sleep(100); return true; }
    await sleep(50);
  }
  return false;
}
function toFile(du) {
  var m = /^data:([^;]+);base64,(.*)$/.exec(du); if (!m) return null;
  var bin = atob(m[2]), u = new Uint8Array(bin.length);
  for (var i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
  var ext = m[1].indexOf('png') >= 0 ? 'png' : 'jpg';
  return new File([u], 'question.' + ext, { type: m[1] });
}
function vis(el) { return !!(el && el.getClientRects().length && el.offsetWidth > 10 && el.offsetHeight > 10); }
function findSend() {
  var L = [].slice.call(document.querySelectorAll('button, [role="button"]')).filter(function (b) {
    var l = ((b.getAttribute('aria-label') || '') + ' ' + (b.title || '') + ' ' + (b.className || '')).toLowerCase();
    return vis(b) && /send|submit/.test(l) && !/stop|voice|mic|cancel|attach|upload|add/.test(l);
  });
  return L[L.length - 1] || null;
}
function isOn(b) { return b && !b.disabled && b.getAttribute('aria-disabled') !== 'true'; }
function wantAuto() {
  return new Promise(function (res) {
    try { chrome.storage.local.get('mockGlobal', function (o) { void chrome.runtime.lastError; var g = (o && o.mockGlobal) || {}; res(g.auto !== false); }); } catch (e) { res(true); }
  });
}
// Image upload poora hone tak send button disabled rehta hai — enable hote hi click (max ~15s)
async function autoSend(probe) {
  var t0 = Date.now(), b = null;
  while (Date.now() - t0 < 15000) {
    b = findSend(); if (isOn(b)) break; b = null; await sleep(100);
  }
  if (!b) return false;
  b.click();
  for (var w = 0; w < 12; w++) { await sleep(100); var e = findEditor(); if (!e || norm(curText(e)).indexOf(probe) < 0) return true; }
  var ed = findEditor(); if (!ed) return true;   // Enter fallback
  ed.focus();
  ['keydown', 'keypress', 'keyup'].forEach(function (t) { ed.dispatchEvent(new KeyboardEvent(t, { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true })); });
  for (var v = 0; v < 10; v++) { await sleep(100); var e2 = findEditor(); if (!e2 || norm(curText(e2)).indexOf(probe) < 0) return true; }
  return false;
}
function dropTarget(ed) { var r = ed; for (var k = 0; k < 6 && r.parentElement; k++) r = r.parentElement; return r; }
// Image lagne tak: paste -> paste dobara -> paste -> drop (page abhi hydrate na hua ho to pehla paste ud jata hai)
async function attachImage(ed, f, base) {
  for (var a = 0; a < 4; a++) {
    var e = findEditor() || ed; e.focus();
    var dt = new DataTransfer(); dt.items.add(f);
    if (a < 3) {
      e.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true }));
    } else {
      var tg = dropTarget(e);
      ['dragenter', 'dragover', 'drop'].forEach(function (t) { try { tg.dispatchEvent(new DragEvent(t, { dataTransfer: dt, bubbles: true, cancelable: true })); } catch (x) {} });
    }
    if (await waitAttach(e, base, a === 0 ? 2500 : 2000)) return true;
  }
  return false;
}
function note(msg) {
  var d = document.createElement('div');
  d.textContent = msg;
  d.style.cssText = 'position:fixed;left:50%;bottom:90px;transform:translateX(-50%);background:#222;color:#fff;padding:8px 14px;border-radius:12px;font:14px sans-serif;z-index:2147483647';
  document.body.appendChild(d); setTimeout(function () { d.remove(); }, 3500);
}
async function deliver(p) {
  if (busy) return; busy = true; var rel = null;
  try {
    var ed = await waitFor(findEditor, 25000);
    if (!ed) { note('Gemini ka text box nahi mila'); return; }
    try { if (window.__pcvApi) { rel = window.__pcvApi.suspend(ed); await sleep(30); } } catch (x) {}
    var f = p.image ? toFile(p.image) : null; if (!f && !p.text) return;
    ed.focus();
    var base = f ? attachCount(ed) : 0;
    var imgOk = true;
    if (f) imgOk = await attachImage(ed, f, base);       // pehle image lagao aur confirm karo
    if (p.text) {
      var okT = await putText(findEditor, p.text);
      if (!okT) { note('⚠ Prompt paste nahi hua — Ctrl+V karo (prompt clipboard me hai)'); try { await navigator.clipboard.writeText(p.text); } catch (x) {} return; }
    }
    if (f && !imgOk) { note('⚠ Image nahi lagi (Gemini ne nahi li) — auto-send roka. Dobara bhejo ya image khud paste karo'); return; }
    if (p.text && await wantAuto()) {
      var sent = await autoSend(norm(p.text).slice(0, 40));
      note(sent ? '🚀 Gemini ko bhej diya' : '⚠ Auto-send nahi hua — Enter dabao');
    } else note(f ? '📎 Image + prompt + question aa gaya. Enter dabao' : '📝 Prompt + question aa gaya. Enter dabao');
  } finally { setTimeout(function () { busy = false; try { rel && rel(); } catch (x) {} }, 1200); }
}
chrome.runtime.onMessage.addListener(function (m, s, reply) { if (m.cmd === 'paste') { deliver(m); reply({ ok: true }); } });

// Nayi khuli Gemini window ke liye: ruka hua image uthao.
// Page load aur app ke message mein race ho sakti hai, isliye ~20 sec tak har 1 sec check karo.
(function poll(n) {
  try {
    chrome.runtime.sendMessage({ cmd: 'getPending' }, function (p) {
      void chrome.runtime.lastError;
      if (p && p.image) { deliver(p); return; }
      if (n > 0) setTimeout(function () { poll(n - 1); }, 250);
    });
  } catch (e) {}
})(80);

})();
