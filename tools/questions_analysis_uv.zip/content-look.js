// ===== Look: Dark Reader jaisa dark/light mode + A+ FontSize Changer jaisa font size/color =====
// Engine har frame me chalta hai; panel (UI) sirf main page me. Settings chrome.storage.local ('ldk') me, sab tabs me live sync.
(function () {
  if (window.__ldk) return;
  var TOP = window.top === window;

  // ---------- host (poori page ko ek site maano: top page ka hostname) ----------
  function topHost() {
    try {
      var ao = location.ancestorOrigins;
      if (ao && ao.length) return new URL(ao[ao.length - 1]).hostname || 'local';
    } catch (e) {}
    return location.hostname || 'local';
  }
  var HOST = topHost();

  // ---------- defaults (screenshot wali settings) ----------
  var LOOK_KEYS = ['mode', 'engine', 'bright', 'contrast', 'sepia', 'gray', 'fontOn', 'font', 'stroke'];
  var DEF_LOOK = { mode: 'dark', engine: 'dynamic', bright: 100, contrast: 120, sepia: 10, gray: 25, fontOn: true, font: 'Segoe UI', stroke: 0.1 };
  var DEF_FX = { fs: 100, colorsOn: false, fg: '#fffff7', bg: '#040606', ul: true, cl: true };
  var DEF_LIST = ['www.kiranprepare.com', 'drive.google.com', 'youtubetotranscript.com', 'recruitment.rajasthan.gov.in', 'emitraapp.rajasthan.gov.in', 'ibpsreg.ibps.in', 'merchant.onlinesbi.sbi', 'docs.google.com', 'sscexams.cbexams.com', 'ifms.rajasthan.gov.in', 'www.therepeatersofficial.com'];
  var FONTS = ['Segoe UI', 'Arial', 'Verdana', 'Tahoma', 'Trebuchet MS', 'Calibri', 'Georgia', 'Times New Roman', 'Roboto', 'Open Sans', 'Nirmala UI', 'Noto Sans Devanagari', 'Comic Sans MS', 'Courier New', 'system-ui'];

  var D = { g: Object.assign({ on: true, listMode: 'not', list: DEF_LIST.slice() }, DEF_LOOK), sites: {}, fx: {} };

  function load(cb) {
    var done = false;
    function fin() { if (done) return; done = true; cb(); }
    setTimeout(fin, 1500);
    try {
      chrome.storage.local.get('ldk', function (o) {
        if (done) return;
        void chrome.runtime.lastError;
        var s = o && o.ldk;
        if (s) {
          D.g = Object.assign(D.g, s.g || {}); if (!Array.isArray(D.g.list)) D.g.list = DEF_LIST.slice();
          D.sites = s.sites || {}; D.fx = s.fx || {};
        }
        fin();
      });
    } catch (e) { fin(); }
  }
  function save() { try { chrome.storage.local.set({ ldk: D }); } catch (e) {} }

  // ---------- effective settings ----------
  function look() {
    var L = Object.assign({}, DEF_LOOK, { fontOn: false, stroke: 0 }, D.sites[HOST] || {});
    L.engine = 'dynamic';   // theme mode selector hata diya: hamesha Dynamic
    return L;
  }
  function fx() { return Object.assign({}, DEF_FX, D.fx[HOST] || {}); }
  function inList(h) {
    return D.g.list.some(function (e) {
      e = String(e || '').trim().toLowerCase(); if (!e) return false;
      if (e.indexOf('*.') === 0) { var b = e.slice(2); return h === b || h.slice(-(b.length + 1)) === '.' + b; }
      return h === e || h === 'www.' + e || 'www.' + h === e;
    });
  }
  // sab kuch sirf usi site par jahan ON kiya ho (kisi site par apne aap kuch nahi lagta)
  function enabled() { var x = D.sites[HOST]; return !!x && x.on !== false; }
  function siteEnabled() { return enabled(); }

  // ---------- colour math ----------
  function parse(c) {
    var m = /^rgba?\(([^)]+)\)$/.exec(c || ''); if (!m) return null;
    var p = m[1].split(/[\s,\/]+/).filter(Boolean).map(parseFloat);
    if (p.length < 3 || p.some(isNaN)) return null;
    return { r: p[0], g: p[1], b: p[2], a: p.length > 3 ? p[3] : 1 };
  }
  function toHsl(r, g, b) {
    r /= 255; g /= 255; b /= 255;
    var mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2, h = 0, s = 0, d = mx - mn;
    if (d) {
      s = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn);
      h = mx === r ? (g - b) / d + (g < b ? 6 : 0) : mx === g ? (b - r) / d + 2 : (r - g) / d + 4; h *= 60;
    }
    return { h: h, s: s, l: l };
  }
  function css(h, s, l, a) { return 'hsla(' + Math.round(h) + ',' + Math.round(s * 100) + '%,' + Math.round(l * 100) + '%,' + a + ')'; }
  function conv(kind, c, dark) {
    var p = parse(c); if (!p) return null;
    if (kind === 'bg' && p.a < 0.04) return null;
    var h = toHsl(p.r, p.g, p.b), nl = null, s = h.s;
    if (dark) {
      if (kind === 'bg') { if (h.l > 0.5) { nl = (1 - h.l) * 0.35 + 0.09; s = Math.min(s, 0.6); } }
      else if (kind === 'fg') { if (h.l < 0.5) { nl = 0.9 - h.l * 0.6; s = Math.min(s, 0.9); } }
      else { if (h.l > 0.5) nl = (1 - h.l) * 0.4 + 0.2; }
    } else {
      if (kind === 'bg') { if (h.l < 0.5) { nl = 1 - (h.l * 0.35 + 0.09); s = Math.min(s, 0.6); } }
      else if (kind === 'fg') { if (h.l > 0.5) { nl = 0.1 + (1 - h.l) * 0.6; } }
      else { if (h.l < 0.5) nl = 0.8 - h.l * 0.4; }
    }
    return nl === null ? null : css(h.h, s, nl, p.a);
  }

  // ---------- style tag ----------
  var st = null, MEDIA = ':not(img):not(video):not(canvas):not(svg):not(picture):not(iframe):not(embed):not(object)';
  function styleTag() {
    if (!st) { st = document.createElement('style'); st.id = 'ldk-style'; }
    if (!st.isConnected && document.documentElement) document.documentElement.appendChild(st);
    return st;
  }
  // CSP wali sites inline <style> rok deti hain -> constructable stylesheet (adoptedStyleSheets) use karo, na chale to <style> tag
  var docSheet = null;
  function setDocCss(text) {
    try {
      if (!docSheet) { docSheet = new CSSStyleSheet(); }
      docSheet.replaceSync(text);
      if (document.adoptedStyleSheets.indexOf(docSheet) < 0) document.adoptedStyleSheets = document.adoptedStyleSheets.concat([docSheet]);
      if (st && st.isConnected) st.remove();
      return;
    } catch (e) {}
    styleTag().textContent = text;
  }
  function setShadowCss(root, text) {
    try { var sheet = new CSSStyleSheet(); sheet.replaceSync(text); root.adoptedStyleSheets = [sheet]; return; } catch (e) {}
    root.appendChild(mk('style', { text: text }));
  }
  var OURS = '#pcv-host,#pcv-host2,#sd-mock-host,#sd-pen-host,#ldk-host';

  function buildCss(L, F, on, has) {
    var o = '', useTheme = on && !F.colorsOn, eng = L.engine, dark = L.mode !== 'light';
    // 1) theme
    if (useTheme) {
      if (eng === 'filter' || eng === 'filterp') {
        if (TOP) {
          o += 'html{background-color:#fff!important}\n';
          o += 'img,video,canvas,picture,embed,object,svg image{filter:invert(100%) hue-rotate(180deg)!important}\n';
          if (eng === 'filterp') o += '[style*="background-image"]:empty{filter:invert(100%) hue-rotate(180deg)!important}\n';
          o += OURS + '{filter:invert(100%) hue-rotate(180deg)!important}\n';
        }
      } else if (eng === 'static') {
        var bg = dark ? '#181a1b' : '#f7f6f2', fg = dark ? '#e8e6e3' : '#1d1d1d', bd = dark ? '#545b5e' : '#bdbab2', lk = dark ? '#4fa3ff' : '#0b57d0', ib = dark ? '#2b2f31' : '#ffffff';
        o += 'html{color-scheme:' + (dark ? 'dark' : 'light') + '!important;background-color:' + bg + '!important}\n';
        o += 'html body,html body *' + MEDIA + ':not(#ldk-x){background-color:' + bg + '!important;color:' + fg + '!important;border-color:' + bd + '!important}\n';
        o += 'html body a,html body a *{color:' + lk + '!important}\n';
        o += 'html body input,html body textarea,html body select,html body button{background-color:' + ib + '!important}\n';
      } else {
        o += 'html{color-scheme:' + (dark ? 'dark' : 'light') + '!important;background-color:' + (dark ? '#181a1b' : '#f7f6f2') + '!important}\n';
      }
    }
    // 2) font + stroke (Dark Reader "More" tab)
    if (has) {
      if (L.fontOn && L.font) {
        var ex = ':not(i):not(code):not(pre):not(kbd):not(samp):not([class*="icon" i]):not([class*="material" i]):not([class*="glyph" i]):not([class*="fa-"]):not(.fa):not(.fas):not(.far):not(.fab):not(.katex):not(.katex *):not([class*="MathJax"]):not(mjx-container *)';
        o += 'html body,html body *' + ex + '{font-family:"' + L.font + '","Nirmala UI","Noto Sans Devanagari",sans-serif!important}\n';
      }
      if (+L.stroke > 0) o += 'html body *{-webkit-text-stroke:' + (+L.stroke) + 'px!important}\n';
    }
    // 3) A+ custom colours + links
    if (F.colorsOn) {
      o += 'html,html body{background-color:' + F.bg + '!important}\n';
      o += 'html body *' + MEDIA + ':not(#ldk-x){background-color:' + F.bg + '!important;color:' + F.fg + '!important}\n';
      if (F.cl) o += 'html body a,html body a *{color:#5aa9ff!important}\n';
      if (F.ul) o += 'html body a{text-decoration:underline!important}\n';
    }
    // 4) brightness / contrast / sepia / grayscale (sirf top; iframe bhi usi me aa jaate hain)
    if (TOP && on) {
      var f = [];
      if (useTheme && (eng === 'filter' || eng === 'filterp')) f.push('invert(100%) hue-rotate(180deg)');
      if (+L.bright !== 100) f.push('brightness(' + (L.bright / 100) + ')');
      if (+L.contrast !== 100) f.push('contrast(' + (L.contrast / 100) + ')');
      if (+L.sepia) f.push('sepia(' + L.sepia + '%)');
      if (+L.gray) f.push('grayscale(' + L.gray + '%)');
      if (f.length) o += 'html{filter:' + f.join(' ') + '!important}\n';
    }
    return o;
  }

  // ---------- dynamic engine: har element ka rang badlo ----------
  var touched = new Set(), mo = null, dynOn = false, dynDark = true, q = new Set(), qBusy = false;
  var SKIPTAG = { SCRIPT: 1, STYLE: 1, NOSCRIPT: 1, LINK: 1, META: 1, IMG: 1, VIDEO: 1, CANVAS: 1, IFRAME: 1, PICTURE: 1, SOURCE: 1, SVG: 1, PATH: 1, HEAD: 1, TITLE: 1, EMBED: 1, OBJECT: 1 };
  function skipEl(el) {
    if (!el || el.nodeType !== 1 || (window.SVGElement && el instanceof SVGElement) || SKIPTAG[el.tagName.toUpperCase()] || el.id === 'ldk-host' || el.id === 'ldk-style' || el.id === 'pcv-host' || el.id === 'pcv-host2' || el.id === 'sd-mock-host' || el.id === 'sd-pen-host') return true;
    return false;
  }
  var PROPS = [['bg', 'background-color', 'backgroundColor'], ['fg', 'color', 'color'], ['bt', 'border-top-color', 'borderTopColor'], ['br', 'border-right-color', 'borderRightColor'], ['bb', 'border-bottom-color', 'borderBottomColor'], ['bl', 'border-left-color', 'borderLeftColor']];
  var BW = { bt: 'borderTopWidth', br: 'borderRightWidth', bb: 'borderBottomWidth', bl: 'borderLeftWidth' };
  function procEl(el) {
    if (skipEl(el)) return;
    var cs = getComputedStyle(el), rec = el.__ldkO, i, k, P;
    for (i = 0; i < PROPS.length; i++) {
      P = PROPS[i]; k = P[0];
      if (BW[k] && !(parseFloat(cs[BW[k]]) > 0)) continue;
      // pehle apna set kiya hua hata kar asli (page wala) rang padho
      var cur = cs[P[2]], nv = conv(k === 'bg' ? 'bg' : k === 'fg' ? 'fg' : 'bd', cur, dynDark);
      if (rec && rec[k] !== undefined && el.style.getPropertyValue(P[1]) === rec[k].mine) {
        // pehle se hamara rang laga hai -> dobara mat badlo
        continue;
      }
      if (nv) {
        if (!rec) rec = el.__ldkO = {};
        rec[k] = { oldV: el.style.getPropertyValue(P[1]), oldP: el.style.getPropertyPriority(P[1]), mine: nv };
        el.style.setProperty(P[1], nv, 'important');
        rec[k].mine = el.style.getPropertyValue(P[1]);
        touched.add(el);
      } else if (rec && rec[k] !== undefined) { delete rec[k]; }
    }
  }
  function runQ() {
    qBusy = true;
    var t0 = performance.now();
    var it = q.values();
    while (q.size && performance.now() - t0 < 10) {
      var n = it.next(); if (n.done) break; q.delete(n.value); try { procEl(n.value); } catch (e) {}
    }
    if (mo) mo.takeRecords();
    if (q.size) setTimeout(runQ, 30); else qBusy = false;
  }
  function enqueue(root, deep) {
    if (!root || root.nodeType !== 1) return;
    q.add(root);
    if (deep) { var all = root.querySelectorAll('*'); for (var i = 0; i < all.length; i++) q.add(all[i]); }
    if (!qBusy) setTimeout(runQ, 0);
  }
  function dynStart(dark) {
    dynDark = dark;
    if (dynOn) dynStop();
    dynOn = true;
    var de = document.documentElement; if (!de) return;
    enqueue(de, true);
    mo = new MutationObserver(function (list) {
      list.forEach(function (m) {
        if (m.type === 'childList') { m.addedNodes.forEach(function (n) { if (n.nodeType === 1) enqueue(n, true); }); }
        else if (m.type === 'attributes' && m.target && m.target.nodeType === 1) {
          enqueue(m.target, false);   // page ne rang badla ho to procEl khud pakad leta hai
        }
      });
    });
    mo.observe(de, { childList: true, subtree: true, attributes: true, attributeFilter: ['class'] });
  }
  function dynStop() {
    dynOn = false;
    if (mo) { mo.disconnect(); mo = null; }
    q.clear();
    touched.forEach(function (el) {
      var rec = el.__ldkO; if (!rec) return;
      PROPS.forEach(function (P) {
        var r = rec[P[0]]; if (!r) return;
        if (el.style.getPropertyValue(P[1]) === r.mine) { if (r.oldV) el.style.setProperty(P[1], r.oldV, r.oldP); else el.style.removeProperty(P[1]); }
      });
      el.__ldkO = null;
    });
    touched.clear();
  }

  // ---------- font size (A+ / A-) ----------
  var fsOn = false, fsMo = null, fsMap = new WeakMap(), fsList = new Set(), curFs = 100, fsQ = [], fsBusy = false;
  function hasOwnText(el) {
    for (var n = el.firstChild; n; n = n.nextSibling) if (n.nodeType === 3 && n.nodeValue.trim()) return true;
    return false;
  }
  function fsProc(el) {
    if (skipEl(el) || !hasOwnText(el)) return;
    var o = fsMap.get(el);
    if (o === undefined) {
      var cs = getComputedStyle(el), px = parseFloat(cs.fontSize);
      if (!px) return;
      var par = el.parentElement, po = par && fsMap.get(par);
      if (po) { var pc = parseFloat(getComputedStyle(par).fontSize); if (pc) px = po * (px / pc); }
      o = px; fsMap.set(el, o); fsList.add(el);
      el.__ldkFs0 = { v: el.style.getPropertyValue('font-size'), p: el.style.getPropertyPriority('font-size') };
    }
    el.style.setProperty('font-size', (o * curFs / 100).toFixed(2) + 'px', 'important');
  }
  function fsRun() {
    fsBusy = true; var t0 = performance.now();
    while (fsQ.length && performance.now() - t0 < 12) { try { fsProc(fsQ.pop()); } catch (e) {} }
    if (fsMo) fsMo.takeRecords();
    if (fsQ.length) setTimeout(fsRun, 16); else fsBusy = false;
  }
  // pehle sab ke asli size padho (kuch badalne se pehle), phir lagao
  function fsApply(pct) {
    curFs = pct;
    if (pct === 100 && !fsOn) return;
    if (pct === 100) { fsStop(); return; }
    var de = document.documentElement; if (!de || !document.body) return;
    if (!fsOn) {
      fsOn = true;
      var all = [].slice.call(document.body.querySelectorAll('*')).filter(function (e) { return !skipEl(e) && hasOwnText(e); });
      var sizes = all.map(function (e) { return parseFloat(getComputedStyle(e).fontSize); });
      all.forEach(function (e, i) { if (sizes[i] && !fsMap.has(e)) { fsMap.set(e, sizes[i]); fsList.add(e); e.__ldkFs0 = { v: e.style.getPropertyValue('font-size'), p: e.style.getPropertyPriority('font-size') }; } });
      fsMo = new MutationObserver(function (list) {
        list.forEach(function (m) { m.addedNodes && m.addedNodes.forEach(function (n) { if (n.nodeType === 1) { fsQ.push(n); n.querySelectorAll('*').forEach(function (c) { fsQ.push(c); }); } else if (n.nodeType === 3 && n.parentElement) fsQ.push(n.parentElement); }); });
        if (fsQ.length && !fsBusy) setTimeout(fsRun, 60);
      });
      fsMo.observe(document.body, { childList: true, subtree: true });
    }
    fsList.forEach(function (e) { if (!e.isConnected) { fsList.delete(e); return; } var o = fsMap.get(e); if (o) e.style.setProperty('font-size', (o * pct / 100).toFixed(2) + 'px', 'important'); });
    if (fsMo) fsMo.takeRecords();
  }
  function fsStop() {
    fsOn = false;
    if (fsMo) { fsMo.disconnect(); fsMo = null; }
    fsList.forEach(function (e) { var r = e.__ldkFs0; if (r && r.v) e.style.setProperty('font-size', r.v, r.p); else e.style.removeProperty('font-size'); fsMap.delete(e); e.__ldkFs0 = null; });
    fsList.clear(); fsQ = [];
  }

  // ---------- sab kuch lagao ----------
  var lastKey = '';
  function applyAll() { try { applyAll0(); } catch (e) { try { console.error('[Look] apply', e); } catch (x) {} } }
  function applyAll0() {
    var L = look(), F = fx(), on = enabled();
    setDocCss(buildCss(L, F, on, !!D.sites[HOST]));
    var useTheme = on && !F.colorsOn;
    var wantDyn = useTheme && L.engine === 'dynamic';
    var key = wantDyn ? L.mode : '';
    if (wantDyn) { if (!dynOn || key !== lastKey) { dynStart(L.mode !== 'light'); } } else if (dynOn) dynStop();
    lastKey = key;
    if (document.body) fsApply(F.fs); else document.addEventListener('DOMContentLoaded', function () { fsApply(F.fs); }, { once: true });
    if (TOP && ui) refreshUi();
  }

  // ---------- A+ / A- ----------
  function setFs(p) {
    p = Math.max(50, Math.min(300, Math.round(p)));
    D.fx[HOST] = Object.assign(fx(), { fs: p }); save(); applyAll();
  }
  function stepFs(d) { setFs(fx().fs + d); }

  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && TOP && ui && els.w && els.w.classList.contains('o')) { closeUi(); return; }
    if (!e.altKey || e.ctrlKey || e.metaKey) return;
    if (e.key === 'ArrowUp') { e.preventDefault(); stepFs(10); }
    else if (e.key === 'ArrowDown') { e.preventDefault(); stepFs(-10); }
    else if (!e.shiftKey && (e.key === 'l' || e.key === 'L') && TOP) { e.preventDefault(); toggleUi(); }
    else if (e.shiftKey && (e.key === 'D' || e.key === 'd')) { e.preventDefault(); setSiteOn(!enabled()); }
  }, true);

  // ======================= PANEL (sirf top frame) =======================
  var ui = null, hostEl = null, sh = null, tab = 'filter', els = {};
  function note2(msg) { note(msg); }
  function note(msg) {
    try {
      var d = document.createElement('div'); d.textContent = msg;
      d.style.cssText = 'position:fixed;left:50%;bottom:80px;transform:translateX(-50%);background:#7a1f1f;color:#fff;padding:9px 14px;border-radius:12px;font:14px sans-serif;z-index:2147483647;max-width:90vw;text-align:center';
      (document.documentElement || document.body).appendChild(d); setTimeout(function () { d.remove(); }, 7000);
    } catch (e) {}
  }
  function mk(tag, at, kids) {
    var e = document.createElement(tag);
    for (var k in (at || {})) { if (k === 'text') e.textContent = at[k]; else if (k === 'cls') e.className = at[k]; else if (k === 'style') e.style.cssText = at[k]; else e.setAttribute(k, at[k]); }
    (kids || []).forEach(function (c) { e.appendChild(typeof c === 'string' ? document.createTextNode(c) : c); });
    return e;
  }
  var PCSS =
    ':host{all:initial}*{box-sizing:border-box;font-family:"Segoe UI","Nirmala UI",system-ui,sans-serif}' +
    '#w{position:fixed;right:8px;top:8px;width:min(350px,94vw);max-height:calc(100vh - 16px);overflow-y:auto;background:#1b2a2e;color:#dfeeee;border:2px solid #3a9e91;padding:12px;font-size:14px;display:none;box-shadow:0 8px 28px rgba(0,0,0,.65);user-select:none}#w.o{display:block}' +
    'h1{margin:0 0 10px;color:#f08a7e;font-size:27px;font-weight:900;letter-spacing:.5px;text-align:center}' +
    '.x{position:absolute;right:8px;top:6px;border:0;background:none;color:#9bcfc7;font-size:20px;cursor:pointer}' +
    '.r{display:flex;gap:8px;margin:6px 0;align-items:stretch}.r>*{flex:1}' +
    'button,.seg span{font:inherit;color:#dfeeee;background:#1b2a2e;border:2px solid #3a9e91;padding:8px 6px;cursor:pointer;text-align:center}' +
    'button:hover,.seg span:hover{background:#25403f}' +
    '.seg{display:flex;border:2px solid #3a9e91}.seg span{flex:1;border:0}.seg span.a{background:#3a9e91;color:#fff;font-weight:700}' +
    '.tabs{display:flex;border-bottom:2px solid #3a9e91;margin:12px 0 10px}.tabs span{padding:6px 10px;color:#6fbfb3;cursor:pointer;font-weight:700;border:2px solid transparent;border-bottom:0}.tabs span.a{color:#f08a7e;border-color:#3a9e91;background:#1b2a2e;margin-bottom:-2px}' +
    '.sl{display:flex;gap:6px;align-items:center;margin-top:10px}.sl button{width:34px;padding:6px 0;font-size:18px;flex:none}.sl .rg{flex:1}.sl input[type=range]{width:100%;accent-color:#3a9e91}' +
    '.lab{text-align:center;color:#6fbfb3;font-size:13px;margin-top:2px}.lab b{color:#dfeeee}' +
    '.sub{font-size:12px;color:#6fbfb3;text-align:center;margin:2px 0}' +
    'select,input[type=text]{width:100%;background:#13201f;color:#dfeeee;border:2px solid #3a9e91;padding:7px;font-size:14px}' +
    'input[type=color]{width:46px;height:36px;border:2px solid #3a9e91;background:#13201f;padding:1px;flex:none}' +
    'label.ck{display:flex;gap:8px;align-items:center;margin:8px 0;cursor:pointer}label.ck input{width:18px;height:18px;accent-color:#3a9e91}' +
    '.li{display:flex;align-items:center;border:1px solid #3a9e91;border-top:0;padding:5px 8px;font-size:13px}.li span{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;user-select:text}.li i{font-style:normal;cursor:pointer;color:#f08a7e;padding:0 6px}' +
    '#list{max-height:200px;overflow-y:auto;border-top:1px solid #3a9e91;margin:8px 0}' +
    '.big{font-size:17px;font-weight:700}.pct{flex:1.4;display:flex;align-items:center;justify-content:center;color:#dfeeee;font-weight:700}' +
    'small{display:block;color:#6fbfb3;margin-top:8px;font-size:12px;line-height:1.35}';

  function bigRow() { return mk('div', { cls: 'r' }); }
  function seg(opts, getV, setV) {
    var s = mk('div', { cls: 'seg' });
    opts.forEach(function (o) {
      var sp = mk('span', { text: o[1] }); sp.dataset.v = o[0];
      sp.addEventListener('click', function () { setV(o[0]); });
      s.appendChild(sp);
    });
    s._get = getV; s._sync = function () { [].forEach.call(s.children, function (c) { c.classList.toggle('a', c.dataset.v === String(getV())); }); };
    return s;
  }
  // slider: label, min, max, step, get, set, formatter
  function slider(name, mn, mx, step, getV, setV, fmt) {
    var wrap = mk('div'), lab = mk('div', { cls: 'lab' });
    var rg = mk('input', { type: 'range', min: mn, max: mx, step: step });
    var l = mk('button', { text: '‹' }), r = mk('button', { text: '›' });
    var row = mk('div', { cls: 'sl' }, [l, mk('div', { cls: 'rg' }, [rg]), r]);
    function sync() { var v = getV(); rg.value = v; lab.textContent = ''; lab.appendChild(mk('b', { text: name + ': ' })); lab.appendChild(document.createTextNode(fmt(v))); }
    rg.addEventListener('input', function () { setV(+rg.value); });
    l.addEventListener('click', function () { setV(Math.max(mn, +(getV() - step).toFixed(2))); });
    r.addEventListener('click', function () { setV(Math.min(mx, +(getV() + step).toFixed(2))); });
    wrap.appendChild(row); wrap.appendChild(lab); wrap._sync = sync;
    return wrap;
  }
  function fmtOff(base) { return function (v) { var d = +(v - base).toFixed(2); return d === 0 ? 'off' : (d > 0 ? '+' : '') + d; }; }
  function fmtPct(v) { return v ? '+' + v : 'off'; }

  // Dark Reader jaisa: "Sirf is site ke liye" - override on ho to is site ka alag set
  function ensureSite() { if (!D.sites[HOST]) D.sites[HOST] = { on: true }; return D.sites[HOST]; }
  function getL(k) { return look()[k]; }
  function setL(k, v) {
    var fontKey = k === 'fontOn' || k === 'font' || k === 'stroke';
    var x = D.sites[HOST]; if (!x) x = D.sites[HOST] = { on: fontKey ? false : true };
    x[k] = v; if (!fontKey) x.on = true;
    save(); applyAll();
  }
  function setSiteOn(v) {
    if (v) { ensureSite().on = true; } else if (D.sites[HOST]) { D.sites[HOST].on = false; }
    save(); applyAll();
  }
  function toggleSite() { setSiteOn(!enabled()); }

  var secs = {}, hdrSite, hdrOn, tabEls = {}, listBox;

  function buildUi() {
    hostEl = document.createElement('div'); hostEl.id = 'ldk-host';
    hostEl.style.cssText = 'all:initial;position:fixed;z-index:2147483647;left:0;top:0;width:0;height:0';
    sh = hostEl.attachShadow({ mode: 'open' });
    setShadowCss(sh, PCSS);
    var w = mk('div', { id: 'w' });
    var x = mk('button', { cls: 'x', text: '✕', title: 'Band karo' }); x.addEventListener('click', closeUi);
    w.appendChild(x);
    w.appendChild(mk('h1', { text: 'DARK + FONT' }));

    // top row: site toggle + global on/off
    hdrSite = mk('button', { cls: 'big' }); hdrSite.addEventListener('click', toggleSite);
    hdrOn = seg([['1', '🌙 Dark ON'], ['0', 'Dark OFF']], function () { return enabled() ? '1' : '0'; }, function (v) { setSiteOn(v === '1'); });
    w.appendChild(mk('div', { cls: 'r' }, [hdrSite, hdrOn]));
    w.appendChild(mk('div', { cls: 'sub', text: 'Sab kuch sirf is site ke liye. Alt+L = panel, Alt+Shift+D = Dark ON/OFF, Esc = band' }));

    // tabs
    var tabs = mk('div', { cls: 'tabs' });
    [['filter', 'Filter'], ['site', 'Sites'], ['font', 'Font & Color'], ['more', 'More']].forEach(function (t) {
      var s = mk('span', { text: t[1] }); s.addEventListener('click', function () { tab = t[0]; refreshUi(); });
      tabEls[t[0]] = s; tabs.appendChild(s);
    });
    w.appendChild(tabs);

    // --- Filter tab ---
    var f = mk('div'); secs.filter = f;
    var modeSeg = seg([['dark', 'Dark'], ['light', 'Light']], function () { return getL('mode'); }, function (v) { setL('mode', v); });
    f.appendChild(modeSeg); f.appendChild(mk('div', { cls: 'lab', text: 'Mode' }));
    var sl = [
      slider('Brightness', 50, 150, 5, function () { return getL('bright'); }, function (v) { setL('bright', v); }, fmtOff(100)),
      slider('Contrast', 50, 150, 5, function () { return getL('contrast'); }, function (v) { setL('contrast', v); }, fmtOff(100)),
      slider('Sepia', 0, 100, 5, function () { return getL('sepia'); }, function (v) { setL('sepia', v); }, fmtPct),
      slider('Grayscale', 0, 100, 5, function () { return getL('gray'); }, function (v) { setL('gray', v); }, fmtPct)
    ];
    sl.forEach(function (s) { f.appendChild(s); });
    f._items = [modeSeg].concat(sl);
    w.appendChild(f);

    // --- Sites tab: jin sites par effect laga hai ---
    var s2 = mk('div'); secs.site = s2;
    s2.appendChild(mk('div', { cls: 'sub', text: 'Effect sirf inhi sites par lagta hai (jahan aapne ON kiya / badla). Baaki par kuch nahi.' }));
    listBox = mk('div', { id: 'list' }); s2.appendChild(listBox);
    w.appendChild(s2);

    // --- Font & Color tab (A+ FontSize Changer) ---
    var s3 = mk('div'); secs.font = s3;
    var bp = mk('button', { cls: 'big', text: 'A+' }), bm = mk('button', { cls: 'big', text: 'A−' }), bd = mk('button', { text: 'Default Size' });
    bp.addEventListener('click', function () { stepFs(10); }); bm.addEventListener('click', function () { stepFs(-10); }); bd.addEventListener('click', function () { setFs(100); });
    var pct = mk('div', { cls: 'pct' }); s3._pct = pct;
    s3.appendChild(mk('div', { cls: 'r' }, [bp, bm, pct]));
    s3.appendChild(mk('div', { cls: 'r' }, [bd]));
    s3.appendChild(mk('div', { cls: 'sub', text: 'Shortcut: Alt+↑ (bada) / Alt+↓ (chhota) · har site ka alag yaad rehta hai' }));

    var ckOn = mk('input', { type: 'checkbox' });
    var lOn = mk('label', { cls: 'ck' }, [ckOn, 'Custom font/background color ON (dark mode ki jagah)']);
    ckOn.addEventListener('change', function () { setFx({ colorsOn: ckOn.checked }); });
    s3.appendChild(lOn); s3._ckOn = ckOn;

    function colorRow(title, key) {
      var cp = mk('input', { type: 'color' }), tx = mk('input', { type: 'text' });
      cp.addEventListener('input', function () { tx.value = cp.value; var o = {}; o[key] = cp.value; setFx(o, true); });
      tx.addEventListener('change', function () { var v = tx.value.trim(); if (/^#?[0-9a-f]{6}$/i.test(v)) { if (v[0] !== '#') v = '#' + v; var o = {}; o[key] = v.toLowerCase(); setFx(o); } else syncFont(); });
      ['keydown', 'keyup', 'keypress'].forEach(function (t) { tx.addEventListener(t, function (e) { e.stopPropagation(); }); });
      var box = mk('div'); box.appendChild(mk('div', { cls: 'lab', text: title })); box.appendChild(mk('div', { cls: 'r' }, [tx, cp]));
      box._cp = cp; box._tx = tx; return box;
    }
    var rFg = colorRow('Font Color', 'fg'), rBg = colorRow('Background Color', 'bg');
    s3.appendChild(rFg); s3.appendChild(rBg); s3._fg = rFg; s3._bg = rBg;
    var rs = mk('button', { text: 'Reset Colors' }); rs.style.cssText = 'width:100%;margin-top:6px';
    rs.addEventListener('click', function () { setFx({ colorsOn: false, fg: DEF_FX.fg, bg: DEF_FX.bg }); });
    s3.appendChild(rs);
    var ckUl = mk('input', { type: 'checkbox' }), ckCl = mk('input', { type: 'checkbox' });
    ckUl.addEventListener('change', function () { setFx({ ul: ckUl.checked }); }); ckCl.addEventListener('change', function () { setFx({ cl: ckCl.checked }); });
    s3.appendChild(mk('label', { cls: 'ck' }, [ckUl, 'Underline Links'])); s3.appendChild(mk('label', { cls: 'ck' }, [ckCl, 'Color Links']));
    s3._ul = ckUl; s3._cl = ckCl;
    s3.appendChild(mk('small', { text: 'Underline/Color Links aur custom colors tab lagte hain jab upar "Custom ... ON" tick ho.' }));
    w.appendChild(s3);

    // --- More tab ---
    var s4 = mk('div'); secs.more = s4;
    var ckF = mk('input', { type: 'checkbox' }), sel = mk('select');
    FONTS.forEach(function (n) { sel.appendChild(mk('option', { value: n, text: n })); });
    ckF.addEventListener('change', function () { setL('fontOn', ckF.checked); }); sel.addEventListener('change', function () { setL('font', sel.value); });
    s4.appendChild(mk('div', { cls: 'r' }, [mk('div', { style: 'flex:none;width:34px;display:flex;align-items:center' }, [ckF]), sel]));
    s4.appendChild(mk('div', { cls: 'lab', text: 'Select a font (tick = lagao, untick = Default Font)' }));
    s4._ckF = ckF; s4._sel = sel;
    var stroke = slider('Text stroke', 0, 1, 0.1, function () { return +getL('stroke') || 0; }, function (v) { setL('stroke', v); }, function (v) { return v ? '+' + v : 'off'; });
    s4.appendChild(stroke); s4._stroke = stroke;
    var rst = mk('button', { text: '↺ Sab reset (defaults)' }); rst.style.cssText = 'width:100%;margin-top:12px';
    rst.addEventListener('click', function () { if (!confirm('Saari sites ki Dark/Font/Color settings hata dein?')) return; D = { g: Object.assign({ on: true, listMode: 'not', list: DEF_LIST.slice() }, DEF_LOOK), sites: {}, fx: {} }; save(); applyAll(); });
    s4.appendChild(rst);
    var ex = mk('button', { text: '⬇ Settings copy (backup)' }), im = mk('button', { text: '⬆ Settings paste (restore)' });
    ex.style.cssText = im.style.cssText = 'width:100%;margin-top:8px';
    ex.addEventListener('click', function () { var j = JSON.stringify({ sites: D.sites, fx: D.fx }); try { navigator.clipboard.writeText(j).then(function () { note2('✅ Settings clipboard me copy ho gayi'); }, function () { prompt('Ye copy karo:', j); }); } catch (e) { prompt('Ye copy karo:', j); } });
    im.addEventListener('click', function () { var t = prompt('Pehle copy ki hui settings yahan paste karo:'); if (!t) return; try { var o = JSON.parse(t); D.sites = o.sites || {}; D.fx = o.fx || {}; save(); applyAll(); note2('✅ Settings restore ho gayi'); } catch (e) { note('Galat settings text'); } });
    s4.appendChild(ex); s4.appendChild(im);
    s4.appendChild(mk('small', { text: 'Dark Reader extension band rakho warna double dark ho jayega.' }));
    w.appendChild(s4);

    ['keydown', 'keyup', 'keypress'].forEach(function (t) { w.addEventListener(t, function (e) { e.stopPropagation(); }); });
    sh.appendChild(w);
    els.w = w;
    (document.documentElement || document.body).appendChild(hostEl);
    ui = true;
  }

  function setFx(o, soft) { D.fx[HOST] = Object.assign(fx(), o); save(); applyAll(); }

  function syncFont() {
    var F = fx(), s3 = secs.font;
    s3._pct.textContent = F.fs + '%';
    s3._ckOn.checked = !!F.colorsOn;
    s3._fg._tx.value = F.fg; s3._fg._cp.value = F.fg; s3._bg._tx.value = F.bg; s3._bg._cp.value = F.bg;
    s3._ul.checked = !!F.ul; s3._cl.checked = !!F.cl;
  }
  function tags(h) {
    var t = [], x = D.sites[h], f = D.fx[h];
    if (x && x.on !== false) t.push('🌙');
    if (x && x.fontOn) t.push('Aa');
    if (f && f.fs && f.fs !== 100) t.push('A±' + f.fs + '%');
    if (f && f.colorsOn) t.push('🎨');
    return t;
  }
  function refreshUi() {
    if (!ui) return;
    var L = look(), en = enabled();
    hdrSite.textContent = (en ? '✓ ' : '✗ ') + HOST; hdrSite.style.opacity = en ? '1' : '.6';
    hdrOn._sync();
    Object.keys(tabEls).forEach(function (k) { tabEls[k].classList.toggle('a', k === tab); secs[k].style.display = k === tab ? 'block' : 'none'; });
    secs.filter._items.forEach(function (i) { i._sync(); });
    while (listBox.firstChild) listBox.removeChild(listBox.firstChild);
    var seen = {}; Object.keys(D.sites).concat(Object.keys(D.fx)).forEach(function (h) { seen[h] = 1; });
    var hosts = Object.keys(seen).filter(function (h) { return tags(h).length; });
    if (!hosts.length) listBox.appendChild(mk('div', { cls: 'li', text: '(abhi kisi site par effect nahi)' }));
    hosts.forEach(function (h) {
      var x = mk('i', { text: '✕', title: 'Is site ka sab effect hatao' }); x.addEventListener('click', function () { delete D.sites[h]; delete D.fx[h]; save(); applyAll(); });
      listBox.appendChild(mk('div', { cls: 'li' }, [mk('span', { text: h + '  ' + tags(h).join(' ') }), x]));
    });
    syncFont();
    secs.more._ckF.checked = !!L.fontOn; secs.more._sel.value = L.font || 'Segoe UI';
    secs.more._stroke._sync();
  }
  function openUi() { if (!ui) buildUi(); else (document.documentElement || document.body).appendChild(hostEl); els.w.classList.add('o'); refreshUi(); }
  function closeUi() { if (els.w) els.w.classList.remove('o'); }
  function toggleUi() {
    try {
      if (ui && els.w && els.w.classList.contains('o')) { closeUi(); return; }
      openUi();
      var r = els.w.getBoundingClientRect();
      if (!r.width || !r.height) note('Look panel dikha nahi paya (size 0). Page reload karke dobara dabao.');
    } catch (e) { note('Look error: ' + (e && e.message ? e.message : e)); try { console.error('[Look]', e); } catch (x) {} }
  }

  // ---------- boot ----------
  window.__ldk = { open: TOP ? openUi : function () {}, close: closeUi, toggle: TOP ? toggleUi : function () {} };

  function boot() {
    load(function () {
      applyAll();
      try {
        chrome.storage.onChanged.addListener(function (ch, a) {
          if (a !== 'local' || !ch.ldk) return;
          var s = ch.ldk.newValue; if (!s) return;
          D = { g: Object.assign({ on: true, listMode: 'not', list: DEF_LIST.slice() }, DEF_LOOK, s.g || {}), sites: s.sites || {}, fx: s.fx || {} };
          applyAll();
        });
      } catch (e) {}
      // kuch sites <style>/<html> badal deti hain: tag wapas lagao
      setInterval(function () { try { if (!document.hidden && docSheet && document.adoptedStyleSheets.indexOf(docSheet) < 0) document.adoptedStyleSheets = document.adoptedStyleSheets.concat([docSheet]); else if (!document.hidden && !docSheet && st && !st.isConnected && document.documentElement) document.documentElement.appendChild(st); } catch (e) {} }, 2000);
    });
  }
  try { chrome.runtime.onMessage.addListener(function (m) { if (m && m.cmd === 'ldk-toggle' && TOP) toggleUi(); }); } catch (e) {}
  boot();
})();
