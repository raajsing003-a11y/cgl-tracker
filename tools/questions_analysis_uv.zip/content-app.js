// App page par sirf 'sd-gemini-send' / 'sd-gemini-ping' message sunta hai, baaki kuch nahi karta.
function ready() { try { window.postMessage({ type: 'sd-gemini-ext-ready' }, '*'); } catch (x) {} }
window.addEventListener('message', function (e) {
  var d = e.data;
  if (e.source !== window || !d) return;
  if (d.type === 'sd-gemini-ping') { ready(); return; }
  if (d.type === 'sd-google-send' || d.type === 'sd-google-open') {
    var isSend = d.type === 'sd-google-send';
    var hasI = typeof d.image === 'string' && d.image.indexOf('data:image/') === 0;
    if (isSend && !hasI && !d.text) return;
    try {
      chrome.runtime.sendMessage({
        cmd: isSend ? 'sendG' : 'openG', image: hasI ? d.image : '', text: String(d.text || '').slice(0, 12000),
        url: String(d.url || '').slice(0, 500), geo: d.geo || null
      }, function (r) {
        void chrome.runtime.lastError;
        window.postMessage({ type: 'sd-google-ack', kind: isSend ? 'send' : 'open', found: !!(r && r.found) }, '*');
      });
    } catch (x) {}
    return;
  }
  if (d.type === 'sd-gemini-open') {
    try {
      chrome.runtime.sendMessage({ cmd: 'open', url: String(d.url || '').slice(0, 500), geo: d.geo || null }, function (r) {
        void chrome.runtime.lastError;
        window.postMessage({ type: 'sd-gemini-ack', kind: 'open', found: !!(r && r.found) }, '*');
      });
    } catch (x) {}
    return;
  }
  if (d.type !== 'sd-gemini-send') return;
  var hasImg = typeof d.image === 'string' && d.image.indexOf('data:image/') === 0;
  if (!hasImg && !d.text) return;
  try {
    chrome.runtime.sendMessage({
      cmd: 'send', image: hasImg ? d.image : '', text: String(d.text || '').slice(0, 12000),
      url: String(d.url || '').slice(0, 500), geo: d.geo || null
    }, function (r) {
      void chrome.runtime.lastError;
      window.postMessage({ type: 'sd-gemini-ack', kind: 'send', found: !!(r && r.found) }, '*');
    });
  } catch (x) { /* extension reload hua to ack nahi jayega, app fallback chalayega */ }
});
ready();
document.addEventListener('DOMContentLoaded', ready);


// ===== Extension me saved questions -> app ke Mock Question Add me (sirf jab app page ho: <html data-cgly-app>) =====
(function () {
  if (window.top !== window) return;
  function isApp() { return document.documentElement && document.documentElement.getAttribute('data-cgly-app') === '1'; }
  function sync() {
    if (!isApp()) return;
    try {
      chrome.storage.local.get('mqSaved', function (o) {
        void chrome.runtime.lastError;
        var u = ((o && o.mqSaved) || []).filter(function (x) { return !x.synced; }).slice(0, 30).map(function (x) { var y = {}; for (var k in x) y[k] = x[k]; if (x.c) { y.c = x.c; y.tp = x.c; y.chapter = x.c; } return y; });
        if (u.length) window.postMessage({ type: 'sd-mock-import', items: u }, '*');
      });
    } catch (x) {}
  }
  window.addEventListener('message', function (e) {
    var d = e.data;
    if (e.source !== window || !d || d.type !== 'sd-mock-import-ack' || !Array.isArray(d.ids)) return;
    try {
      chrome.storage.local.get('mqSaved', function (o) {
        var a = (o && o.mqSaved) || [];
        a.forEach(function (q) { if (d.ids.indexOf(q.id) >= 0) { q.synced = true; q.force = false; q.skipped = (d.skipped || []).indexOf(q.id) >= 0; } });
        chrome.storage.local.set({ mqSaved: a });
      });
    } catch (x) {}
  });
  try { chrome.storage.onChanged.addListener(function (ch, area) { if (area === 'local' && ch.mqSaved) setTimeout(sync, 400); }); } catch (x) {}
  setTimeout(sync, 2500); setInterval(function () { if (!document.hidden) sync(); }, 10000);
})();
