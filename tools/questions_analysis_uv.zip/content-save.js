// ===== Gemini / Google reply -> extension me save (khud ke paas) =====
// Reply me '---MOCKBANK---' block ho to questions (Q/A-D/ANS/EXP) auto-save ho jate hain; 💾 button se manual bhi.
(function () {
  if (window.__mqSave) return; window.__mqSave = 1;
  if (window.top !== window) return;
  var auto = true, lastKey = '', timer = null, bar = null, toastEl = null;
  try { chrome.storage.local.get('mqAuto', function (o) { if (o && o.mqAuto === false) auto = false; refreshBar(); }); } catch (e) {}

  // parse + safai: shared mq-core.js (MQ) se. Core load na ho to purana tareeka nahi, error toast aayega.
  function parseBlock(raw) { return (window.MQ || self.MQ || {}).parseBlock ? MQ.parseBlock(raw) : []; }

  // Gemini/Google ne poora block code-block me likha ho to wahi raw text lo (math render nahi hota -> LaTeX safe)
  function codeText() {
    var els = document.querySelectorAll('pre, code, code-block, .code-block, [data-test-id="code-content"]'), best = '';
    for (var i = 0; i < els.length; i++) { var tx = els[i].textContent || ''; if (tx.indexOf('---MOCKBANK---') >= 0 && tx.indexOf('---END---') >= 0) best = tx; }
    return best;
  }
  function pageText() {
    var ct = codeText(); if (ct) return ct;
    var t = (document.body && (document.body.innerText || document.body.textContent)) || '';
    if (t.indexOf('---MOCKBANK---') < 0) return t;
    // Gemini/Google ne math render kiya ho to uska asli LaTeX wapas nikalo (warna text bigad jata hai). Sirf tab jab page par math ho.
    try {
      if (!document.querySelector(MQ.MATH_SEL)) return t;
      var c = document.body.cloneNode(true), r = MQ.extractMath(c);
      if (r.n || r.plain) { c.style.cssText = 'position:fixed;left:-99999px;top:0;width:1200px'; document.documentElement.appendChild(c); var t2 = c.innerText || c.textContent || ''; c.remove(); if (t2.indexOf('---MOCKBANK---') >= 0) return t2; }
    } catch (e) {}
    return t;
  }
  // raw reply text -> (safai ke baad) questions; jin me bikhre 1-akshar wali lines mili unpe bad:1
  function itemsFrom(raw) {
    var i = raw.lastIndexOf('---MOCKBANK---'); if (i >= 0) raw = raw.slice(i);
    var cleaned = MQ.joinTiny(raw), items = parseBlock(cleaned);
    if (cleaned !== raw) { var ri = parseBlock(raw); items.forEach(function (q, k) { var r0 = ri.length === items.length ? ri[k] : null; q.bad = (!r0 || MQ.broken(r0)) ? 1 : 0; }); }
    return items;
  }
  // debug: math jaisa kuch bhi ho uska asli HTML clipboard me (Claude ko bhejne ke liye)
  function mathDebug() {
    var out = ['URL: ' + location.href, 'MATH_SEL matches: ' + document.querySelectorAll(MQ.MATH_SEL).length];
    var els = Array.prototype.slice.call(document.querySelectorAll(MQ.MATH_SEL)).slice(-3);
    if (!els.length) { // kuch nahi mila: MOCKBANK wale text ke aas-paas ka HTML do
      var w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT), n, hit = null; while ((n = w.nextNode())) { if (/Step\s*1|\u0938\u094d\u091f\u0947\u092a\s*1/.test(n.nodeValue)) hit = n; }
      var p = hit && hit.parentElement; for (var k = 0; p && k < 2; k++) p = p.parentElement;
      out.push('NO MATH ELEMENT FOUND. Nearby HTML:\n' + (p ? p.outerHTML.slice(0, 5000) : '(step text nahi mila)'));
    }
    els.forEach(function (el, i) { var r = MQ.texOf(el), pr = el.parentElement; out.push('--- #' + (i + 1) + ' tex=' + JSON.stringify(r.tex || '') + ' via=' + r.how + '\nELEMENT:\n' + el.outerHTML.slice(0, 2500) + '\nPARENT:\n' + (pr ? pr.outerHTML.slice(0, 2500) : '')); });
    var txt = out.join('\n\n');
    function done() { toast('🧪 Math HTML copy ho gaya (' + els.length + ' element) — Claude chat me paste karo'); }
    try { navigator.clipboard.writeText(txt).then(done, fb); } catch (e) { fb(); }
    function fb() { var ta = document.createElement('textarea'); ta.value = txt; ta.style.cssText = 'position:fixed;left:-9999px'; document.body.appendChild(ta); ta.select(); try { document.execCommand('copy'); } catch (x) {} ta.remove(); done(); }
  }
  function hash(s) { var h = 0; for (var i = 0; i < s.length; i++) h = ((h << 5) - h + s.charCodeAt(i)) | 0; return String(h); }

  function toast(msg) {
    if (!document.body) return;
    if (!toastEl) {
      toastEl = document.createElement('div');
      toastEl.style.cssText = 'position:fixed;left:50%;bottom:70px;transform:translateX(-50%);background:#1b5e20;color:#fff;padding:9px 15px;border-radius:12px;font:600 14px sans-serif;z-index:2147483647;max-width:90vw;text-align:center;display:none';
      document.body.appendChild(toastEl);
    }
    toastEl.textContent = msg; toastEl.style.display = 'block';
    clearTimeout(toastEl._t); toastEl._t = setTimeout(function () { toastEl.style.display = 'none'; }, 3500);
  }

  function save(force) {
    if (!force) {   // sasta check: reply me asli 'ANS: A-D' aaya ho tabhi bhari parsing (prompt template me 'ANS: <A..' hota hai)
      var tc = (document.body && document.body.textContent) || '', mi = tc.lastIndexOf('---MOCKBANK---');
      if (mi < 0 || !/ANS:\s*[ABCD]\b/.test(tc.slice(mi, mi + 30000))) return;
    }
    var items = itemsFrom(pageText());
    if (!items.length) { if (force) toast('Reply me ---MOCKBANK--- block nahi mila (reply poora aane do ya naya prompt use karo)'); return; }
    var key = hash(items.map(function (q) { return q.t; }).join('|'));
    if (!force && key === lastKey) return;
    lastKey = key;
    try {
      chrome.runtime.sendMessage({ cmd: 'mqSave', items: items, src: location.href }, function (r) {
        void chrome.runtime.lastError;
        if (!r) { toast('Extension ne jawab nahi diya — extension reload karo'); return; }
        toast('💾 ' + r.added + ' question save' + (r.dup ? ' (' + r.dup + ' pehle se the)' : '') + (r.fixed ? ' · 🔧 ' + r.fixed + ' toote question theek hue' : '') + ' · kul ' + r.total + (items.some(function (q) { return q.bad; }) ? ' · ⚠ math toota mila (jod diya) — dobara banwao' : ''));
        refreshBar(r.total);
      });
    } catch (e) {}
  }

  function sched() { if (!auto) return; clearTimeout(timer); timer = setTimeout(function () { save(false); }, 3000); }

  var cnt = null, autoBtn = null;
  function refreshBar(total) {
    if (!bar) return;
    if (autoBtn) autoBtn.textContent = auto ? 'Auto: ON' : 'Auto: OFF';
    if (total != null && cnt) cnt.textContent = '📂 Saved (' + total + ')';
    else if (cnt) { try { chrome.storage.local.get('mqSaved', function (o) { cnt.textContent = '📂 Saved (' + (((o && o.mqSaved) || []).length) + ')'; }); } catch (e) {} }
  }
  function mountBar() {
    if (bar || !document.body) return;
    bar = document.createElement('div');
    bar.style.cssText = 'position:fixed;left:8px;bottom:8px;z-index:2147483646;display:flex;gap:6px;align-items:center;background:rgba(20,22,27,.92);color:#fff;border-radius:12px;padding:5px 7px;font:700 12px sans-serif;box-shadow:0 2px 10px rgba(0,0,0,.45)';
    function b(txt, bg, fn) { var x = document.createElement('button'); x.type = 'button'; x.textContent = txt; x.style.cssText = 'border:0;border-radius:9px;padding:6px 9px;font:700 12px sans-serif;color:#fff;cursor:pointer;background:' + bg; x.onclick = fn; bar.appendChild(x); return x; }
    b('💾 Save', '#2e7d32', function () { save(true); });
    b('🧪', '#7b1fa2', mathDebug).title = 'Math debug: math ka asli HTML copy karo';
    cnt = b('📂 Saved', '#1a73e8', function () { try { chrome.runtime.sendMessage({ cmd: 'mqOpen' }); } catch (e) {} });
    autoBtn = b('Auto: ON', '#555', function () { auto = !auto; try { chrome.storage.local.set({ mqAuto: auto }); } catch (e) {} refreshBar(); toast(auto ? 'Auto-save ON' : 'Auto-save OFF'); });
    document.body.appendChild(bar); refreshBar();
  }
  function start() {
    mountBar();
    new MutationObserver(function (ms) {
      for (var i = 0; i < ms.length; i++) { var t = ms[i].target; if (bar && t && t.nodeType === 1 && bar.contains(t)) continue; sched(); return; }
    }).observe(document.body, { subtree: true, childList: true, characterData: true });
    setTimeout(function () { sched(); }, 1500);
  }
  if (document.body) start(); else document.addEventListener('DOMContentLoaded', start);
})();
