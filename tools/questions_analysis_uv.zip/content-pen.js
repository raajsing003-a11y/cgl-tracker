// ===== Pen: kisi bhi page ki screen par kuch bhi draw karo =====
// Tools: Pen, Highlighter, Eraser, Line, Arrow, Rectangle, Ellipse, Text, Laser. Undo/Redo/Clear, colors, size,
// Scroll mode (✋), Page ke saath scroll (📌), Screenshot save/copy (📷/📋). Alt+P = ON/OFF.
// Drawing canvas page ke upar hai, isliye Gemini/Google ko bheje gaye screenshot me drawing bhi jati hai.
(function () {
  if (window.__sdPen) return; window.__sdPen = 1;
  if (window.top !== window) return;                       // sirf main page par
  var H = location.hostname || 'local';
  var COLORS = ['#ff1744', '#ff9100', '#ffea00', '#00e676', '#00b0ff', '#d500f9', '#ffffff', '#111111'];
  var CFG = { tool: 'pen', color: '#ff1744', size: 4, anchor: false, fill: false, palm: true, pos: null, bpos: null, hid: {} };
  var S = { on: false, hand: false, show: true, objs: [], undo: [], redo: [], cur: null, era: null, hover: null, laser: [], lasering: false, penSeen: false, txt: null, hidden: false };
  var host, sh, cv, g, tb, fab, ta, raf = 0, dpr = 1;
  var TOOLS = [['pen', '✏️', 'Pen (P)'], ['hl', '🖍', 'Highlighter (H)'], ['eraser', '🧽', 'Eraser (E)'], ['line', '╱', 'Line (L)'], ['arrow', '➚', 'Arrow (A)'],
    ['rect', '▭', 'Rectangle (R)'], ['ellipse', '◯', 'Ellipse (O)'], ['text', 'T', 'Text (T)'], ['laser', '🔴', 'Laser pointer (K)']];
  var KEYMAP = { p: 'pen', h: 'hl', e: 'eraser', l: 'line', a: 'arrow', r: 'rect', o: 'ellipse', t: 'text', k: 'laser' };

  // ---------- settings ----------
  var svT = 0;
  function saveCfg() { clearTimeout(svT); svT = setTimeout(function () { try { chrome.storage.local.set({ penCfg: CFG }); } catch (e) {} }, 250); }
  function loadCfg(cb) {
    var done = false; function fin() { if (done) return; done = true; cb(); }
    setTimeout(fin, 1200);
    try {
      chrome.storage.local.get('penCfg', function (o) {
        void chrome.runtime.lastError;
        var c = o && o.penCfg; if (c && typeof c === 'object') { for (var k in CFG) if (k in c) CFG[k] = c[k]; if (!CFG.hid || typeof CFG.hid !== 'object') CFG.hid = {}; }
        fin();
      });
    } catch (e) { fin(); }
  }

  // ---------- helpers ----------
  function sx() { return window.pageXOffset || 0; }
  function sy() { return window.pageYOffset || 0; }
  function dseg(px, py, x1, y1, x2, y2) {
    var dx = x2 - x1, dy = y2 - y1, l = dx * dx + dy * dy, t = l ? ((px - x1) * dx + (py - y1) * dy) / l : 0;
    t = Math.max(0, Math.min(1, t));
    var cx = x1 + t * dx, cy = y1 + t * dy; return Math.hypot(px - cx, py - cy);
  }
  function hit(o, x, y, r) {
    var px = o.a ? x + sx() : x, py = o.a ? y + sy() : y, i, p, w = (o.w || 2) / 2 + r;
    if (o.t === 'pen') {
      p = o.pts; if (p.length === 1) return Math.hypot(px - p[0][0], py - p[0][1]) <= w;
      for (i = 1; i < p.length; i++) if (dseg(px, py, p[i - 1][0], p[i - 1][1], p[i][0], p[i][1]) <= w) return true;
      return false;
    }
    if (o.t === 'line' || o.t === 'arrow') return dseg(px, py, o.x1, o.y1, o.x2, o.y2) <= w;
    var l = Math.min(o.x1, o.x2), rr = Math.max(o.x1, o.x2), t = Math.min(o.y1, o.y2), b = Math.max(o.y1, o.y2);
    if (o.t === 'rect') {
      if (o.fill && px >= l && px <= rr && py >= t && py <= b) return true;
      return dseg(px, py, l, t, rr, t) <= w || dseg(px, py, rr, t, rr, b) <= w || dseg(px, py, rr, b, l, b) <= w || dseg(px, py, l, b, l, t) <= w;
    }
    if (o.t === 'ellipse') {
      var cx = (l + rr) / 2, cy = (t + b) / 2, a = Math.max((rr - l) / 2, 1), bb = Math.max((b - t) / 2, 1), n = Math.hypot((px - cx) / a, (py - cy) / bb);
      if (o.fill && n <= 1) return true;
      return Math.abs(n - 1) * Math.min(a, bb) <= w;
    }
    if (o.t === 'text') return px >= o.x - r && px <= o.x + o.bw + r && py >= o.y - r && py <= o.y + o.bh + r;
    return false;
  }

  // ---------- drawing ----------
  function drawObj(c, o) {
    var i, p;
    c.save(); if (o.a) c.translate(-sx(), -sy());
    c.lineCap = 'round'; c.lineJoin = 'round'; c.strokeStyle = o.c; c.fillStyle = o.c; c.lineWidth = o.w;
    if (o.t === 'pen') {
      if (o.hl) c.globalAlpha = 0.38;
      p = o.pts;
      if (p.length === 1) { c.beginPath(); c.arc(p[0][0], p[0][1], Math.max(o.w / 2, 0.6), 0, 6.2832); c.fill(); }
      else if (o.pp) {
        for (i = 1; i < p.length; i++) {
          c.lineWidth = Math.max(0.6, o.w * (0.35 + 1.1 * ((p[i][2] + p[i - 1][2]) / 2)));
          c.beginPath(); c.moveTo(p[i - 1][0], p[i - 1][1]); c.lineTo(p[i][0], p[i][1]); c.stroke();
        }
      } else {
        c.beginPath(); c.moveTo(p[0][0], p[0][1]);
        for (i = 1; i < p.length - 1; i++) c.quadraticCurveTo(p[i][0], p[i][1], (p[i][0] + p[i + 1][0]) / 2, (p[i][1] + p[i + 1][1]) / 2);
        c.lineTo(p[p.length - 1][0], p[p.length - 1][1]); c.stroke();
      }
    } else if (o.t === 'line' || o.t === 'arrow') {
      c.beginPath(); c.moveTo(o.x1, o.y1); c.lineTo(o.x2, o.y2); c.stroke();
      if (o.t === 'arrow') {
        var ang = Math.atan2(o.y2 - o.y1, o.x2 - o.x1), hl = Math.max(12, o.w * 4.5);
        c.beginPath(); c.moveTo(o.x2, o.y2); c.lineTo(o.x2 - hl * Math.cos(ang - 0.45), o.y2 - hl * Math.sin(ang - 0.45));
        c.moveTo(o.x2, o.y2); c.lineTo(o.x2 - hl * Math.cos(ang + 0.45), o.y2 - hl * Math.sin(ang + 0.45)); c.stroke();
      }
    } else if (o.t === 'rect' || o.t === 'ellipse') {
      var l = Math.min(o.x1, o.x2), t = Math.min(o.y1, o.y2), w = Math.abs(o.x2 - o.x1), h = Math.abs(o.y2 - o.y1);
      c.beginPath();
      if (o.t === 'rect') c.rect(l, t, w, h); else c.ellipse(l + w / 2, t + h / 2, w / 2, h / 2, 0, 0, 6.2832);
      if (o.fill) { c.globalAlpha = 0.25; c.fill(); c.globalAlpha = 1; }
      c.stroke();
    } else if (o.t === 'text') {
      c.font = '600 ' + o.s + 'px "Segoe UI","Noto Sans Devanagari",system-ui,sans-serif'; c.textBaseline = 'top';
      var ls = o.txt.split('\n'); for (i = 0; i < ls.length; i++) c.fillText(ls[i], o.x, o.y + i * o.s * 1.25);
    }
    c.restore();
  }
  function redraw() {
    raf = 0; if (!g) return;
    g.setTransform(dpr, 0, 0, dpr, 0, 0); g.clearRect(0, 0, innerWidth, innerHeight);
    if (S.show) {
      for (var i = 0; i < S.objs.length; i++) drawObj(g, S.objs[i]);
      if (S.cur) drawObj(g, S.cur);
    }
    if (S.on && !S.hand && CFG.tool === 'eraser' && S.hover) {
      g.save(); g.strokeStyle = 'rgba(255,255,255,.9)'; g.lineWidth = 1.5; g.beginPath(); g.arc(S.hover.x, S.hover.y, eraseR(), 0, 6.2832); g.stroke();
      g.strokeStyle = 'rgba(0,0,0,.6)'; g.lineWidth = 1; g.beginPath(); g.arc(S.hover.x, S.hover.y, eraseR() + 1.5, 0, 6.2832); g.stroke(); g.restore();
    }
    if (S.laser.length) {
      var now = Date.now(), keep = [];
      for (var j = 0; j < S.laser.length; j++) if (now - S.laser[j].t < 700) keep.push(S.laser[j]);
      S.laser = keep;
      for (j = 0; j < keep.length; j++) {
        var a = 1 - (now - keep[j].t) / 700;
        g.fillStyle = 'rgba(255,23,68,' + (0.85 * a).toFixed(3) + ')'; g.beginPath(); g.arc(keep[j].x, keep[j].y, 3 + 7 * a, 0, 6.2832); g.fill();
      }
      if (keep.length) sched();
    }
  }
  function sched() { if (!raf) raf = requestAnimationFrame(redraw); }
  function sizeCv() {
    dpr = window.devicePixelRatio || 1;
    cv.width = Math.round(innerWidth * dpr); cv.height = Math.round(innerHeight * dpr); sched();
  }

  // ---------- undo / redo ----------
  function rm(o) { var i = S.objs.indexOf(o); if (i >= 0) S.objs.splice(i, 1); }
  function undo() {
    var a = S.undo.pop(); if (!a) return;
    if (a.k === 'add') rm(a.o); else if (a.k === 'del') a.list.forEach(function (o) { S.objs.push(o); }); else if (a.k === 'clear') S.objs = a.list.slice();
    S.redo.push(a); sched(); sync();
  }
  function redo() {
    var a = S.redo.pop(); if (!a) return;
    if (a.k === 'add') S.objs.push(a.o); else if (a.k === 'del') a.list.forEach(rm); else if (a.k === 'clear') S.objs = [];
    S.undo.push(a); sched(); sync();
  }
  function clearAll() {
    if (!S.objs.length) return;
    S.undo.push({ k: 'clear', list: S.objs.slice() }); S.redo = []; S.objs = []; sched(); sync();
  }
  function commit(o) { S.objs.push(o); S.undo.push({ k: 'add', o: o }); S.redo = []; sched(); sync(); }

  // ---------- pointer ----------
  function eraseR() { return CFG.size * 1.5 + 8; }
  function eraseAt(x, y) {
    var r = eraseR(), keep = [];
    S.objs.forEach(function (o) { if (hit(o, x, y, r)) S.era.list.push(o); else keep.push(o); });
    if (keep.length !== S.objs.length) { S.objs = keep; sched(); }
  }
  function st(x, y, a) { return a ? [x + sx(), y + sy()] : [x, y]; }
  function snapXY(o, x, y, shift) {
    if (!shift) return [x, y];
    var dx = x - o.x1, dy = y - o.y1;
    if (o.t === 'rect' || o.t === 'ellipse') { var m = Math.max(Math.abs(dx), Math.abs(dy)); return [o.x1 + (dx < 0 ? -m : m), o.y1 + (dy < 0 ? -m : m)]; }
    var d = Math.hypot(dx, dy), a = Math.round(Math.atan2(dy, dx) / (Math.PI / 4)) * (Math.PI / 4); return [o.x1 + d * Math.cos(a), o.y1 + d * Math.sin(a)];
  }
  function down(e) {
    if (!S.on || S.hand) return;
    if (e.pointerType === 'mouse' && e.button !== 0) return;
    if (e.pointerType === 'pen') S.penSeen = true;
    if (CFG.palm && S.penSeen && e.pointerType === 'touch') return;
    e.preventDefault();
    if (S.txt) endText(true);
    var t = CFG.tool, x = e.clientX, y = e.clientY, a = CFG.anchor, p0 = st(x, y, a);
    if (!S.show) { S.show = true; sync(); }
    if (t === 'text') { startText(x, y); return; }
    try { cv.setPointerCapture(e.pointerId); } catch (er) {}
    if (t === 'laser') { S.lasering = true; S.laser.push({ x: x, y: y, t: Date.now() }); sched(); return; }
    if (t === 'eraser') { S.era = { list: [] }; eraseAt(x, y); return; }
    if (t === 'pen' || t === 'hl') {
      var hl = t === 'hl', pen = e.pointerType === 'pen' && !hl;
      S.cur = { t: 'pen', c: CFG.color, w: CFG.size * (hl ? 3.2 : 1), hl: hl, a: a, pp: pen, pts: [[p0[0], p0[1], pen ? (e.pressure || 0.5) : 1]] };
    } else S.cur = { t: t, c: CFG.color, w: CFG.size, a: a, fill: CFG.fill, x1: p0[0], y1: p0[1], x2: p0[0], y2: p0[1] };
    sched();
  }
  function move(e) {
    if (!S.on || S.hand) return;
    var x = e.clientX, y = e.clientY;
    if (CFG.tool === 'eraser') { S.hover = { x: x, y: y }; if (!S.era) sched(); }
    if (S.lasering) {
      var le = e.getCoalescedEvents ? e.getCoalescedEvents() : [e];
      le.forEach(function (c) { S.laser.push({ x: c.clientX, y: c.clientY, t: Date.now() }); }); sched(); return;
    }
    if (S.era) { eraseAt(x, y); sched(); return; }
    var o = S.cur; if (!o) return;
    if (o.t === 'pen') {
      var evs = e.getCoalescedEvents ? e.getCoalescedEvents() : [e];
      if (!evs.length) evs = [e];
      evs.forEach(function (c) {
        var q = st(c.clientX, c.clientY, o.a), l = o.pts[o.pts.length - 1];
        if (Math.abs(q[0] - l[0]) + Math.abs(q[1] - l[1]) < 0.6) return;
        o.pts.push([q[0], q[1], o.pp ? (c.pressure || 0.5) : 1]);
      });
    } else { var q2 = st(x, y, o.a), r = snapXY(o, q2[0], q2[1], e.shiftKey); o.x2 = r[0]; o.y2 = r[1]; }
    sched();
  }
  function up(e) {
    if (S.lasering) { S.lasering = false; return; }
    if (S.era) { if (S.era.list.length) { S.undo.push({ k: 'del', list: S.era.list }); S.redo = []; sync(); } S.era = null; sched(); return; }
    var o = S.cur; if (!o) return; S.cur = null;
    if (o.t !== 'pen' && o.t !== 'text' && Math.abs(o.x2 - o.x1) < 2 && Math.abs(o.y2 - o.y1) < 2) { sched(); return; }
    commit(o);
  }

  // ---------- text ----------
  function fontSize() { return Math.round(CFG.size * 3 + 12); }
  function startText(x, y) {
    var s = fontSize();
    ta = document.createElement('textarea');
    ta.style.cssText = 'position:fixed;left:' + x + 'px;top:' + y + 'px;min-width:120px;min-height:' + Math.round(s * 1.4) + 'px;font:600 ' + s + 'px "Segoe UI","Noto Sans Devanagari",system-ui,sans-serif;line-height:1.25;color:' + CFG.color +
      ';background:rgba(0,0,0,.25);border:1.5px dashed ' + CFG.color + ';outline:none;padding:0;margin:0;resize:both;overflow:hidden;z-index:5;pointer-events:auto;caret-color:' + CFG.color;
    ta.placeholder = 'Likho…'; sh.appendChild(ta);
    S.txt = { x: x, y: y, s: s, c: CFG.color, a: CFG.anchor };
    ta.addEventListener('keydown', function (e) {
      e.stopPropagation();
      if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); endText(true); }
      else if (e.key === 'Escape') { e.preventDefault(); endText(false); }
    });
    ta.addEventListener('keyup', function (e) { e.stopPropagation(); });
    ta.addEventListener('keypress', function (e) { e.stopPropagation(); });
    ta.addEventListener('blur', function () { setTimeout(function () { if (S.txt) endText(true); }, 0); });
    setTimeout(function () { try { ta.focus(); } catch (e) {} }, 0);
  }
  function endText(ok) {
    var d = S.txt; if (!d || !ta) return; S.txt = null;
    var v = ta.value.replace(/\s+$/, ''); try { ta.remove(); } catch (e) {} ta = null;
    if (!ok || !v.trim()) return;
    g.save(); g.font = '600 ' + d.s + 'px "Segoe UI","Noto Sans Devanagari",system-ui,sans-serif';
    var ls = v.split('\n'), w = 0; ls.forEach(function (l) { w = Math.max(w, g.measureText(l).width); }); g.restore();
    var p = st(d.x, d.y, d.a);
    commit({ t: 'text', c: d.c, s: d.s, a: d.a, x: p[0], y: p[1], txt: v, bw: w, bh: ls.length * d.s * 1.25 });
  }

  // ---------- screenshot ----------
  function frames() { return new Promise(function (r) { requestAnimationFrame(function () { requestAnimationFrame(r); }); }); }
  function setUiHidden(v) { S.hidden = v; tb.style.visibility = v ? 'hidden' : ''; fab.style.visibility = v ? 'hidden' : ''; if (ta) ta.style.visibility = v ? 'hidden' : ''; }
  function toast(m) {
    var t = sh.getElementById('toast'); t.textContent = m; t.style.display = 'block'; clearTimeout(toast.t); toast.t = setTimeout(function () { t.style.display = 'none'; }, 2600);
  }
  function snap(copy) {
    var hidSave = S.hover; S.hover = null; sched();
    setUiHidden(true);
    frames().then(function () {
      return new Promise(function (res) {
        try { chrome.runtime.sendMessage({ cmd: 'mockCapture' }, function (r) { void chrome.runtime.lastError; res(r && r.ok ? r.data : null); }); } catch (e) { res(null); }
      });
    }).then(function (data) {
      setUiHidden(false); S.hover = hidSave;
      if (!data) { toast('⚠ Screenshot nahi ban paya (extension reload karke page refresh karo)'); return; }
      var im = new Image();
      im.onload = function () {
        var c = document.createElement('canvas'); c.width = im.naturalWidth; c.height = im.naturalHeight; c.getContext('2d').drawImage(im, 0, 0);
        c.toBlob(function (b) {
          if (!b) { toast('⚠ Image nahi ban payi'); return; }
          if (copy) {
            try { navigator.clipboard.write([new ClipboardItem({ 'image/png': b })]).then(function () { toast('📋 Screenshot copy ho gaya'); }, function () { toast('⚠ Copy nahi hua — 📷 se save karo'); }); }
            catch (e) { toast('⚠ Copy nahi hua — 📷 se save karo'); }
          } else {
            var d = new Date(), z = function (n) { return (n < 10 ? '0' : '') + n; };
            var a = document.createElement('a'); a.href = URL.createObjectURL(b); a.download = 'pen-' + d.getFullYear() + z(d.getMonth() + 1) + z(d.getDate()) + '-' + z(d.getHours()) + z(d.getMinutes()) + z(d.getSeconds()) + '.png';
            sh.appendChild(a); a.click(); setTimeout(function () { try { URL.revokeObjectURL(a.href); a.remove(); } catch (e) {} }, 1500); toast('📷 Screenshot save ho gaya');
          }
        }, 'image/png');
      };
      im.onerror = function () { toast('⚠ Image nahi ban payi'); }; im.src = data;
    });
  }

  // ---------- UI ----------
  var CSS = ':host{all:initial}*{box-sizing:border-box;font-family:system-ui,"Segoe UI","Noto Sans Devanagari",sans-serif}' +
    '#cv{position:fixed;left:0;top:0;width:100vw;height:100vh;touch-action:none;pointer-events:none;display:block}' +
    '#tb{position:fixed;display:none;flex-direction:column;gap:6px;padding:8px;border-radius:14px;background:rgba(24,26,32,.96);color:#fff;box-shadow:0 6px 22px rgba(0,0,0,.5);width:332px;max-width:calc(100vw - 12px);pointer-events:auto;user-select:none;font-size:12.5px}' +
    '#tb .r{display:flex;flex-wrap:wrap;gap:4px;align-items:center}' +
    '#tb button{border:0;border-radius:9px;min-width:33px;height:33px;padding:0 6px;background:#3a3f4a;color:#fff;font-size:16px;cursor:pointer;line-height:1}' +
    '#tb button:hover{background:#4b5160}#tb button.on{background:#1a73e8}#tb button:disabled{opacity:.35;cursor:default}' +
    '#tb button.sw{width:24px;min-width:24px;height:24px;border-radius:50%;border:2px solid #555;padding:0}#tb button.sw.on{border-color:#fff;box-shadow:0 0 0 2px #1a73e8}' +
    '#tb input[type=color]{width:28px;height:28px;border:0;padding:0;background:none;cursor:pointer}' +
    '#tb input[type=range]{flex:1;min-width:80px;accent-color:#1a73e8}' +
    '#hd{cursor:move;font-size:15px;opacity:.8;padding:0 6px;touch-action:none;flex:none}#ttl{flex:1;font-weight:700;font-size:12.5px}' +
    '#tb button.x{background:#b3261e}#prev{width:36px;height:22px;flex:none;display:flex;align-items:center;justify-content:center}' +
    '#fab{position:fixed;width:40px;height:40px;border-radius:50%;background:#1a73e8;color:#fff;font-size:19px;display:flex;align-items:center;justify-content:center;box-shadow:0 3px 12px rgba(0,0,0,.5);cursor:pointer;pointer-events:auto;user-select:none;touch-action:none;border:2px solid rgba(255,255,255,.85)}' +
    '#fab.dot::after{content:"";position:absolute;right:-1px;top:-1px;width:10px;height:10px;border-radius:50%;background:#ff1744;border:2px solid #fff}' +
    '#toast{position:fixed;left:50%;bottom:70px;transform:translateX(-50%);background:#202124;color:#fff;padding:9px 14px;border-radius:12px;font-size:13.5px;max-width:88vw;text-align:center;display:none;pointer-events:none}' +
    '.sm{font-size:11px;opacity:.75;line-height:1.35}';

  function build() {
    host = document.createElement('div'); host.id = 'sd-pen-host';
    host.style.cssText = 'all:initial;position:fixed;left:0;top:0;width:0;height:0;z-index:2147483640';
    sh = host.attachShadow({ mode: 'open' });
    var th = TOOLS.map(function (t) { return '<button data-t="' + t[0] + '" title="' + t[2] + '">' + t[1] + '</button>'; }).join('');
    var sw = COLORS.map(function (c) { return '<button class="sw" data-c="' + c + '" style="background:' + c + '" title="' + c + '"></button>'; }).join('');
    sh.innerHTML = '<style>' + CSS + '</style><canvas id="cv"></canvas>' +
      '<div id="tb">' +
      '<div class="r"><span id="hd" title="Kheench kar kahin bhi rakho">⠿</span><span id="ttl">✏️ Pen</span><button data-a="min" title="Band karo (Esc / Alt+P) — drawing bachi rahegi">✕</button></div>' +
      '<div class="r">' + th + '</div>' +
      '<div class="r">' + sw + '<input type="color" id="cc" title="Apna color chuno"></div>' +
      '<div class="r"><span class="sm">Size</span><input type="range" id="sz" min="1" max="30" step="1"><span id="szv" class="sm" style="width:20px;text-align:right"></span><canvas id="prev" width="72" height="44" style="width:36px;height:22px;background:#2b2f38;border-radius:6px"></canvas></div>' +
      '<div class="r"><button data-a="undo" title="Undo (Ctrl+Z)">↶</button><button data-a="redo" title="Redo (Ctrl+Y)">↷</button><button data-a="clear" title="Sab saaf (Undo se wapas aa sakta hai)">🗑</button>' +
      '<button data-a="eye" title="Drawing dikhao / chhupao">👁</button><button data-a="hand" title="✋ Scroll / click mode: page chalao, drawing dikhti rahegi">✋</button>' +
      '<button data-a="anchor" title="📌 Page ke saath scroll: drawing page par chipki rahegi (nayi lakeeron ke liye)">📌</button>' +
      '<button data-a="fill" title="Rectangle / Ellipse andar se bharo">⬛</button>' +
      '<button data-a="shot" title="Screenshot (drawing ke saath) save karo">📷</button><button data-a="copy" title="Screenshot clipboard me copy karo">📋</button></div>' +
      '<div class="r"><button data-a="palm" title="Palm rejection: stylus use karo to haath ka touch ignore" style="font-size:12px">🖐 Palm: ON</button><button data-a="hide" title="Is site par ✏️ button chhupao (right-click menu se wapas aayega)" style="font-size:12px">🙈 Button chhupao</button></div>' +
      '<div class="sm">Shift = seedhi line / square · ✋ = scroll mode · Alt+P = ON/OFF · Esc = band · [ ] = size</div>' +
      '</div><div id="fab" title="✏️ Pen: screen par draw karo (Alt+P)">✏️</div><div id="toast"></div>';
    cv = sh.getElementById('cv'); g = cv.getContext('2d'); tb = sh.getElementById('tb'); fab = sh.getElementById('fab');
    document.documentElement.appendChild(host);

    // canvas events
    cv.addEventListener('pointerdown', down); cv.addEventListener('pointermove', move);
    cv.addEventListener('pointerup', up); cv.addEventListener('pointercancel', up);
    cv.addEventListener('pointerleave', function () { S.hover = null; if (CFG.tool === 'eraser') sched(); });
    cv.addEventListener('wheel', function (e) { window.scrollBy(e.deltaX, e.deltaY); e.preventDefault(); }, { passive: false });

    // toolbar clicks
    tb.addEventListener('click', function (e) {
      var b = e.target.closest ? e.target.closest('button') : null; if (!b) return;
      if (b.dataset.t) { setTool(b.dataset.t); return; }
      if (b.dataset.c) { setColor(b.dataset.c); return; }
      act(b.dataset.a);
    });
    sh.getElementById('cc').addEventListener('input', function (e) { setColor(e.target.value); });
    sh.getElementById('sz').addEventListener('input', function (e) { CFG.size = +e.target.value; saveCfg(); sync(); });
    tb.addEventListener('pointerdown', function (e) { if (S.txt && e.target !== ta) endText(true); });

    // drag toolbar + fab
    drag(sh.getElementById('hd'), tb, 'pos', null);
    drag(fab, fab, 'bpos', function () { setOn(true); });
  }
  function drag(handle, box, key, onTap) {
    var sx0, sy0, ox, oy, moved, down0 = false;
    handle.addEventListener('pointerdown', function (e) {
      if (e.button && e.pointerType === 'mouse') return;
      down0 = true; moved = false; sx0 = e.clientX; sy0 = e.clientY; var r = box.getBoundingClientRect(); ox = r.left; oy = r.top;
      try { handle.setPointerCapture(e.pointerId); } catch (er) {} e.preventDefault();
    });
    handle.addEventListener('pointermove', function (e) {
      if (!down0) return;
      var dx = e.clientX - sx0, dy = e.clientY - sy0;
      if (!moved && Math.abs(dx) + Math.abs(dy) < 5) return; moved = true;
      place(box, ox + dx, oy + dy);
    });
    handle.addEventListener('pointerup', function () {
      if (!down0) return; down0 = false;
      if (moved) { var r = box.getBoundingClientRect(); CFG[key] = { x: r.left, y: r.top }; saveCfg(); }
      else if (onTap) onTap();
    });
  }
  function place(box, x, y) {
    var w = box.offsetWidth || 40, h = box.offsetHeight || 40;
    x = Math.max(2, Math.min(innerWidth - w - 2, x)); y = Math.max(2, Math.min(innerHeight - h - 2, y));
    box.style.left = x + 'px'; box.style.top = y + 'px'; box.style.right = 'auto'; box.style.bottom = 'auto';
  }
  function placeAll() {
    var p = CFG.pos; if (p && typeof p.x === 'number') place(tb, p.x, p.y); else place(tb, 10, Math.max(10, innerHeight * 0.18));
    var b = CFG.bpos; if (b && typeof b.x === 'number') place(fab, b.x, b.y); else place(fab, 10, innerHeight * 0.45);
  }

  // ---------- state sync ----------
  function setTool(t) {
    if (S.txt) endText(true);
    CFG.tool = t; S.hand = false; S.hover = null; saveCfg(); sync(); sched();
  }
  function setColor(c) { CFG.color = c; if (CFG.tool === 'eraser') CFG.tool = 'pen'; saveCfg(); sync(); }
  function act(a) {
    if (a === 'undo') undo(); else if (a === 'redo') redo(); else if (a === 'clear') clearAll();
    else if (a === 'eye') { S.show = !S.show; sched(); sync(); }
    else if (a === 'hand') { S.hand = !S.hand; sync(); }
    else if (a === 'anchor') { CFG.anchor = !CFG.anchor; saveCfg(); sync(); toast(CFG.anchor ? '📌 Ab nayi drawing page ke saath scroll hogi' : '📌 Ab nayi drawing screen par fix rahegi'); }
    else if (a === 'fill') { CFG.fill = !CFG.fill; saveCfg(); sync(); }
    else if (a === 'palm') { CFG.palm = !CFG.palm; saveCfg(); sync(); }
    else if (a === 'shot') snap(false); else if (a === 'copy') snap(true);
    else if (a === 'min') setOn(false);
    else if (a === 'hide') { CFG.hid[H] = true; saveCfg(); setOn(false); toast('🙈 Button chhup gaya. Wapas: page par right-click → "✏️ Pen button: dikhao/chhupao"'); }
  }
  function setOn(v) {
    if (S.txt) endText(true);
    S.on = !!v; if (S.on) { S.hand = false; if (!S.show) S.show = true; } S.hover = null; sync(); if (S.on) placeAll(); sched();
  }
  function btn(sel) { return sh.querySelector(sel); }
  function sync() {
    if (!sh) return;
    tb.style.display = S.on ? 'flex' : 'none';
    fab.style.display = (!S.on && !CFG.hid[H]) ? 'flex' : 'none';
    fab.className = S.objs.length ? 'dot' : '';
    cv.style.pointerEvents = (S.on && !S.hand) ? 'auto' : 'none';
    cv.style.cursor = CFG.tool === 'text' ? 'text' : (CFG.tool === 'eraser' ? 'none' : 'crosshair');
    [].forEach.call(sh.querySelectorAll('[data-t]'), function (b) { b.classList.toggle('on', b.dataset.t === CFG.tool && !S.hand); });
    [].forEach.call(sh.querySelectorAll('[data-c]'), function (b) { b.classList.toggle('on', b.dataset.c.toLowerCase() === String(CFG.color).toLowerCase()); });
    sh.getElementById('cc').value = /^#[0-9a-f]{6}$/i.test(CFG.color) ? CFG.color : '#ff1744';
    sh.getElementById('sz').value = CFG.size; sh.getElementById('szv').textContent = CFG.size;
    btn('[data-a=undo]').disabled = !S.undo.length; btn('[data-a=redo]').disabled = !S.redo.length; btn('[data-a=clear]').disabled = !S.objs.length;
    btn('[data-a=eye]').classList.toggle('on', !S.show); btn('[data-a=hand]').classList.toggle('on', S.hand);
    btn('[data-a=anchor]').classList.toggle('on', !!CFG.anchor); btn('[data-a=fill]').classList.toggle('on', !!CFG.fill);
    btn('[data-a=palm]').textContent = '🖐 Palm: ' + (CFG.palm ? 'ON' : 'OFF'); btn('[data-a=palm]').classList.toggle('on', !!CFG.palm);
    sh.getElementById('ttl').textContent = '✏️ Pen' + (S.hand ? ' · ✋ scroll mode' : '');
    var pv = sh.getElementById('prev'), pc = pv.getContext('2d'); pc.clearRect(0, 0, 72, 44);
    if (CFG.tool !== 'eraser') {
      pc.strokeStyle = CFG.color; pc.lineCap = 'round'; pc.lineWidth = Math.min(40, CFG.size * (CFG.tool === 'hl' ? 3.2 : 1) * 2); pc.globalAlpha = CFG.tool === 'hl' ? 0.4 : 1;
      pc.beginPath(); pc.moveTo(10, 22); pc.lineTo(62, 22); pc.stroke();
    }
  }

  // ---------- keys / messages ----------
  function editable(t) {
    if (!t || !t.tagName) return false; var n = t.tagName.toUpperCase();
    return n === 'INPUT' || n === 'TEXTAREA' || n === 'SELECT' || t.isContentEditable;
  }
  window.addEventListener('keydown', function (e) {
    if (!sh) return;
    if (e.altKey && !e.ctrlKey && !e.metaKey && e.code === 'KeyP') { e.preventDefault(); setOn(!S.on); return; }
    if (!S.on || S.txt) return;
    var t = e.composedPath ? e.composedPath()[0] : e.target; if (editable(t)) return;
    var k = e.key, low = k.length === 1 ? k.toLowerCase() : k;
    if ((e.ctrlKey || e.metaKey) && !e.altKey) {
      if (low === 'z' && !e.shiftKey) { e.preventDefault(); e.stopPropagation(); undo(); }
      else if (low === 'y' || (low === 'z' && e.shiftKey)) { e.preventDefault(); e.stopPropagation(); redo(); }
      return;
    }
    if (e.altKey) return;
    if (k === 'Escape') { e.preventDefault(); e.stopPropagation(); setOn(false); return; }
    if (k === 'Delete') { e.preventDefault(); e.stopPropagation(); clearAll(); return; }
    if (k === '[') { CFG.size = Math.max(1, CFG.size - 1); saveCfg(); sync(); return; }
    if (k === ']') { CFG.size = Math.min(30, CFG.size + 1); saveCfg(); sync(); return; }
    if (KEYMAP[low]) { e.preventDefault(); e.stopPropagation(); setTool(KEYMAP[low]); }
  }, true);
  window.addEventListener('resize', function () { if (!cv) return; sizeCv(); placeAll(); });
  window.addEventListener('scroll', function () { if (S.objs.some(function (o) { return o.a; }) || (S.cur && S.cur.a)) sched(); }, { passive: true });
  // Gemini/Google bhejte waqt toolbar chhupe (drawing screenshot me rahegi)
  window.addEventListener('sd-pen-hide', function () { if (sh) setUiHidden(true); });
  window.addEventListener('sd-pen-show', function () { if (sh) setUiHidden(false); });
  try {
    chrome.runtime.onMessage.addListener(function (m) {
      if (!m || !sh) return;
      if (m.cmd === 'pen-toggle') { if (CFG.hid[H]) { delete CFG.hid[H]; saveCfg(); } setOn(!S.on); }
      else if (m.cmd === 'pen-btn') { if (CFG.hid[H]) delete CFG.hid[H]; else CFG.hid[H] = true; saveCfg(); sync(); toast(CFG.hid[H] ? '🙈 Is site par ✏️ button chhup gaya' : '✏️ Button wapas aa gaya'); }
    });
  } catch (e) {}

  // ---------- start ----------
  function start() {
    if (document.getElementById('sd-pen-host')) return;
    loadCfg(function () {
      if (document.getElementById('sd-pen-host')) return;
      build(); sizeCv(); placeAll(); sync();
    });
  }
  if (document.documentElement) start(); else document.addEventListener('DOMContentLoaded', start);
})();
