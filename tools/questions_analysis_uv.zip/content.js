(function () {
  if (window.__pcvInit) return; window.__pcvInit = 1;
  var HOST = location.hostname || 'local';

  // Gemini ke liye tayyar buttons (baaki sites par "Chuno" use karo)
  var PRE = HOST === 'gemini.google.com' ? {
    header:  { l: 'Header',   s: ['top-bar-actions', '.top-bar-actions', '.top-bar-container', 'header[class*="top"]', '[class*="top-bar"]', 'header', '[role="banner"]', 'mat-toolbar', 'bard-mode-switcher', '[class*="toolbar"]', '[class*="gradient"][class*="top"]', '[class*="top"][class*="gradient"]', '[class*="top"][class*="fade"]', '[class*="scrim"]'] },
    sidebar: { l: 'Sidebar',  s: ['bard-sidenav', 'side-navigation-v2', 'mat-sidenav', '.side-nav-container'] },
    input:   { l: 'Chat box', s: ['input-container', 'input-area-v2', '.input-area-container', 'input-area', '.bottom-container'] }
  } : null;

  var S = { on: true, hide: [], moves: [], mvOn: true, pre: {}, btn: null, ng: false, clr: [] };
  var editSel = '', host, sh, btn, pan, ov, hm, st, susp = false;

  // ---------- storage (har site ki alag) ----------
  function save() {
    try { chrome.storage.local.get('pcvSites', function (o) { var a = (o && o.pcvSites) || {}; a[HOST] = S; chrome.storage.local.set({ pcvSites: a }); }); } catch (e) {}
  }

  // ---------- CSS ----------
  function css() {
    var o = '';
    S.hide.forEach(function (s) { o += 'html.pcv-on ' + s + '{display:none!important}\n'; });
    if (PRE) Object.keys(PRE).forEach(function (g) { o += 'html.pcv-on.pcv-p-' + g + ' [data-pcv-hide~="' + g + '"]{display:none!important}\n'; });
    S.clr.forEach(function (m) {
      o += 'html.pcv-on ' + m.s + '{background:none!important;background-image:none!important;box-shadow:none!important;border-color:transparent!important}\n';
      o += 'html.pcv-on ' + m.s + '::before,html.pcv-on ' + m.s + '::after{background:none!important;background-image:none!important;box-shadow:none!important}\n';
      if (m.c) o += 'html.pcv-on ' + m.s + '{padding:0!important;margin:0!important;min-height:0!important;height:0!important;overflow:visible!important}\n';
    });
    o += 'html.pcv-ng [data-pcv-g]{background:transparent!important;background-image:none!important;box-shadow:none!important}\n';
    o += 'html.pcv-ng [data-pcv-gp]::before,html.pcv-ng [data-pcv-gp]::after{background:none!important;background-image:none!important;box-shadow:none!important}\n';
    o += 'html.pcv-ng [data-pcv-m]{-webkit-mask-image:none!important;mask-image:none!important}\n';
    if (PRE) o += 'html.pcv-on.pcv-p-sidebar bard-sidenav-content,html.pcv-on.pcv-p-sidebar mat-sidenav-content{margin-left:0!important}\n';
    return o;
  }
  function apply() {
    st.textContent = css();
    var c = document.documentElement.classList;
    c.toggle('pcv-on', !!S.on && !susp); c.toggle('pcv-ng', !!(S.ng || (PRE && S.pre.header)) && !susp);
    if (PRE) Object.keys(PRE).forEach(function (g) { c.toggle('pcv-p-' + g, !!S.pre[g]); });
    presetScan(); topScan(); if (S.ng || (PRE && S.pre.header)) ngScan(); movesApply(); ovSync(); paint(); paint2();
  }

  // ---------- Preset elements: sirf wahi chuno jo poora page / chat nahi hain ----------
  var GUARD = 'infinite-scroller,chat-window-content,.conversation-container,user-query,model-response,message-content';
  function presetScan() {
    if (!PRE) return;
    Object.keys(PRE).forEach(function (g) {
      var guard = g === 'input' ? GUARD : GUARD + ',rich-textarea';
      PRE[g].s.forEach(function (sel) {
        var list; try { list = document.querySelectorAll(sel); } catch (e) { return; }
        Array.prototype.forEach.call(list, function (el) {
          if (el.hasAttribute('data-pcv-hide') || el.hasAttribute('data-pcv-no')) return;
          var r = el.getBoundingClientRect(), bad = (r.width > innerWidth * 0.7 && r.height > innerHeight * 0.7);
          if (!bad) { try { bad = !!el.querySelector(guard); } catch (e) {} }
          if (bad) { el.setAttribute('data-pcv-no', '1'); return; }
          el.setAttribute('data-pcv-hide', g);
        });
      });
    });
  }

  // ---------- Header auto-detect (class name badal jaye tab bhi): upar chipka, chauda, chhota band ----------
  function topScan() {
    if (!PRE || !S.pre.header) return;
    var pts = [], xs = [0.08, 0.3, 0.5, 0.7, 0.92], y;
    for (y = 4; y <= 220; y += 18) xs.forEach(function (fx) { pts.push([Math.round(innerWidth * fx), y]); });
    var seen = new Set();
    pts.forEach(function (pt) {
      var list = document.elementsFromPoint(pt[0], pt[1]);
      list.forEach(function (el) {
        if (!el || el === host || el === host2 || (host && host.contains(el)) || el === document.documentElement || el === document.body) return;
        var best = null, cur = el;
        while (cur && cur !== document.body && cur !== document.documentElement) {
          if (seen.has(cur)) { cur = cur.parentElement; continue; }
          if (okTop(cur)) best = cur;
          cur = cur.parentElement;
        }
        if (best) { seen.add(best); best.setAttribute('data-pcv-hide', 'header'); }
      });
    });
  }
  function okTop(el) {
    if (el.hasAttribute('data-pcv-no')) return false;
    var r = el.getBoundingClientRect();
    if (r.top > 12 || r.bottom < 6 || r.height > innerHeight * 0.4 || r.width < innerWidth * 0.5) return false;
    var cs = getComputedStyle(el), pos = cs.position;
    if (/(auto|scroll)/.test(cs.overflowY) && el.scrollHeight > el.clientHeight + 40) return false;
    try { if (el.matches(GUARD) || el.closest(GUARD) || el.querySelector(GUARD + ',rich-textarea,textarea,[contenteditable="true"]')) return false; } catch (e) {}
    if ((el.textContent || '').trim().length > 200) return false;
    // sirf upar chipke (fixed/absolute/sticky) ya khali/dhundhle patte (koi text nahi) maane jayenge
    var floaty = pos === 'fixed' || pos === 'absolute' || pos === 'sticky';
    var blank = !(el.textContent || '').trim();
    return floaty || blank || /header|top-bar|toolbar|banner/i.test(el.tagName + ' ' + el.className + ' ' + (el.getAttribute('role') || ''));
  }

  // ---------- Kaala shadow / gradient / fade (mask) hatao ----------
  var seenNg = new WeakSet();
  var ngTick = 0;
  function ngScan() {
    if (++ngTick % 5 === 0) seenNg = new WeakSet();
    var all = document.querySelectorAll('body *'), n = 0;
    for (var i = 0; i < all.length && n < 2500; i++) {
      var el = all[i]; if (seenNg.has(el)) continue; seenNg.add(el); n++;
      var cs = getComputedStyle(el);
      var mi = cs.webkitMaskImage || cs.maskImage;
      if (mi && mi !== 'none' && /gradient/.test(mi)) el.setAttribute('data-pcv-m', '1');
      var pos = cs.position;
      if ((pos === 'fixed' || pos === 'absolute' || pos === 'sticky') && /gradient/.test(cs.backgroundImage) && cs.webkitBackgroundClip !== 'text' &&
          (cs.pointerEvents === 'none' || el.children.length === 0 || !el.textContent.trim())) el.setAttribute('data-pcv-g', '1');
      ['::before', '::after'].forEach(function (ps) {
        var c2 = getComputedStyle(el, ps);
        if (c2.content && c2.content !== 'none' && c2.content !== 'normal' && (c2.position === 'absolute' || c2.position === 'fixed' || c2.position === 'sticky') &&
            (/gradient/.test(c2.backgroundImage) || (c2.boxShadow && c2.boxShadow !== 'none'))) el.setAttribute('data-pcv-gp', '1');
      });
    }
  }

  // ---------- selector banana ----------
  function selOf(el) {
    var parts = [], cur = el;
    for (var depth = 0; cur && cur.nodeType === 1 && cur !== document.body && depth < 12; depth++) {
      var p = cur.tagName.toLowerCase();
      if (cur.id && !/\d{3,}/.test(cur.id)) { parts.unshift('#' + CSS.escape(cur.id)); }
      else {
        var par = cur.parentElement;
        if (par) { var sib = [].filter.call(par.children, function (x) { return x.tagName === cur.tagName; }); if (sib.length > 1) p += ':nth-of-type(' + (sib.indexOf(cur) + 1) + ')'; }
        parts.unshift(p);
      }
      var s = parts.join(' > ');
      try { var m = document.querySelectorAll(s); if (m.length === 1 && m[0] === el) return s; } catch (e) {}
      if (cur.id && !/\d{3,}/.test(cur.id)) break;
      cur = cur.parentElement;
    }
    return parts.join(' > ');
  }
  function shortLbl(s) { var a = s.split(' > '); var l = a[a.length - 1]; return l.length > 26 ? l.slice(0, 26) + '…' : l; }

  // ---------- Chuno (hover + ↑ parent / ↓ child) ----------
  function startPick(msg, cb) {
    var box = document.createElement('div');
    box.style.cssText = 'position:fixed;pointer-events:none;border:2px solid #7c4dff;background:#7c4dff33;z-index:2147483646;top:0;left:0;width:0;height:0';
    var tip = document.createElement('div');
    tip.textContent = msg + '  (↑ parent, ↓ child, Enter/Click = chuno, Esc = cancel)';
    tip.style.cssText = 'position:fixed;top:8px;left:50%;transform:translateX(-50%);background:#1f1f1f;color:#fff;padding:6px 12px;border-radius:10px;font:13px sans-serif;z-index:2147483647;pointer-events:none;max-width:90vw';
    document.documentElement.appendChild(box); document.documentElement.appendChild(tip);
    var cur = null, stack = [];
    function ok(t) { return t && t.nodeType === 1 && t !== host && !host.contains(t) && t !== document.documentElement && t !== document.body; }
    function draw() { if (!cur) return; var r = cur.getBoundingClientRect(); box.style.top = r.top + 'px'; box.style.left = r.left + 'px'; box.style.width = r.width + 'px'; box.style.height = r.height + 'px'; }
    function mv(e) { if (!ok(e.target)) return; cur = e.target; stack = []; draw(); }
    function end() { document.removeEventListener('mousemove', mv, true); document.removeEventListener('click', ck, true); document.removeEventListener('keydown', kd, true); document.removeEventListener('mousedown', blk, true); box.remove(); tip.remove(); }
    function pickIt() { var t = cur; end(); if (ok(t)) cb(t); }
    function blk(e) { if (ok(e.target)) { e.preventDefault(); e.stopPropagation(); } }
    function ck(e) { e.preventDefault(); e.stopPropagation(); if (!cur && ok(e.target)) cur = e.target; pickIt(); }
    function kd(e) {
      if (e.key === 'Escape') { end(); return; }
      if (e.key === 'Enter') { e.preventDefault(); pickIt(); return; }
      if (e.key === 'ArrowUp' && cur && ok(cur.parentElement)) { e.preventDefault(); stack.push(cur); cur = cur.parentElement; draw(); }
      if (e.key === 'ArrowDown' && stack.length) { e.preventDefault(); cur = stack.pop(); draw(); }
    }
    document.addEventListener('mousemove', mv, true); document.addEventListener('click', ck, true); document.addEventListener('keydown', kd, true); document.addEventListener('mousedown', blk, true);
  }

  // ---------- Move / resize ----------
  var BX = ['position', 'left', 'top', 'width', 'height', 'max-width', 'min-width', 'margin', 'z-index', 'overflow', 'transform', 'bottom', 'right', 'box-sizing'];
  function q(s) { try { return document.querySelector(s); } catch (e) { return null; } }
  function clearEl(el) { if (!el) return; BX.forEach(function (p) { el.style.removeProperty(p); }); }
  function putEl(el, m) {
    var v = { position: 'fixed', left: m.x + 'px', top: m.y + 'px', width: m.w + 'px', height: m.h + 'px', 'max-width': 'none', 'min-width': '0', margin: '0', 'z-index': '1000', overflow: 'auto', transform: 'none', bottom: 'auto', right: 'auto', 'box-sizing': 'border-box' };
    for (var k in v) { if (el.style.getPropertyValue(k) !== v[k]) el.style.setProperty(k, v[k], 'important'); }
  }
  function movesApply() {
    S.moves.forEach(function (m) { if (m.sus) return; var el = q(m.s); if (!el) return; if (S.mvOn) putEl(el, m); else clearEl(el); });
  }
  function clamp(v, a, b) { return Math.min(b, Math.max(a, v)); }
  function getMove(s) { for (var i = 0; i < S.moves.length; i++) if (S.moves[i].s === s) return S.moves[i]; return null; }

  var raf = 0;
  function ovPos() {
    if (!editSel) { raf = 0; return; }
    var el = q(editSel);
    if (el) { var r = el.getBoundingClientRect(); ov.style.left = r.left + 'px'; ov.style.top = r.top + 'px'; ov.style.width = r.width + 'px'; ov.style.height = r.height + 'px'; hm.classList.toggle('in', r.top < 28); ov.querySelector('.hd').classList.toggle('in', r.top < 28); }
    raf = requestAnimationFrame(ovPos);
  }
  function ovSync() { ov.style.display = editSel && q(editSel) ? 'block' : 'none'; if (editSel && !raf) raf = requestAnimationFrame(ovPos); }
  function editStart(el) {
    var s = selOf(el), r = el.getBoundingClientRect();
    if (!getMove(s)) S.moves.push({ s: s, x: Math.round(r.left), y: Math.round(r.top), w: Math.round(r.width), h: Math.round(r.height) });
    S.mvOn = true; editSel = s; movesApply(); save(); apply();
  }
  function wireOv() {
    Array.prototype.forEach.call(ov.querySelectorAll('[data-m]'), function (h) {
      h.addEventListener('pointerdown', function (e) {
        var m = getMove(editSel), el = q(editSel); if (!m || !el) return;
        var mode = h.dataset.m, sx = e.clientX, sy = e.clientY, o = { x: m.x, y: m.y, w: m.w, h: m.h };
        try { h.setPointerCapture(e.pointerId); } catch (x) {}
        e.preventDefault();
        function mv(ev) {
          var dx = ev.clientX - sx, dy = ev.clientY - sy;
          if (mode === 'm') { m.x = Math.round(clamp(o.x + dx, 60 - o.w, innerWidth - 60)); m.y = Math.round(clamp(o.y + dy, 0, innerHeight - 30)); }
          if (mode === 'r' || mode === 'c') m.w = Math.round(Math.max(40, o.w + dx));
          if (mode === 'b' || mode === 'c') m.h = Math.round(Math.max(30, o.h + dy));
          if (mode === 'l') { var nw = Math.max(40, o.w - dx); m.x = Math.round(o.x + (o.w - nw)); m.w = Math.round(nw); }
          putEl(el, m);
        }
        function up() { h.removeEventListener('pointermove', mv); h.removeEventListener('pointerup', up); save(); }
        h.addEventListener('pointermove', mv); h.addEventListener('pointerup', up);
      });
    });
    ov.querySelector('.hd').addEventListener('click', function () { editSel = ''; apply(); });
  }

  // ---------- Gemini image-paste extension ke liye: paste ke dauran chat box ko normal kar do ----------
  // (chhupa ya hila hua chat box paste/send ko rok sakta hai; paste hone ke baad sab wapas wahi ho jata hai)
  window.__pcvApi = {
    suspend: function (ed) {
      var hidden = !ed || ed.getClientRects().length === 0 || ed.offsetWidth < 20;
      var touched = [];
      S.moves.forEach(function (m) { var el = q(m.s); if (el && ed && (el.contains(ed) || ed.contains(el))) { m.sus = 1; clearEl(el); touched.push(m); } });
      if (hidden || touched.length) { susp = true; apply(); }
      return function () { touched.forEach(function (m) { delete m.sus; }); susp = false; apply(); };
    }
  };

  // ---------- Panel ----------
  function paint() {
    if (!pan) return;
    while (pan.firstChild) pan.removeChild(pan.firstChild);
    function B(label, at, on) { at = at || {}; at.text = label; if (on) at.cls = 'on'; var x = mk('button', at); pan.appendChild(x); return x; }
    function T(t) { pan.appendChild(mk('div', { cls: 't', text: t })); }
    function R(label, title, icons) { var r = mk('div', { cls: 'r' }, [mk('span', { title: title, text: label })]); icons.forEach(function (i) { r.appendChild(mk('i', i)); }); pan.appendChild(r); }
    B('🎨 Dark / Font size / Color', { 'data-a': 'look' });
    B('🎯 Chuno aur chhupao', { 'data-a': 'pickhide' });
    B('✥ Chuno aur move / resize', { 'data-a': 'pickmove' });
    if (PRE) Object.keys(PRE).forEach(function (g) { var on = !!S.pre[g]; B((on ? '🙈 ' : '👁 ') + PRE[g].l + (on ? ' (chhupa)' : ''), { 'data-g': g }, on); });
    B('🌫 Kaala shadow/fade auto-hatao: ' + (S.ng ? 'ON' : 'OFF'), { 'data-a': 'ng' }, S.ng);
    B('🫥 Chuno: sirf background/shadow hatao', { 'data-a': 'pickclr' });
    if (S.hide.length || (PRE && Object.keys(S.pre).some(function (k) { return S.pre[k]; })))
      B(S.on ? '👁 Chhupi cheezein dikhao' : '🙈 Dobara chhupao', { 'data-a': 'all' }, !S.on);
    if (S.hide.length) {
      T('Chhupayi hui (' + S.hide.length + ')');
      S.hide.forEach(function (s, i) { R(shortLbl(s), s, [{ 'data-rh': i, text: '✕' }]); });
    }
    if (S.clr.length) {
      T('Sirf background hata (' + S.clr.length + ')');
      S.clr.forEach(function (m, i) { R(shortLbl(m.s), m.s, [{ 'data-cc': i, title: 'Jagah bhi khali karo (on/off)', text: m.c ? '⇕✓' : '⇕' }, { 'data-rc': i, text: '✕' }]); });
    }
    if (S.moves.length) {
      B('📐 Move/resize layout: ' + (S.mvOn ? 'ON' : 'OFF'), { 'data-a': 'mv' }, S.mvOn);
      T('Hilayi hui (' + S.moves.length + ')');
      S.moves.forEach(function (m, i) { R(shortLbl(m.s), m.s, [{ 'data-me': i, title: 'Phir se badlo', text: '✥' }, { 'data-mr': i, title: 'Pehle jaisa', text: '✕' }]); });
    }
    var sm = mk('small'); sm.appendChild(document.createTextNode('Alt+H = chhupi cheezein toggle')); sm.appendChild(mk('br')); sm.appendChild(document.createTextNode('Button ko kheench kar kahin bhi rakho'));
    pan.appendChild(sm);
  }
  function closePanel() { pan.classList.remove('o'); btn.classList.remove('o'); }
  function onPanel(e) {
    var t = e.target, b = t.closest('button, i'); if (!b) return;
    var d = b.dataset;
    if (d.g) { S.pre[d.g] = !S.pre[d.g]; S.on = true; }
    else if (d.a === 'look') { closePanel(); try { if (window.__ldk) window.__ldk.toggle(); } catch (x) {} return; }
    else if (d.a === 'all') S.on = !S.on;
    else if (d.a === 'mv') { S.mvOn = !S.mvOn; if (!S.mvOn) { S.moves.forEach(function (m) { clearEl(q(m.s)); }); editSel = ''; } }
    else if (d.a === 'pickhide') { closePanel(); startPick('🎯 Jo chhupana hai', function (el) {
      var r = el.getBoundingClientRect(), big = r.width > innerWidth * 0.7 && r.height > innerHeight * 0.7, hasIn = !!el.querySelector('rich-textarea,textarea,[contenteditable="true"],input');
      if ((big || hasIn) && !confirm('Ye cheez ' + (big ? 'poora page ' : '') + (hasIn ? 'aur chat/input box ' : '') + 'bhi chhupa degi.\n\nSirf shadow/background hatana ho to "🫥 sirf background hatao" use karo.\n\nPhir bhi chhupayein?')) return;
      var s = selOf(el); if (s && S.hide.indexOf(s) < 0) S.hide.push(s); S.on = true; save(); apply(); }); return; }
    else if (d.a === 'pickmove') { closePanel(); startPick('✥ Jise kheenchna/resize karna hai', function (el) { editStart(el); }); return; }
    else if (d.a === 'ng') { S.ng = !S.ng; if (S.ng) S.on = true; }
    else if (d.a === 'pickclr') { closePanel(); startPick('🫥 Jiska background/shadow hatana hai (andar ka content rahega)', function (el) { var s = selOf(el); if (s && !S.clr.some(function (m) { return m.s === s; })) S.clr.push({ s: s, c: 0 }); S.on = true; save(); apply(); }); return; }
    else if (d.cc !== undefined) { var m2 = S.clr[+d.cc]; if (m2) m2.c = m2.c ? 0 : 1; }
    else if (d.rc !== undefined) S.clr.splice(+d.rc, 1);
    else if (d.rh !== undefined) S.hide.splice(+d.rh, 1);
    else if (d.me !== undefined) { editSel = S.moves[+d.me].s; S.mvOn = true; closePanel(); }
    else if (d.mr !== undefined) { var m = S.moves.splice(+d.mr, 1)[0]; if (m) { clearEl(q(m.s)); if (editSel === m.s) editSel = ''; } }
    save(); apply();
  }
  try { chrome.runtime.onMessage.addListener(function (m) { if (m && m.cmd === 'pcv-toggle' && pan) { pan.classList.toggle('o'); btn.classList.toggle('o'); place(); } }); } catch (e) {}
  document.addEventListener('keydown', function (e) {
    if (e.altKey && (e.key === 'h' || e.key === 'H')) { e.preventDefault(); S.on = !S.on; save(); apply(); }
  }, true);

  // ---------- DOM helper (innerHTML nahi: Gemini jaisi sites Trusted Types lagati hain) ----------
  function mk(tag, at, kids) {
    var e = document.createElement(tag);
    for (var k in (at || {})) { if (k === 'text') e.textContent = at[k]; else if (k === 'cls') e.className = at[k]; else e.setAttribute(k, at[k]); }
    (kids || []).forEach(function (c) { e.appendChild(c); });
    return e;
  }
  // ---------- Button + panel UI (shadow DOM) ----------
  function build() {
    host = document.createElement('div'); host.id = 'pcv-host';
    host.style.cssText = 'all:initial;position:fixed;z-index:2147483647;right:10px;bottom:10px';
    sh = host.attachShadow({ mode: 'open' });
    var CSSTXT = '.b{width:38px;height:38px;border-radius:50%;border:1px solid #7c4dff;cursor:pointer;background:#1f1f1f;color:#fff;font-size:17px;opacity:.6;box-shadow:0 2px 8px #0008;touch-action:none}.b:hover,.b.o{opacity:1}' +
      '.p{display:none;position:absolute;right:0;bottom:42px;width:220px;max-height:70vh;overflow:auto;background:#1f1f1f;color:#fff;border:1px solid #444;border-radius:12px;padding:8px;font:13px sans-serif;box-shadow:0 6px 20px #000a;box-sizing:border-box}.p.o{display:block}.p.dn{bottom:auto;top:42px}' +
      '.p button{display:block;width:100%;margin:4px 0;padding:8px;border-radius:8px;border:1px solid #555;background:#2b2b2b;color:#fff;cursor:pointer;text-align:left;font:13px sans-serif}.p button.on{background:#7c4dff;border-color:#7c4dff}' +
      '.p small{display:block;opacity:.6;margin-top:6px}.t{opacity:.7;margin:8px 0 2px;font-size:12px}.r{display:flex;align-items:center;gap:6px;padding:3px 4px;background:#2b2b2b;border-radius:6px;margin:2px 0}.r span{flex:1;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;font:12px monospace}.r i{cursor:pointer;font-style:normal;padding:0 4px;opacity:.8}.r i:hover{opacity:1;color:#ff8a80}' +
      '#ov{display:none;position:fixed;pointer-events:none;border:2px dashed #7c4dff;box-sizing:border-box;z-index:1}#ov>div{position:absolute;pointer-events:auto;touch-action:none}' +
      '#ov .hm{left:0;top:-24px;height:22px;line-height:22px;padding:0 12px;background:#7c4dff;color:#fff;font:12px sans-serif;cursor:move;border-radius:8px 8px 0 0;white-space:nowrap}#ov .hm.in{top:2px;left:2px;border-radius:8px}' +
      '#ov .hd{right:0;top:-24px;height:22px;line-height:22px;padding:0 12px;background:#2e7d32;color:#fff;font:12px sans-serif;cursor:pointer;border-radius:8px 8px 0 0}#ov .hd.in{top:2px;right:2px;border-radius:8px}' +
      '#ov .hr{right:-7px;top:10px;bottom:10px;width:14px;cursor:ew-resize}#ov .hl{left:-7px;top:10px;bottom:10px;width:14px;cursor:ew-resize}#ov .hb{bottom:-7px;left:10px;right:10px;height:14px;cursor:ns-resize}#ov .hc{right:-9px;bottom:-9px;width:20px;height:20px;border-radius:50%;background:#7c4dff;cursor:nwse-resize}';
    sh.appendChild(mk('style', { text: CSSTXT }));
    var ovn = mk('div', { id: 'ov' }, [
      mk('div', { cls: 'hm', 'data-m': 'm', text: '✥ Kheencho' }), mk('div', { cls: 'hd', text: '✔ Done' }),
      mk('div', { cls: 'hr', 'data-m': 'r' }), mk('div', { cls: 'hl', 'data-m': 'l' }), mk('div', { cls: 'hb', 'data-m': 'b' }), mk('div', { cls: 'hc', 'data-m': 'c' })
    ]);
    sh.appendChild(ovn);
    sh.appendChild(mk('button', { cls: 'b', id: 't', title: 'Page Clean View (Alt+H)', text: '👁' }));
    sh.appendChild(mk('div', { cls: 'p', id: 'p' }));
    btn = sh.getElementById('t'); pan = sh.getElementById('p'); ov = sh.getElementById('ov'); hm = ov.querySelector('.hm');
    pan.addEventListener('click', onPanel); wireOv();
    // button: click = panel, kheencho = jagah badlo
    var dr = null;
    btn.addEventListener('pointerdown', function (e) { dr = { x: e.clientX, y: e.clientY, moved: false, r: innerWidth - host.getBoundingClientRect().right, b: innerHeight - host.getBoundingClientRect().bottom }; try { btn.setPointerCapture(e.pointerId); } catch (x) {} });
    btn.addEventListener('pointermove', function (e) {
      if (!dr) return; var dx = e.clientX - dr.x, dy = e.clientY - dr.y;
      if (!dr.moved && Math.abs(dx) + Math.abs(dy) < 5) return; dr.moved = true;
      S.btn = { r: Math.round(clamp(dr.r - dx, 0, innerWidth - 40)), b: Math.round(clamp(dr.b - dy, 0, innerHeight - 40)) }; place();
    });
    btn.addEventListener('pointerup', function () {
      if (!dr) return; var mv = dr.moved; dr = null;
      if (mv) { save(); return; }
      pan.classList.toggle('o'); btn.classList.toggle('o'); place();
    });
  }
  // ---------- Gemini: chat box dikhao/chhupao ke liye alag aankh wala button ----------
  var host2 = null, btn2 = null;
  function build2() {
    if (!PRE) return;
    host2 = document.createElement('div'); host2.id = 'pcv-host2';
    host2.style.cssText = 'all:initial;position:fixed;z-index:2147483647;right:58px;bottom:10px';
    var sh2 = host2.attachShadow({ mode: 'open' });
    sh2.appendChild(mk('style', { text: '.b{width:40px;height:40px;border-radius:50%;border:1px solid #7c4dff;cursor:pointer;background:#1f1f1f;color:#fff;opacity:.6;box-shadow:0 2px 8px #0008;touch-action:none;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:0;padding:0;line-height:1}.b:hover{opacity:1}.b.off{background:#7c4dff;opacity:1}.e{font-size:16px}.c{font:9px sans-serif}' }));
    btn2 = mk('button', { cls: 'b' }, [mk('span', { cls: 'e', text: '👁' }), mk('span', { cls: 'c', text: 'chat' })]);
    sh2.appendChild(btn2);
    var dr = null;
    btn2.addEventListener('pointerdown', function (e) { var r = host2.getBoundingClientRect(); dr = { x: e.clientX, y: e.clientY, moved: false, r: innerWidth - r.right, b: innerHeight - r.bottom }; try { btn2.setPointerCapture(e.pointerId); } catch (x) {} });
    btn2.addEventListener('pointermove', function (e) {
      if (!dr) return; var dx = e.clientX - dr.x, dy = e.clientY - dr.y;
      if (!dr.moved && Math.abs(dx) + Math.abs(dy) < 5) return; dr.moved = true;
      S.btn2 = { r: Math.round(clamp(dr.r - dx, 0, innerWidth - 44)), b: Math.round(clamp(dr.b - dy, 0, innerHeight - 44)) }; place2();
    });
    btn2.addEventListener('pointerup', function () {
      if (!dr) return; var mv = dr.moved; dr = null;
      if (mv) { save(); return; }
      S.pre.input = !S.pre.input; S.on = true; save(); apply();
    });
  }
  function paint2() {
    if (!btn2) return; var hid = !!S.pre.input;
    btn2.className = 'b' + (hid ? ' off' : '');
    btn2.firstChild.textContent = hid ? '🙈' : '👁';
    btn2.title = hid ? 'Gemini chat box dikhao' : 'Gemini chat box chhupao';
  }
  function place2() { if (host2 && S.btn2) { host2.style.right = S.btn2.r + 'px'; host2.style.bottom = S.btn2.b + 'px'; } }
  function place() {
    if (S.btn) { host.style.right = S.btn.r + 'px'; host.style.bottom = S.btn.b + 'px'; }
    var rr = host.getBoundingClientRect(); pan.classList.toggle('dn', rr.top < 300);
  }

  // ---------- start ----------
  function mount() {
    if (!document.documentElement) return setTimeout(mount, 20);
    st = document.createElement('style'); st.id = 'pcv-style';
    build(); build2();
    document.documentElement.appendChild(st); document.documentElement.appendChild(host); if (host2) document.documentElement.appendChild(host2);
    function boot(o) {
      var a = (o && o.pcvSites && o.pcvSites[HOST]) || null;
      if (a) { S = Object.assign(S, a); if (!Array.isArray(S.hide)) S.hide = []; if (!Array.isArray(S.moves)) S.moves = []; if (!S.pre) S.pre = {}; if (!Array.isArray(S.clr)) S.clr = []; }
      apply(); place(); place2();
    }
    try { chrome.storage.local.get('pcvSites', boot); } catch (e) { boot(null); }
    window.addEventListener('resize', function () { S.moves.forEach(function (m) { m.x = clamp(m.x, 60 - m.w, innerWidth - 60); m.y = clamp(m.y, 0, innerHeight - 30); }); movesApply(); place(); });
    var tk = 0;
    setInterval(function () {
      if (document.hidden) return;
      tk++;
      movesApply(); ovSync(); presetScan(); topScan(); if ((S.ng || (PRE && S.pre.header)) && tk % 3 === 0) ngScan();
      if (!host.isConnected && document.documentElement) document.documentElement.appendChild(host);
      if (host2 && !host2.isConnected && document.documentElement) document.documentElement.appendChild(host2);
      if (!st.isConnected && document.documentElement) document.documentElement.appendChild(st);
    }, 1000);
  }
  mount();
})();
