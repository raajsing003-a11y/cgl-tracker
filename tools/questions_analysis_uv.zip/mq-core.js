// ===== mq-core.js: content-save.js, saved.js aur background.js ka shared code =====
// 1) joinTiny   : bikhre 1-akshar wali lines jodta hai (rendered math ka innerText bigad jaye to)
// 2) parseBlock : ---MOCKBANK--- block -> questions
// 3) extractMath: DOM (clone) me rendered math ko asli LaTeX \( \) se badalta hai (multi-strategy)
// 4) broken     : saved question me toota math hai ya nahi
(function (G) {
  var MQ = G.MQ || (G.MQ = {});

  /* ---------- 1) joinTiny ---------- */
  var DEV = /[\u0900-\u097f]/, MATHCH = /^[\d.,+\-\u2212\u00d7\u00f7=<>\u2264\u2265\u2260\u00b1\u221a\u03c0%^()\[\]{}\/|:\u221e\u00b0]+$/;
  var LABEL = /^(?:\(?[A-D]\s*[).:]|Q\s*\d*\s*[:\uff1a.)])$/;               // 'A)', 'Q:' jaisi asli labels
  var TERM = /[\u0964.!?:\uff1a;]\s*$/;                                       // sentence/section ka ant
  var STARTER = /^(?:\u0938\u094d\u091f\u0947\u092a|\u091a\u0930\u0923|Step|\u0905\u0924\u0903|\u092e\u0942\u0932 \u0905\u0935\u0927\u093e\u0930\u0923\u093e|\u092c\u0947\u0938\u093f\u0915|\u0938\u094d\u092e\u093e\u0930\u094d\u091f|\u0917\u0932\u0924 \u0935\u093f\u0915\u0932\u094d\u092a|\u0938\u0939\u0940 \u0909\u0924\u094d\u0924\u0930|SUBJECT\s*[:\uff1a]|Q\s*\d*\s*[:\uff1a.)]|\(?[A-D]\s*[).:]|ANS|EXP|---)/i;
  function isTiny(l) {
    var s = String(l).trim(); if (!s) return false;
    if (LABEL.test(s)) return false;
    if (s.length <= 2) return true;
    if (s.length <= 6 && MATHCH.test(s)) return true;
    if (s.length <= 3 && !DEV.test(s)) return true;
    return false;
  }
  MQ.isTiny = isTiny;
  MQ.joinTiny = function (text) {
    var src = String(text == null ? '' : text).replace(/\r/g, '');
    if (!src) return src;
    var L = src.split('\n'), out = [], i = 0;
    while (i < L.length) {
      if (!isTiny(L[i])) { out.push(L[i]); i++; continue; }
      var j = i; while (j < L.length && isTiny(L[j])) j++;
      var run = L.slice(i, j);
      if (run.length < 3) { for (var k = 0; k < run.length; k++) out.push(run[k]); i = j; continue; }
      var line = run.map(function (x) { return x.trim(); }).join(' ');
      var prev = out.length ? out[out.length - 1] : null;
      if (prev != null && prev.trim() && !TERM.test(prev) && !STARTER.test(line)) { out[out.length - 1] = prev.replace(/\s+$/, '') + ' ' + line; line = null; }
      var nxt = j < L.length ? L[j] : null, cur = line == null ? out[out.length - 1] : line;
      if (nxt != null && nxt.trim() && !isTiny(nxt) && !TERM.test(cur) && !STARTER.test(nxt.trim()) && nxt.trim().length <= 60) {
        cur = cur.replace(/\s+$/, '') + ' ' + nxt.trim(); j++;
        if (line == null) out[out.length - 1] = cur; else line = cur;
      }
      if (line != null) out.push(line);
      i = j;
    }
    return out.join('\n');
  };

  /* ---------- 4) broken ---------- */
  MQ.broken = function (q) {
    if (!q) return false;
    if (q.bad) return true;
    var f = [q.t, q.e].concat(q.o || []);
    for (var i = 0; i < f.length; i++) { if (f[i] && MQ.joinTiny(f[i]) !== String(f[i]).replace(/\r/g, '')) return true; }
    return false;
  };


  /* ---- English subject: question/options me Hindi (Devanagari) nahi; max 2 question (main + sabse hard) ---- */
  MQ.MAX = 12;
  MQ.enOnly = function(s){
    s = String(s || ''); if(!/[\u0900-\u097f]/.test(s)) return s;
    var lines = s.split('\n'), keep = lines.filter(function(l){ return !/[\u0900-\u097f]/.test(l) || /[A-Za-z]{3}.*[\u0900-\u097f]|[\u0900-\u097f].*[A-Za-z]{3}/.test(l); });
    if(keep.length) s = keep.join('\n');
    s = s.replace(/[\u0900-\u097f]+(?:[\s,.?!\u0964'"\-:;()\/]*[\u0900-\u097f]+)*/g, '');
    return s.replace(/\s*[\/|]\s*["'\u2018\u2019\u201c\u201d]+/g, '').replace(/\(\s*\)|\[\s*\]/g, '').replace(/\s+\/\s*(?=\n|$)/g, '').replace(/(^|\n)\s*\/\s+/g, '$1').replace(/[ \t]{2,}/g, ' ').replace(/[ \t]+\n/g, '\n').trim();
  };
  MQ.post = function(list){
    list.forEach(function(q){ if(q.s === 'English'){ q.t = MQ.enOnly(q.t); q.o = (q.o || []).map(MQ.enOnly); } });
    return list.length > MQ.MAX ? list.slice(0, MQ.MAX) : list;
  };

  /* ---------- 2) parseBlock ---------- */
  MQ.parseBlock = function (raw) {
    var txt = String(raw || '').replace(/\r/g, ''), i = txt.lastIndexOf('---MOCKBANK---');
    if (i < 0) return [];
    txt = txt.slice(i + 14);
    var j = txt.indexOf('---END---'); if (j < 0) return [];
    txt = txt.slice(0, j);
    if (txt.split('\n').length < 8) txt = txt.replace(/\s+(?=(?:SUBJECT\s*[:\uff1a]|Q\s*\d*\s*[:\uff1a]|ANS(?:WER)?\s*[:\uff1a]|EXP(?:LANATION)?\s*[:\uff1a]|[A-D]\s*\)\s))/g, '\n');
    var out = [], cur = null, mode = '', sub = '', chap = '';
    function clean(x) { return String(x || '').replace(/\*\*/g, '').replace(/^\s*[*\u2022\-]\s+/, '').trim(); }
    txt.split('\n').forEach(function (line0) {
      if (/^\s*```/.test(line0)) return;                          // code-block fence
      var l = clean(line0), m;
      if (!l) return;
      if ((m = l.match(/^SUBJECT\s*[:\uff1a]\s*([A-Za-z]+)/i))) { var v = m[1].toLowerCase(); sub = /math/.test(v) ? 'Math' : /eng/.test(v) ? 'English' : /reason/.test(v) ? 'Reasoning' : /gk|gs|general/.test(v) ? 'GK' : ''; return; }
      if ((m = l.match(/^(?:CHAPTER|CH|TOPIC)\s*[:\uff1a]\s*(.+)$/i))) { chap = m[1].replace(/[<>]/g, '').trim().slice(0, 60); if (mode === 'e' || mode === 'a' || /^o[0-3]$/.test(mode)) mode = ''; return; }
      if ((m = l.match(/^Q\s*\d*\s*[:\uff1a.)]\s*(.*)$/i))) { cur = { t: m[1], o: ['', '', '', ''], a: '', e: '', s: sub, c: chap }; out.push(cur); mode = 'q'; return; }
      if (!cur) return;
      if ((m = l.match(/^\(?([A-D])\s*[).:]\s*(.*)$/)) && mode !== 'e') { cur.o['ABCD'.indexOf(m[1])] = m[2]; mode = 'o' + 'ABCD'.indexOf(m[1]); return; }
      if ((m = l.match(/^ANS(?:WER)?\s*[:\uff1a]\s*\(?\s*([A-D])/i))) { cur.a = m[1].toUpperCase(); mode = 'a'; return; }
      if ((m = l.match(/^EXP(?:LANATION)?\s*[:\uff1a]\s*(.*)$/i))) { cur.e = m[1]; mode = 'e'; return; }
      if (mode === 'q') cur.t += '\n' + l;
      else if (mode === 'e') cur.e += '\n' + l;
      else if (/^o[0-3]$/.test(mode)) cur.o[+mode[1]] += '\n' + l;
    });
    return MQ.post(out.filter(function (q) { return q.t && !/^</.test(q.t) && (q.o[0] || q.o[1]) && !/^<option/i.test(q.o[0]); }));
  };

  /* ---------- 3) MathML -> LaTeX (mini) ---------- */
  var OPS = { '\u00d7': '\\times ', '\u00f7': '\\div ', '\u2212': '-', '\u2260': '\\neq ', '\u2264': '\\le ', '\u2265': '\\ge ', '\u00b1': '\\pm ', '\u221e': '\\infty ', '\u03c0': '\\pi ', '\u221a': '\\surd ', '\u00b0': '^\\circ ', '\u2248': '\\approx ', '\u2192': '\\to ', '\u22c5': '\\cdot ', '\u00b7': '\\cdot ', '%': '\\%', '&': '\\&', '#': '\\#', '_': '\\_' };
  function kids(el) { var r = []; for (var c = el.firstElementChild; c; c = c.nextElementSibling) { var n = (c.localName || c.tagName || '').toLowerCase(); if (n === 'annotation' || n === 'annotation-xml') continue; r.push(c); } return r; }
  function ml(el) {
    if (!el) return '';
    if (el.nodeType === 3) return el.textContent;
    var n = (el.localName || el.tagName || '').toLowerCase(), k = kids(el), t = (el.textContent || '').trim();
    function a(i) { return ml(k[i]); }
    function seq() { return k.map(ml).join(''); }
    switch (n) {
      case 'math': case 'mrow': case 'mstyle': case 'semantics': case 'mpadded': case 'merror': case 'mphantom': return seq();
      case 'mn': case 'mi': return t;
      case 'mtext': return t ? '\\text{' + t + '}' : '';
      case 'mo': return OPS[t] != null ? OPS[t] : t;
      case 'mfrac': return '\\frac{' + a(0) + '}{' + a(1) + '}';
      case 'msqrt': return '\\sqrt{' + seq() + '}';
      case 'mroot': return '\\sqrt[' + a(1) + ']{' + a(0) + '}';
      case 'msup': return '{' + a(0) + '}^{' + a(1) + '}';
      case 'msub': return '{' + a(0) + '}_{' + a(1) + '}';
      case 'msubsup': return '{' + a(0) + '}_{' + a(1) + '}^{' + a(2) + '}';
      case 'mover': return '\\overset{' + a(1) + '}{' + a(0) + '}';
      case 'munder': return '\\underset{' + a(1) + '}{' + a(0) + '}';
      case 'mfenced': return '(' + k.map(ml).join(',') + ')';
      case 'mspace': return '\\ ';
      default: return k.length ? seq() : t;
    }
  }
  MQ.mathml2tex = function (m) { return ml(m).replace(/\s+/g, ' ').trim(); };

  /* ---------- 3) extractMath ---------- */
  var ATTRS = ['data-math', 'data-tex', 'data-latex', 'data-formula', 'data-original', 'data-expr', 'data-katex'];
  MQ.MATH_SEL = '[data-math],[data-tex],[data-latex],[data-formula],[data-katex],.math-inline,.math-block,.katex-display,.katex,mjx-container,.MathJax,.MathJax_Display,math,script[type^="math/tex"]';
  function texOf(el) {
    var i, v;
    for (i = 0; i < ATTRS.length; i++) { v = el.getAttribute && el.getAttribute(ATTRS[i]); if (v && v.trim()) return { tex: v.trim(), how: ATTRS[i] }; }
    var q = el.querySelectorAll ? el.querySelectorAll('annotation') : [];
    for (i = 0; i < q.length; i++) { var enc = (q[i].getAttribute('encoding') || '').toLowerCase(); if ((/tex/.test(enc) || /latex/.test(enc)) && q[i].textContent.trim()) return { tex: q[i].textContent.trim(), how: 'annotation' }; }
    var inner = el.querySelector ? el.querySelector('[data-math],[data-tex],[data-latex]') : null;
    if (inner) { for (i = 0; i < ATTRS.length; i++) { v = inner.getAttribute(ATTRS[i]); if (v && v.trim()) return { tex: v.trim(), how: 'inner ' + ATTRS[i] }; } }
    var sc = el.tagName === 'SCRIPT' ? el : (el.querySelector ? el.querySelector('script[type^="math/tex"]') : null);
    if (sc && sc.textContent.trim()) return { tex: sc.textContent.trim(), how: 'script' };
    var mm = (el.localName || '').toLowerCase() === 'math' ? el : (el.querySelector ? el.querySelector('math') : null);
    if (mm) { var t = MQ.mathml2tex(mm); if (t) return { tex: t, how: 'mathml' }; }
    var al = el.getAttribute && (el.getAttribute('aria-label') || el.getAttribute('alt'));
    if (al && /[\\^_{}]/.test(al)) return { tex: al.trim(), how: 'aria' };
    var kh = el.querySelector ? el.querySelector('.katex-html') : null;
    if (!kh && el.classList && el.classList.contains('katex')) kh = el.querySelector('.katex-html');
    var plain = ((kh || el).textContent || '').replace(/\s+/g, ' ').trim();
    return { tex: '', plain: plain, how: 'plain' };
  }
  MQ.texOf = texOf;
  // root ke andar ka rendered math -> \( \) / \[ \] text. Return: { n, plain, hows }
  MQ.extractMath = function (root) {
    var res = { n: 0, plain: 0, hows: {} }, list = Array.prototype.slice.call(root.querySelectorAll(MQ.MATH_SEL));
    list.forEach(function (el) {
      if (!root.contains(el) || el === root) return;                          // parent pehle replace ho chuka
      var r = texOf(el), txt;
      var disp = (el.classList && (el.classList.contains('math-block') || el.classList.contains('katex-display') || el.classList.contains('MathJax_Display'))) || (el.closest && el.closest('.math-block,.katex-display')) || (el.getAttribute && el.getAttribute('display') === 'block');
      if (r.tex) { txt = (disp ? '\\[' : '\\(') + r.tex + (disp ? '\\]' : '\\)'); res.n++; res.hows[r.how] = (res.hows[r.how] || 0) + 1; }
      else { txt = r.plain ? ' ' + r.plain + ' ' : ''; res.plain++; }
      var tn = (el.ownerDocument || document).createTextNode(txt);
      if (el.parentNode) el.parentNode.replaceChild(tn, el);
    });
    return res;
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = MQ;
})(typeof self !== 'undefined' ? self : (typeof window !== 'undefined' ? window : globalThis));
