try { importScripts('mq-core.js'); } catch (e) {}
// ===== Gemini: HAMESHA EK HI window/tab =====
// - Pehle se khuli koi bhi Gemini tab/window (loading wali bhi) milti hai to wahi use hoti hai
// - Window banane ka kaam lock ke andar: do send ek saath aaye to bhi sirf ek window banti hai
// - Banayi hui window ki id yaad rakhte hain (service worker so jaye tab bhi)
var mem = null;
var lockP = Promise.resolve();
function withLock(fn) { var p = lockP.then(fn, fn); lockP = p.catch(function () {}); return p; }
function isGem(u) { return typeof u === 'string' && u.indexOf('https://gemini.google.com/') === 0; }

async function setPending(p) {
  p.t = Date.now(); mem = p;
  try { await chrome.storage.session.set({ pending: p }); } catch (e) {}
}
async function takePending() {
  var p = mem; mem = null;
  try {
    var o = await chrome.storage.session.get('pending');
    if (o && o.pending) { p = p || o.pending; await chrome.storage.session.remove('pending'); }
  } catch (e) {}
  if (p && Date.now() - p.t > 90000) return null;   // 90 sec se purani image skip
  return p || null;
}

async function geminiTab() {
  var all = [], sid = null;
  try {   // tabs + saved window id ek saath (pehle ek-ek karke)
    var rr = await Promise.all([chrome.tabs.query({}).catch(function () { return []; }), chrome.storage.session.get('gemWin').catch(function () { return null; })]);
    all = rr[0] || []; sid = rr[1] && rr[1].gemWin;
  } catch (e) {}
  var tabs = all.filter(function (t) { return isGem(t.url) || isGem(t.pendingUrl); });
  if (!tabs.length) return null;
  // 1) pehle jo window humne banayi thi
  if (sid != null) { var mine = tabs.filter(function (t) { return t.windowId === sid; })[0]; if (mine) return mine; }
  // 2) phir koi popup window, 3) phir koi bhi Gemini tab
  var wins = {}, wids = [];
  tabs.forEach(function (t) { if (wids.indexOf(t.windowId) < 0) wids.push(t.windowId); });
  await Promise.all(wids.map(function (id) { return chrome.windows.get(id).then(function (w) { wins[id] = w; }, function () {}); }));
  var pop = tabs.filter(function (t) { return wins[t.windowId] && wins[t.windowId].type === 'popup'; })[0];
  return pop || tabs[0];
}

// Sirf lock ke andar bulao: pehle dobara check, tabhi nayi window
async function ensureWin(m) {
  var t = await geminiTab();
  if (t) return { tab: t, created: false };
  var url = isGem(m.url) ? m.url : 'https://gemini.google.com/app';
  var g = m.geo || {}, o = { url: url, type: 'popup', focused: true };
  if (g && typeof g.l === 'number') { o.left = Math.round(g.l); o.top = Math.round(g.t); o.width = Math.round(g.w); o.height = Math.round(g.h); }
  var w = null;
  try { w = await chrome.windows.create(o); } catch (e) { try { w = await chrome.windows.create({ url: url, type: 'popup', focused: true }); } catch (x) {} }
  if (w) { try { await chrome.storage.session.set({ gemWin: w.id }); } catch (e) {} }
  return { tab: null, created: true };
}
async function front(t) {
  try { await Promise.all([chrome.windows.update(t.windowId, { focused: true, drawAttention: false }), chrome.tabs.update(t.id, { active: true })]); } catch (e) {}
}
async function tellTab(t, msg) {
  try { await chrome.tabs.sendMessage(t.id, msg); return true; } catch (e) {}
  // content script nahi mila (extension reload ke baad purani tab): inject karke dobara try
  try {
    await chrome.scripting.executeScript({ target: { tabId: t.id }, files: ['content-gemini.js'] });
    await new Promise(function (r) { setTimeout(r, 150); });
    await chrome.tabs.sendMessage(t.id, msg); return true;
  } catch (e2) {}
  return false;
}

chrome.runtime.onMessage.addListener(function (m, sender, reply) {
  if (m.cmd === 'send') {
    withLock(async function () {
      var p = { image: m.image, text: m.text };
      var r = await ensureWin(m);
      if (r.created) { await setPending(p); reply({ found: false }); return; }   // nayi window: load hote hi content-gemini utha lega
      var t = r.tab; await front(t);
      if (m.custom && isGem(m.url) && (t.url || '').split('?')[0].replace(/\/$/, '') !== m.url.split('?')[0].replace(/\/$/, '')) {   // apna specific URL: tab ko wahan le jao
        await setPending(p);
        try { await chrome.tabs.update(t.id, { url: m.url }); } catch (e) {}
        reply({ found: false }); return;
      }
      var ok = await tellTab(t, { cmd: 'paste', image: p.image, text: p.text });
      if (ok) { reply({ found: true }); return; }
      await setPending(p);                                        // tab abhi load ho rahi hai
      try { await chrome.tabs.reload(t.id); } catch (e) {}
      reply({ found: false });
    });
    return true;
  }
  if (m.cmd === 'open') {
    withLock(async function () {
      var r = await ensureWin(m);
      if (r.tab) await front(r.tab);
      reply({ found: !r.created });
    });
    return true;
  }
  if (m.cmd === 'getPending') {
    takePending().then(function (p) { reply(p); });
    return true;
  }
});

// ===== Page Clean View: toolbar icon = panel kholo (purane khule tab par bhi chalta hai) =====
chrome.action.onClicked.addListener(async function (tab) {
  try { await chrome.tabs.sendMessage(tab.id, { cmd: 'pcv-toggle' }); }
  catch (e) {
    try {
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content.js'] });
      setTimeout(function () { chrome.tabs.sendMessage(tab.id, { cmd: 'pcv-toggle' }).catch(function () {}); }, 500);
    } catch (x) {}
  }
});

// ===== Google (AI Mode): bhi HAMESHA EK hi window (sirf wahi jo extension ne banayi) =====
var memG = null;
function isGoo(u) { return typeof u === 'string' && /^https:\/\/www\.google\.[a-z.]+\//.test(u); }
async function setPendingG(p) { p.t = Date.now(); memG = p; try { await chrome.storage.session.set({ pendingG: p }); } catch (e) {} }
async function takePendingG() {
  var p = memG; memG = null;
  try { var o = await chrome.storage.session.get('pendingG'); if (o && o.pendingG) { p = p || o.pendingG; await chrome.storage.session.remove('pendingG'); } } catch (e) {}
  if (p && Date.now() - p.t > 90000) return null;
  return p || null;
}
async function googleTab() {
  var sid = null;
  try { var o = await chrome.storage.session.get('gooWin'); sid = o && o.gooWin; } catch (e) {}
  if (sid == null) return null;
  var tabs = [];
  try { tabs = await chrome.tabs.query({ windowId: sid }); } catch (e) { return null; }
  return tabs.filter(function (t) { return isGoo(t.url) || isGoo(t.pendingUrl); })[0] || tabs[0] || null;
}
async function ensureGoo(m) {
  var t = await googleTab();
  if (t) return { tab: t, created: false };
  var url = isGoo(m.url) ? m.url : 'https://www.google.com/search?udm=50';
  var g = m.geo || {}, o = { url: url, type: 'popup', focused: true };
  if (g && typeof g.l === 'number') { o.left = Math.round(g.l); o.top = Math.round(g.t); o.width = Math.round(g.w); o.height = Math.round(g.h); }
  var w = null;
  try { w = await chrome.windows.create(o); } catch (e) { try { w = await chrome.windows.create({ url: url, type: 'popup', focused: true }); } catch (x) {} }
  if (w) { try { await chrome.storage.session.set({ gooWin: w.id }); } catch (e) {} }
  return { tab: null, created: true };
}
async function tellGoo(t, msg) {
  try { await chrome.tabs.sendMessage(t.id, msg); return true; } catch (e) {}
  try {
    await chrome.scripting.executeScript({ target: { tabId: t.id }, files: ['content-google.js'] });
    await new Promise(function (r) { setTimeout(r, 150); });
    await chrome.tabs.sendMessage(t.id, msg); return true;
  } catch (e2) {}
  return false;
}
chrome.runtime.onMessage.addListener(function (m, sender, reply) {
  if (m.cmd === 'sendG') {
    withLock(async function () {
      var p = { image: m.image, text: m.text };
      var r = await ensureGoo(m);
      if (r.created) { await setPendingG(p); reply({ found: false }); return; }
      await front(r.tab);
      if (m.custom && isGoo(m.url) && (r.tab.url || '').split('&')[0] !== m.url.split('&')[0]) {
        await setPendingG(p);
        try { await chrome.tabs.update(r.tab.id, { url: m.url }); } catch (e) {}
        reply({ found: false }); return;
      }
      var ok = await tellGoo(r.tab, { cmd: 'paste-google', image: p.image, text: p.text });
      if (ok) { reply({ found: true }); return; }
      await setPendingG(p);
      try { await chrome.tabs.update(r.tab.id, { url: isGoo(m.url) ? m.url : 'https://www.google.com/search?udm=50' }); } catch (e) {}
      reply({ found: false });
    });
    return true;
  }
  if (m.cmd === 'openG') {
    withLock(async function () { var r = await ensureGoo(m); if (r.tab) await front(r.tab); reply({ found: !r.created }); });
    return true;
  }
  if (m.cmd === 'getPendingG') { takePendingG().then(function (p) { reply(p); }); return true; }
});

// ===== Mock Helper: kisi bhi site ka screenshot (content-mock.js maangta hai) + right-click toggle =====
chrome.runtime.onMessage.addListener(function (m, sender, reply) {
  if (m && m.cmd === 'mockCapture') {
    var wid = sender && sender.tab ? sender.tab.windowId : chrome.windows.WINDOW_ID_CURRENT;
    chrome.tabs.captureVisibleTab(wid, { format: 'jpeg', quality: 92 }, function (d) {
      var le = chrome.runtime.lastError;
      if (le || !d) reply({ ok: false, err: 'Screenshot nahi ban paya: ' + ((le && le.message) || 'khali') });
      else reply({ ok: true, data: d });
    });
    return true;
  }
});
chrome.runtime.onInstalled.addListener(function () {
  try {
    chrome.contextMenus.removeAll(function () {
      chrome.contextMenus.create({ id: 'mock-toggle', title: 'Gemini/Google bar: is site par dikhao/chhupao', contexts: ['page', 'frame', 'selection'] });
      chrome.contextMenus.create({ id: 'ldk-toggle', title: '🎨 Look: Dark / Font size / Color', contexts: ['action', 'page'] });
      chrome.contextMenus.create({ id: 'pen-toggle', title: '✏️ Pen: screen par draw karo (Alt+P)', contexts: ['action', 'page', 'frame', 'selection'] });
      chrome.contextMenus.create({ id: 'pen-btn', title: '✏️ Pen button: is site par dikhao/chhupao', contexts: ['page', 'frame', 'selection'] });
      chrome.contextMenus.create({ id: 'mq-open', title: '📂 Saved Mock Questions kholo', contexts: ['action', 'page'] });
    });
  } catch (e) {}
});
chrome.contextMenus.onClicked.addListener(function (info, tab) {
  if (info.menuItemId === 'ldk-toggle' && tab && tab.id != null) chrome.tabs.sendMessage(tab.id, { cmd: 'ldk-toggle' }, { frameId: 0 }).catch(function () {});
  if (info.menuItemId === 'mock-toggle' && tab && tab.id != null) chrome.tabs.sendMessage(tab.id, { cmd: 'mock-toggle' }).catch(function () {});
  if (info.menuItemId === 'pen-toggle' && tab && tab.id != null) chrome.tabs.sendMessage(tab.id, { cmd: 'pen-toggle' }, { frameId: 0 }).catch(function () {});
  if (info.menuItemId === 'pen-btn' && tab && tab.id != null) chrome.tabs.sendMessage(tab.id, { cmd: 'pen-btn' }, { frameId: 0 }).catch(function () {});
});


// ===== Saved Mock Questions: Gemini/Google reply se aaye questions extension me jama (chrome.storage.local 'mqSaved') =====
async function mqShrink(du) {
  try {
    var b = await (await fetch(du)).blob(), bm = await createImageBitmap(b), k = Math.min(1, 900 / Math.max(bm.width, bm.height));
    var c = new OffscreenCanvas(Math.round(bm.width * k), Math.round(bm.height * k)); c.getContext('2d').drawImage(bm, 0, 0, c.width, c.height);
    var ob = await c.convertToBlob({ type: 'image/jpeg', quality: 0.7 }), buf = new Uint8Array(await ob.arrayBuffer()), s = '';
    for (var i = 0; i < buf.length; i += 0x8000) s += String.fromCharCode.apply(null, buf.subarray(i, i + 0x8000));
    return 'data:image/jpeg;base64,' + btoa(s);
  } catch (e) { return ''; }
}
// Gemini/Google ko jaane wala har screenshot yaad rakho (source page ke saath) — save ke time pehle question ke saath lag jata hai
chrome.runtime.onMessage.addListener(function (m, sender) {
  if (m && (m.cmd === 'send' || m.cmd === 'sendG') && typeof m.image === 'string' && m.image.indexOf('data:image/') === 0) {
    mqShrink(m.image).then(function (img) {
      if (!img) return;
      chrome.storage.local.set({ mqLast: { img: img, src: (sender && sender.tab && sender.tab.url) || '', t: Date.now(), used: false } });
    });
  }
});
chrome.runtime.onMessage.addListener(function (m, sender, reply) {
  if (!m) return;
  if (m.cmd === 'mqOpen') { chrome.tabs.create({ url: chrome.runtime.getURL('saved.html') }); reply && reply({ ok: true }); return; }
  if (m.cmd === 'mqSave' && Array.isArray(m.items)) {
    chrome.storage.local.get(['mqSaved', 'mqLast'], function (o) {
      var all = (o && o.mqSaved) || [], last = o && o.mqLast, added = 0, dup = 0, ts = Date.now(), useShot = !!(last && last.img && !last.used && ts - last.t < 30 * 60 * 1000);
      var src = (useShot && last.src) || m.src || '';
      var fixed = 0;
      m.items.forEach(function (q, i) {
        if (!q || !q.t) return;
        var j = -1; for (var k = 0; k < all.length; k++) { if (mqSame(q, all[k])) { j = k; break; } }
        if (j >= 0) {
          var x = all[j];
          // purana toota hua (bikhre akshar) + naya sahi => purane ko naye se badlo
          if (self.MQ && MQ.broken(x) && !q.bad) {
            x.t = q.t; x.c = q.c || x.c; x.o = q.o || x.o; x.a = q.a || x.a; x.e = mqFmt(q.e); x.s = q.s || x.s; x.bad = 0;
            if (x.synced) { x.id = ts + i; x.force = true; x.synced = false; x.skipped = false; }   // app me gaya tha: naya copy force se jayega
            fixed++; return;
          }
          dup++; return;
        }
        all.unshift({ id: ts + i, s: q.s || 'Math', c: q.c || '', t: q.t, o: q.o || ['', '', '', ''], a: q.a || '', e: mqFmt(q.e), img: (added === 0 && useShot) ? last.img : '', src: src, ts: ts, synced: false, bad: q.bad ? 1 : 0 });
        added++;
      });
      var set = { mqSaved: all };
      if (added && useShot) { last.used = true; set.mqLast = last; }
      chrome.storage.local.set(set, function () { reply({ added: added, dup: dup, fixed: fixed, total: all.length }); });
    });
    return true;
  }
});
chrome.contextMenus.onClicked.addListener(function (info) { if (info.menuItemId === 'mq-open') chrome.tabs.create({ url: chrome.runtime.getURL('saved.html') }); });



/* ---- near-duplicate check: same/lagbhag same question + milte-julte options = repeat ---- */
function mqNorm(s){ return String(s || '').toLowerCase().replace(/[^a-z0-9\u0900-\u097f]+/g, ' ').trim(); }
function mqSet(s){ var o = {}; mqNorm(s).split(' ').forEach(function(w){ if(w) o[w] = 1; }); return o; }
function mqJacArr(a, b){ var A = {}, B = {}, n = 0, u = 0, k; a.forEach(function(x){ A[x] = 1; }); b.forEach(function(x){ B[x] = 1; });
  for(k in A){ u++; if(B[k]) n++; } for(k in B){ if(!A[k]) u++; } return u ? n / u : 0; }
function mqSame(q, x){
  if(!q || !x) return false;
  var tq = mqNorm(q.t), tx = mqNorm(x.t); if(!tq || !tx) return false;
  var oq = (q.o || []).map(mqNorm).filter(Boolean), ox = (x.o || []).map(mqNorm).filter(Boolean), both = oq.length && ox.length;
  if(tq === tx) return both ? mqJacArr(oq, ox) >= 0.5 : true;
  var A = mqSet(q.t), B = mqSet(x.t), ka = Object.keys(A), kb = Object.keys(B), n = 0;
  if(Math.min(ka.length, kb.length) < 5) return false;
  ka.forEach(function(k){ if(B[k]) n++; });
  var ov = n / Math.min(ka.length, kb.length);
  if(ov < 0.9) return false;
  return both ? mqJacArr(oq, ox) >= 0.5 : ov >= 0.97;
}



function mqFmt(e) {
  e = String(e || '').replace(/\r/g, '').trim();
  if (!e) return e;
  e = e.replace(/[ \t]*(मूल अवधारणा|बेसिक कॉन्सेप्ट|स्मार्ट ट्रिक|गलत विकल्प|सही उत्तर)/g, '\n\n$1');
  e = e.replace(/([।])[ \t]+(?=\S)/g, '$1\n');
  e = e.replace(/[ \t]+(?=(?:स्टेप|चरण|Step)\s*\d)/g, '\n');
  e = e.replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n');
  return e.trim();
}
function mqTex(s) {
  return String(s || '').replace(/\\\[([\s\S]+?)\\\]/g, function (m, a) { return '$$' + a + '$$'; }).replace(/\\\(([\s\S]+?)\\\)/g, function (m, a) { return '$' + a + '$'; });
}
