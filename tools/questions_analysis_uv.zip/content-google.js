(function () {
if (window.__sdGooInit) return; window.__sdGooInit = 1;
var busy = false;
function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
function norm(s) { return String(s || '').replace(/\s+/g, ' ').trim(); }
function curText(ed) { return ed ? (('value' in ed && ed.tagName !== 'DIV') ? ed.value : (ed.innerText || ed.textContent || '')) : ''; }
// Text daalo, phir check karo ki sach mein gaya; nahi gaya to doosre tareeke se dobara (3 koshish)
async function putText(getEd, text) {
  var probe = norm(text).slice(0, 40), tail = norm(text).slice(-25);
  for (var i = 0; i < 4; i++) {
    var ed = getEd(); if (!ed) { await sleep(500); continue; }
    var have = norm(curText(ed));
    if (have.indexOf(probe) >= 0 && have.indexOf(tail) >= 0) return true;      // pehle se hai
    ed.focus();
    var isInput = ed.tagName === 'TEXTAREA' || ed.tagName === 'INPUT';
    try {
      if (i === 0 || i === 1) {
        if (isInput) {
          var proto = ed.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
          Object.getOwnPropertyDescriptor(proto, 'value').set.call(ed, text);
          ed.dispatchEvent(new Event('input', { bubbles: true }));
        } else {
          var sel = window.getSelection(), r = document.createRange(); r.selectNodeContents(ed); sel.removeAllRanges(); sel.addRange(r);
          document.execCommand('insertText', false, text);
        }
      } else if (i === 2) {
        var dt = new DataTransfer(); dt.setData('text/plain', text);
        ed.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true }));
      } else {
        if (isInput) { ed.value = text; } else { ed.textContent = text; }
        ed.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: text }));
      }
    } catch (x) {}
    for (var w = 0; w < 14; w++) {
      await sleep(40);
      have = norm(curText(getEd() || ed));
      if (have.indexOf(probe) >= 0 && have.indexOf(tail) >= 0) return true;
    }
  }
  return false;
}

function vis(el) { return !!(el && el.getClientRects().length && el.offsetWidth > 20 && el.offsetHeight > 10); }
function findEditor() {
  var c = [].slice.call(document.querySelectorAll('textarea, input[name="q"], div[contenteditable="true"], [role="textbox"], [role="combobox"]')).filter(vis);
  return c[0] || null;
}
function waitFor(fn, ms) {
  return new Promise(function (res) {
    var t0 = Date.now();
    (function tick() { var v = fn(); if (v) return res(v); if (Date.now() - t0 > ms) return res(null); setTimeout(tick, 40); })();
  });
}
// Image attach hua ya nahi: jaise hi koi naya image/preview dikhe turant aage (nahi dikha to max wait tak ruko — pehle jaisa safe)
function attachCount(ed) {
  var n = 0, root = ed;
  try { for (var k = 0; k < 7 && root.parentElement; k++) root = root.parentElement; n += root.querySelectorAll('img,canvas,[data-attachment],[aria-label*="mage" i]').length; } catch (e) {}
  try { n += document.querySelectorAll('img[src^="blob:"],img[src^="data:"]').length; } catch (e) {}
  return n;
}
async function waitAttach(ed, base, maxMs) {
  var t0 = Date.now(); await sleep(60);
  while (Date.now() - t0 < maxMs) {
    if (attachCount(ed) > base) { await sleep(100); return true; }
    await sleep(50);
  }
  return false;
}
function toFile(du) {
  var m = /^data:([^;]+);base64,(.*)$/.exec(du); if (!m) return null;
  var bin = atob(m[2]), u = new Uint8Array(bin.length);
  for (var i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
  return new File([u], 'question.' + (m[1].indexOf('png') >= 0 ? 'png' : 'jpg'), { type: m[1] });
}
function note(msg) {
  var d = document.createElement('div'); d.textContent = msg;
  d.style.cssText = 'position:fixed;left:50%;bottom:90px;transform:translateX(-50%);background:#222;color:#fff;padding:8px 14px;border-radius:12px;font:14px sans-serif;z-index:2147483647';
  document.documentElement.appendChild(d); setTimeout(function () { d.remove(); }, 4000);
}
function setText(ed, text) {
  ed.focus();
  if (ed.tagName === 'TEXTAREA' || ed.tagName === 'INPUT') {
    var proto = ed.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    var set = Object.getOwnPropertyDescriptor(proto, 'value').set;
    set.call(ed, (ed.value ? ed.value + '\n' : '') + text);
    ed.dispatchEvent(new Event('input', { bubbles: true }));
  } else {
    var sel = window.getSelection(), r = document.createRange(); r.selectNodeContents(ed); r.collapse(false); sel.removeAllRanges(); sel.addRange(r);
    document.execCommand('insertText', false, text);
  }
}
function sendBtns(ed) {
  var scope = document;
  var up = ed, k;
  for (k = 0; k < 6 && up.parentElement; k++) { up = up.parentElement; if (up.querySelectorAll('button, [role="button"]').length >= 2) { scope = up; } }
  return [].slice.call(scope.querySelectorAll('button, [role="button"]')).filter(function (b) {
    var l = ((b.getAttribute('aria-label') || '') + ' ' + (b.title || '') + ' ' + (b.type || '') + ' ' + (b.getAttribute('data-tooltip') || '')).toLowerCase();
    return vis(b) && b.getAttribute('aria-disabled') !== 'true' && !b.disabled && /submit|send|search|bhejo/.test(l) && !/voice|mic|lens|image|upload|clear|close|add/.test(l);
  });
}
function hasText(ed, probe) { return norm(curText(ed)).indexOf(probe) >= 0; }
async function submit(getEd, probe) {
  // 1) send button dabao  2) na gaya to Enter  3) phir button dobara
  for (var i = 0; i < 3; i++) {
    var ed = getEd(); if (!ed || !hasText(ed, probe)) return true;      // box khali = chala gaya
    if (i === 1) {
      ed.focus();
      ['keydown', 'keypress', 'keyup'].forEach(function (t) {
        ed.dispatchEvent(new KeyboardEvent(t, { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true }));
      });
    } else {
      var b = sendBtns(ed); if (b.length) b[b.length - 1].click();
    }
    for (var w = 0; w < 14; w++) { await sleep(70); var e0 = getEd(); if (!e0 || !hasText(e0, probe)) break; }   // chala gaya to turant
  }
  var e2 = getEd(); return !e2 || !hasText(e2, probe);
}
async function deliver(p) {
  if (busy) return; busy = true;
  try {
    var ed = await waitFor(findEditor, 25000);
    if (!ed) { note('Google ka search box nahi mila'); return; }
    var f = p.image ? toFile(p.image) : null; if (!f && !p.text) return;
    ed.focus();
    if (f) {
      var base = attachCount(ed);
      var dt = new DataTransfer(); dt.items.add(f);
      ed.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true }));
      await waitAttach(ed, base, 1800);
    }
    var ed2 = findEditor() || ed;
    if (p.text) {
      var okT = await putText(findEditor, p.text);
      if (!okT) { note('⚠ Prompt paste nahi hua — Ctrl+V karo (prompt clipboard me hai)'); try { await navigator.clipboard.writeText(p.text); } catch (x) {} return; }
    }
    var probe = norm(p.text || '').slice(0, 40);
    var sent = p.text ? await submit(findEditor, probe) : true;
    note(sent ? (f ? '🔍 Image + question + prompt Google ko bhej diya' : '🔍 Question + prompt Google ko bhej diya') : '⚠ Auto-search nahi hua — blue ↑ (send) button dabao');
  } finally { setTimeout(function () { busy = false; }, 1200); }
}
chrome.runtime.onMessage.addListener(function (m, s, reply) { if (m.cmd === 'paste-google') { deliver(m); reply({ ok: true }); } });
(function poll(n) {
  try {
    chrome.runtime.sendMessage({ cmd: 'getPendingG' }, function (p) {
      void chrome.runtime.lastError;
      if (p && (p.image || p.text)) { deliver(p); return; }
      if (n > 0) setTimeout(function () { poll(n - 1); }, 250);
    });
  } catch (e) {}
})(80);
})();
